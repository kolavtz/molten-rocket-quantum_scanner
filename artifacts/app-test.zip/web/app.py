# pyre-ignore-all-errors
# Dummy reload for SQLAlchemy mappings
"""
Quantum-Safe TLS Scanner — Flask Web Application

Routes:
    GET  /            → Scanner dashboard
    POST /scan        → Run scan pipeline
    GET  /results/<id>→ View scan results
    GET  /cbom/<id>   → Download CBOM JSON
    GET  /api/scan    → REST API endpoint
"""

import sys
import typing
try:
    if hasattr(sys.stdout, 'reconfigure'):
        typing.cast(typing.Any, sys.stdout).reconfigure(encoding='utf-8')
except Exception:
    pass

import json
import re
import base64
import hashlib
import io
import pyotp
import qrcode
import secrets

import os
import uuid
import traceback
import logging
import socket
import urllib.request
import urllib.parse
from datetime import datetime, timezone
from typing import Any

from flask import (
    Flask,
    g,
    current_app,
    render_template,
    request,
    jsonify,
    send_file,
    redirect,
    url_for,
    Response,
    flash,
    session,
)
from flask_login import (
    LoginManager,
    UserMixin,
    login_user,
    logout_user,
    login_required,
    current_user,
)
from flask_mail import Mail, Message
from flask_wtf.csrf import CSRFProtect
from flask_talisman import Talisman
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.middleware.proxy_fix import ProxyFix
from functools import wraps, lru_cache
import threading

import sys
import typing
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from config import SECRET_KEY, DEBUG, FLASK_HOST, FLASK_PORT, RESULTS_DIR, AUTODISCOVERY_PORTS, BASE_DIR
from src.scanner.network_discovery import NetworkScanner, sanitize_target
from src.scanner.tls_analyzer import TLSAnalyzer
from src.scanner.pqc_detector import PQCDetector
from src.cbom.builder import CBOMBuilder
from src.cbom.cyclonedx_generator import CycloneDXGenerator
from src.validator.quantum_safe_checker import QuantumSafeChecker
from src.validator.certificate_issuer import CertificateIssuer
from src.reporting.report_generator import ReportGenerator
from src.reporting.recommendation_engine import RecommendationEngine
from src.services.dashboard_data_service import DashboardDataService
from src import database as db
from src.db import db_session
from web.pdf_export import generate_report_pdf

# ── Flask App ────────────────────────────────────────────────────────

app = Flask(
    __name__,
    template_folder=os.path.join(os.path.dirname(__file__), "templates"),
    static_folder=os.path.join(os.path.dirname(__file__), "static"),
)
app.secret_key = SECRET_KEY

@app.teardown_appcontext
def shutdown_session(exception=None):
    """
    Remove the scoped_session at request teardown.
    This prevents memory leaks and stale transactions (e.g., OperationalError).
    """
    try:
        db_session.remove()
    except Exception:
        pass


# Security Hardening & Mail Config
from config import (
    MAX_CONTENT_LENGTH,
    SESSION_COOKIE_HTTPONLY,
    SESSION_COOKIE_SECURE,
    SESSION_COOKIE_SAMESITE,
    PERMANENT_SESSION_LIFETIME,
    MAIL_SERVER,
    MAIL_PORT,
    MAIL_USE_TLS,
    MAIL_USE_SSL,
    MAIL_USERNAME,
    MAIL_PASSWORD,
    MAIL_DEFAULT_SENDER,
    FORCE_HTTPS,
    TRUST_PROXY_SSL_HEADER,
    HSTS_SECONDS,
    MAX_LOGIN_ATTEMPTS,
    LOGIN_LOCKOUT_MINUTES,
    REQUIRE_2FA,
    SESSION_COOKIE_NAME,
    SESSION_IDLE_TIMEOUT_SECONDS,
    AUDIT_LOG_PAGE_SIZE,
    RATELIMIT_STORAGE_URI,
    RATELIMIT_ENABLED,
    RATELIMIT_DEFAULT_LIMITS,
    CSP_CONFIG,
)

app.config.update(
    MAX_CONTENT_LENGTH=MAX_CONTENT_LENGTH,
    SESSION_COOKIE_HTTPONLY=SESSION_COOKIE_HTTPONLY,
    SESSION_COOKIE_SECURE=SESSION_COOKIE_SECURE,
    SESSION_COOKIE_SAMESITE=SESSION_COOKIE_SAMESITE,
    PERMANENT_SESSION_LIFETIME=PERMANENT_SESSION_LIFETIME,
    MAIL_SERVER=MAIL_SERVER,
    MAIL_PORT=MAIL_PORT,
    MAIL_USE_TLS=MAIL_USE_TLS,
    MAIL_USE_SSL=MAIL_USE_SSL,
    MAIL_USERNAME=MAIL_USERNAME,
    MAIL_PASSWORD=MAIL_PASSWORD,
    MAIL_DEFAULT_SENDER=MAIL_DEFAULT_SENDER,
    PREFERRED_URL_SCHEME="https" if FORCE_HTTPS else "http",
    SESSION_COOKIE_NAME=SESSION_COOKIE_NAME,
    # Keep CSRF token validation enabled, but do not hard-require Referer for HTTPS POSTs.
    # Some local/reverse-proxy/browser setups strip Referer, which otherwise blocks form deletes with 400.
    WTF_CSRF_SSL_STRICT=False,
)

if TRUST_PROXY_SSL_HEADER:
    app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Cache and throttling helpers for large datasets
_dashboard_cache = {
    "data": None,
    "updated_at": 0,
}
_dashboard_ttl_seconds = 30

# Database init guard for WSGI / debug reload flows
_db_initialized = False
_db_init_lock = threading.Lock()

from flask import Blueprint
dashboard_bp = Blueprint('main', __name__)

mail = Mail(app)
csrf = CSRFProtect(app)
talisman = Talisman(
    app,
    content_security_policy=CSP_CONFIG,
    force_https=FORCE_HTTPS,
    strict_transport_security=FORCE_HTTPS,
    strict_transport_security_max_age=HSTS_SECONDS,
    strict_transport_security_include_subdomains=True,
    frame_options="DENY",           # block all framing globally; /results overrides to SAMEORIGIN
    referrer_policy="strict-origin-when-cross-origin",
    session_cookie_secure=FORCE_HTTPS,
    force_https_permanent=False,    # use 302 so tests don't cache permanent redirects
)
limiter = Limiter(
    key_func=get_remote_address,
    app=app,
    default_limits=RATELIMIT_DEFAULT_LIMITS,  # type: ignore[arg-type]
    storage_uri=RATELIMIT_STORAGE_URI,
    enabled=RATELIMIT_ENABLED,
)

# Sprint 2: Log all rate-limit violations to the audit table.
try:
    from middleware.rate_limit_logger import log_rate_limit_violation
    limiter.request_filter(lambda: False)  # no-op filter; real hook below
    @limiter.request_filter
    def _noop_filter():
        return False  # Never exempt any request from limiter counting

    # Flask-Limiter ≥ 3.x uses on_breach for violation callbacks
    @app.after_request
    def _check_rate_limit_violation(response):
        """If the limiter set the 429 status, log the violation."""
        if response.status_code == 429:
            try:
                from middleware.rate_limit_logger import log_rate_limit_violation
                log_rate_limit_violation(None, request)
            except Exception:
                pass
        return response
except Exception:
    pass

def get_dashboard_data() -> dict:
    """Return real-time dashboard aggregation totals."""
    return DashboardDataService.get_all_scans_aggregated()


def invalidate_dashboard_cache() -> None:
    """Clear dashboard caches after asset or scan mutations."""
    _dashboard_cache["data"] = None
    _dashboard_cache["updated_at"] = 0
    try:
        from web.blueprints import dashboard as dashboard_blueprint

        dashboard_blueprint._dashboard_data_cache["data"] = None
        dashboard_blueprint._dashboard_data_cache["updated_at"] = 0
    except Exception:
        pass


def _start_scheduler_if_enabled() -> None:
    """Start background scheduler once in runtime context.

    Avoid starting scheduler at import-time (tests/reloader parent process),
    which can make startup appear stuck and create duplicate background work.
    """
    from config import AUTOMATED_SCAN_ENABLED

    if not AUTOMATED_SCAN_ENABLED:
        logger.info("Automated scheduler disabled.")
        return

    # In Flask debug reloader, parent process should not start background threads.
    if DEBUG and os.environ.get("WERKZEUG_RUN_MAIN") != "true":
        return

    try:
        from src.scheduler import start_scheduler
        start_scheduler()
    except Exception as e:
        app.logger.error("Failed to start automated scan scheduler: %s", e)


SCAN_ROLES = {"Admin", "Manager", "SingleScan", "Viewer"}
BULK_SCAN_ROLES = {"Admin", "Manager"}
ADMIN_PANEL_ROLES = {"Admin"}
ALL_APP_ROLES = {"Admin", "Manager", "SingleScan", "Viewer"}

# ── Theme Configuration ───────────────────────────────────────────
THEME_FILE = os.path.join(os.path.dirname(__file__), "theme.json")


_HEX_COLOR_RE = re.compile(r"^#[0-9a-fA-F]{6}$")

THEME_DEFAULTS = {
    "dark": {
        "bg_navbar": "#0b1220",
        "bg_primary": "#060b16",
        "bg_secondary": "#0f1b2d",
        "bg_card": "#111a2e",
        "bg_input": "#0d1628",
        "border_subtle": "#2a3a55",
        "border_hover": "#38bdf8",
        "text_primary": "#e6edf7",
        "text_secondary": "#b3c0d4",
        "text_muted": "#8a99b2",
        "accent_color": "#22d3ee",
        "text_on_accent": "#06202a",
        "safe": "#34d399",
        "warn": "#fbbf24",
        "danger": "#f87171",
    },
    "light": {
        "bg_navbar": "#f8fafc",
        "bg_primary": "#eef3fb",
        "bg_secondary": "#ffffff",
        "bg_card": "#ffffff",
        "bg_input": "#f8fbff",
        "border_subtle": "#c7d2e5",
        "border_hover": "#0ea5e9",
        "text_primary": "#0b1324",
        "text_secondary": "#334155",
        "text_muted": "#64748b",
        "accent_color": "#0ea5e9",
        "text_on_accent": "#ffffff",
        "safe": "#059669",
        "warn": "#d97706",
        "danger": "#dc2626",
    },
}


def _normalize_hex_color(value: Any, fallback: str) -> str:
    text = str(value or "").strip()
    if _HEX_COLOR_RE.match(text):
        return text.lower()
    return fallback


def _hex_to_rgb(color: str) -> tuple[int, int, int]:
    c = typing.cast(typing.Any, color.lstrip("#"))
    return int(c[0:2], 16), int(c[2:4], 16), int(c[4:6], 16)


def _relative_luminance(color: str) -> float:
    r, g, b = _hex_to_rgb(color)

    def _channel(v: int) -> float:
        x = v / 255.0
        return x / 12.92 if x <= 0.03928 else ((x + 0.055) / 1.055) ** 2.4

    rl = _channel(r)
    gl = _channel(g)
    bl = _channel(b)
    return 0.2126 * rl + 0.7152 * gl + 0.0722 * bl


def _contrast_ratio(color_a: str, color_b: str) -> float:
    la = _relative_luminance(color_a)
    lb = _relative_luminance(color_b)
    lighter = max(la, lb)
    darker = min(la, lb)
    return (lighter + 0.05) / (darker + 0.05)


def _sanitize_theme_palette(raw_palette: dict | None, defaults: dict) -> dict:
    raw_palette = raw_palette if isinstance(raw_palette, dict) else {}
    palette = {
        "bg_navbar": _normalize_hex_color(raw_palette.get("bg_navbar"), defaults["bg_navbar"]),
        "bg_primary": _normalize_hex_color(raw_palette.get("bg_primary"), defaults["bg_primary"]),
        "bg_secondary": _normalize_hex_color(raw_palette.get("bg_secondary"), defaults["bg_secondary"]),
        "bg_card": _normalize_hex_color(raw_palette.get("bg_card"), defaults["bg_card"]),
        "bg_input": _normalize_hex_color(raw_palette.get("bg_input"), defaults["bg_input"]),
        "border_subtle": _normalize_hex_color(raw_palette.get("border_subtle"), defaults["border_subtle"]),
        "border_hover": _normalize_hex_color(raw_palette.get("border_hover"), defaults["border_hover"]),
        "text_primary": _normalize_hex_color(raw_palette.get("text_primary"), defaults["text_primary"]),
        "text_secondary": _normalize_hex_color(raw_palette.get("text_secondary"), defaults["text_secondary"]),
        "text_muted": _normalize_hex_color(raw_palette.get("text_muted"), defaults["text_muted"]),
        "accent_color": _normalize_hex_color(raw_palette.get("accent_color"), defaults["accent_color"]),
        "text_on_accent": _normalize_hex_color(raw_palette.get("text_on_accent"), defaults.get("text_on_accent", "#ffffff")),
        "safe": _normalize_hex_color(raw_palette.get("safe"), defaults["safe"]),
        "warn": _normalize_hex_color(raw_palette.get("warn"), defaults["warn"]),
        "danger": _normalize_hex_color(raw_palette.get("danger"), defaults["danger"]),
    }

    def _best_text_for_background(bg_color: str) -> str:
        dark_text = "#0b1120"
        light_text = "#f3f4f6"
        dark_ratio = _contrast_ratio(bg_color, dark_text)
        light_ratio = _contrast_ratio(bg_color, light_text)
        return dark_text if dark_ratio >= light_ratio else light_text

    if _contrast_ratio(palette["bg_primary"], palette["text_primary"]) < 4.5:
        palette["text_primary"] = _best_text_for_background(palette["bg_primary"])

    if _contrast_ratio(palette["bg_card"], palette["text_primary"]) < 4.5:
        palette["text_primary"] = _best_text_for_background(palette["bg_card"])

    if _contrast_ratio(palette["bg_navbar"], palette["text_primary"]) < 4.5:
        palette["text_primary"] = _best_text_for_background(palette["bg_navbar"])

    if _contrast_ratio(palette["bg_card"], palette["text_secondary"]) < 3.0:
        palette["text_secondary"] = palette["text_primary"]
    if _contrast_ratio(palette["bg_card"], palette["text_muted"]) < 2.5:
        palette["text_muted"] = palette["text_secondary"]

    if _contrast_ratio(palette["accent_color"], palette["text_on_accent"]) < 4.5:
        palette["text_on_accent"] = _best_text_for_background(palette["accent_color"])

    return palette


def _sanitize_theme(raw_theme: dict) -> dict:
    raw_theme = raw_theme if isinstance(raw_theme, dict) else {}
    if "dark" in raw_theme or "light" in raw_theme:
        dark = _sanitize_theme_palette(raw_theme.get("dark"), THEME_DEFAULTS["dark"])
        light = _sanitize_theme_palette(raw_theme.get("light"), THEME_DEFAULTS["light"])
        mode = str(raw_theme.get("mode") or "system").lower()
    else:
        dark = _sanitize_theme_palette(raw_theme, THEME_DEFAULTS["dark"])
        light = _sanitize_theme_palette(raw_theme, THEME_DEFAULTS["light"])
        mode = str(raw_theme.get("mode") or "system").lower()

    if mode not in {"system", "dark", "light"}:
        mode = "system"

    active = dark if mode == "dark" else light if mode == "light" else dark
    return {
        "mode": mode,
        "dark": dark,
        "light": light,
        "active": active,
        "bg_navbar": active["bg_navbar"],
        "accent_color": active["accent_color"],
        "bg_primary": active["bg_primary"],
        "text_primary": active["text_primary"],
    }

def load_theme():
    if os.path.exists(THEME_FILE):
        try:
            with open(THEME_FILE, 'r') as f:
                data = json.load(f)
                return _sanitize_theme(data if isinstance(data, dict) else {})
        except Exception:
            pass
    return _sanitize_theme({"dark": THEME_DEFAULTS["dark"], "light": THEME_DEFAULTS["light"], "mode": "system"})

@app.context_processor
def inject_theme():
    return dict(theme=load_theme())

@app.context_processor
def inject_csrf_token():
    """Ensure CSRF token is always available in templates."""
    try:
        from flask_wtf.csrf import generate_csrf
        return dict(csrf_token=generate_csrf)
    except Exception:
        return dict(csrf_token=lambda: "")


# Graceful CSRF handling
from flask_wtf.csrf import CSRFError

@app.errorhandler(CSRFError)
def handle_csrf_error(e):
    """Provide a helpful feedback path for missing/invalid CSRF tokens."""
    logger.warning("CSRF validation failed: %s", str(e))
    
    # Check if the request wants JSON (e.g., from AJAX bulk operations)
    if request.is_json or (request.accept_mimetypes.best or "") == "application/json":
        return jsonify({
            "status": "error",
            "message": "Security check failed: CSRF token missing or invalid. Please refresh the page and try again."
        }), 403
    
    flash("Security check failed (CSRF token missing or invalid). Please reload the login page and try again.", "error")

    # If the user was already on login page, preserve feedback and show login form.
    if request.path == url_for('login'):
        return render_template('login.html', locked=False), 400

    return redirect(url_for('login'))


@app.before_request
def initialize_database():
    """Ensure MySQL bootstrap runs once in any WSGI/DEV server startup path."""
    if not _db_initialized:
        _bootstrap_runtime_state()


# Authentication
login_manager = LoginManager()
login_manager.login_view = "login"
login_manager.init_app(app)


@login_manager.unauthorized_handler
def _unauthorized_handler():
    if _expects_json_response():
        return jsonify({
            "status": "error",
            "message": "Authentication required.",
            "login_url": url_for("login"),
        }), 401
    return redirect(url_for("login"))

class User(UserMixin):
    def __init__(self, user_dict):
        self.id = user_dict["id"]
        self.username = user_dict["username"]
        self.role = db.normalize_role(user_dict.get("role", "Viewer"))
        self.is_active_user = bool(user_dict.get("is_active", True))

    @property
    def is_active(self):
        return self.is_active_user

@login_manager.user_loader
def load_user(user_id):
    user_data = db.get_user_by_id(str(user_id))
    if user_data:
        return User(user_data)
    return None


def _expects_json_response() -> bool:
    """Return True when caller expects JSON (AJAX/API), not HTML redirects."""
    if request.is_json:
        return True

    x_requested_with = str(request.headers.get("X-Requested-With", "") or "").strip().lower()
    if x_requested_with == "xmlhttprequest":
        return True

    best = str(request.accept_mimetypes.best or "").strip().lower()
    if best == "application/json":
        return True

    try:
        return (
            request.accept_mimetypes["application/json"] > 0
            and request.accept_mimetypes["application/json"] >= request.accept_mimetypes["text/html"]
        )
    except Exception:
        return False


def _is_api_request() -> bool:
    request_path = str(getattr(request, "path", "") or "")
    return request_path.startswith("/api/") or _expects_json_response()


@app.errorhandler(404)
def _handle_not_found(error):
    if _is_api_request():
        return jsonify({"status": "error", "message": "Resource not found."}), 404
    return error, 404


@app.errorhandler(405)
def _handle_method_not_allowed(error):
    if _is_api_request():
        return jsonify({"status": "error", "message": "Method not allowed."}), 405
    return error, 405


@app.errorhandler(500)
def _handle_internal_error(error):
    if _is_api_request():
        return jsonify({"status": "error", "message": "Internal server error."}), 500
    return error, 500

def role_required(roles):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.is_authenticated:
                db.append_audit_log(
                    event_category="auth",
                    event_type="unauthenticated_access_attempt",
                    status="denied",
                    ip_address=_get_request_ip(),
                    user_agent=request.headers.get("User-Agent", "")[:512],
                    request_method=request.method,
                    request_path=request.path,
                    details={"required_roles": roles},
                )
                if _expects_json_response():
                    return jsonify({
                        "status": "error",
                        "message": "Authentication required.",
                        "login_url": url_for("login"),
                    }), 401
                return redirect(url_for('login'))
            if current_user.role not in roles:
                _audit("auth", "authorization_denied", "denied", details={"required_roles": roles, "actual_role": current_user.role})
                if _expects_json_response():
                    return jsonify({
                        "status": "error",
                        "message": "You do not have permission to access this resource.",
                        "home_url": url_for("quantumshield_dashboard.dashboard_home"),
                    }), 403
                flash("You do not have permission to access this resource.", "error")
                return redirect(url_for('quantumshield_dashboard.dashboard_home'))
            return f(*args, **kwargs)
        return decorated_function
    return decorator


def require_api_key(f):
    """Decorator — enforces API key authentication for machine-facing endpoints.

    Reads the key from the ``X-API-Key`` header (preferred) or the
    ``api_key`` query parameter (CI/CD fallback).  On success, the resolved
    user dict is stored in ``flask.g.api_user``.  On failure returns a
    structured JSON 401 and logs the attempt.
    """

    @wraps(f)
    def decorated(*args, **kwargs):
        if app.config.get("TESTING"):
            g.api_user = {
                "id": "test-user",
                "username": "test",
                "role": "Admin",
            }
            return f(*args, **kwargs)

        raw_key = (
            request.headers.get("X-API-Key", "")
            or request.args.get("api_key", "")
            or (request.get_json(silent=True) or {}).get("api_key", "")
        ).strip()

        if not raw_key:
            db.append_audit_log(
                event_category="api",
                event_type="api_key_missing",
                status="denied",
                ip_address=_get_request_ip(),
                user_agent=request.headers.get("User-Agent", "")[:512],
                request_method=request.method,
                request_path=request.path,
            )
            return jsonify({"error": "API key required", "hint": "Pass X-API-Key header or ?api_key= param"}), 401

        user_data = db.get_user_by_api_key(raw_key)
        if not user_data:
            db.append_audit_log(
                event_category="api",
                event_type="api_key_invalid",
                status="denied",
                ip_address=_get_request_ip(),
                user_agent=request.headers.get("User-Agent", "")[:512],
                request_method=request.method,
                request_path=request.path,
            )
            return jsonify({"error": "Invalid or revoked API key"}), 401

        g.api_user = user_data
        db.append_audit_log(
            event_category="api",
            event_type="api_key_authenticated",
            status="success",
            actor_user_id=user_data.get("id"),
            actor_username=user_data.get("username"),
            ip_address=_get_request_ip(),
            user_agent=request.headers.get("User-Agent", "")[:512],
            request_method=request.method,
            request_path=request.path,
            details={"role": user_data.get("role")},
        )
        return f(*args, **kwargs)
    return decorated

def _is_https_request() -> bool:
    if request.is_secure:
        return True
    return request.headers.get("X-Forwarded-Proto", "").lower() == "https"


def _validate_password_strength(password: str) -> tuple[bool, str]:
    if not password or len(password) < 12:
        return False, "Password must be at least 12 characters long."
    if len(password) > 20:
        return False, "Password must be no more than 20 characters long."
    if not any(ch.isupper() for ch in password):
        return False, "Password must include at least one uppercase letter."
    if not any(ch.islower() for ch in password):
        return False, "Password must include at least one lowercase letter."
    if not any(ch.isdigit() for ch in password):
        return False, "Password must include at least one number."
    if not any(not ch.isalnum() for ch in password):
        return False, "Password must include at least one special character."
    return True, ""


def _build_setup_link(token: str) -> str:
    scheme = "https" if FORCE_HTTPS else None
    return url_for("setup_password", token=token, _external=True, _scheme=scheme)


def _smtp_resolution_error(exc: Exception) -> bool:
    """Detect DNS/host resolution failures from SMTP send attempts."""
    if isinstance(exc, socket.gaierror):
        return True
    text = str(exc or "").lower()
    return "getaddrinfo failed" in text or "errno 11001" in text or "name or service not known" in text


def _smtp_preflight_check() -> tuple[bool, str]:
    """Validate SMTP host resolves before attempting to send email."""
    host = str(app.config.get("MAIL_SERVER") or "").strip()
    port_raw = app.config.get("MAIL_PORT")
    try:
        port = int(port_raw) if port_raw is not None else 0
    except Exception:
        port = 0

    if not host:
        return False, "MAIL_SERVER is empty. Set a valid SMTP host in .env/config."

    try:
        socket.getaddrinfo(host, port if port > 0 else None)
    except socket.gaierror as exc:
        return False, f"MAIL_SERVER '{host}' could not be resolved ({exc})."
    except Exception:
        # Non-DNS errors should be handled by actual SMTP send.
        return True, ""
    return True, ""


def _smtp_failure_message(exc: Exception) -> str:
    """Build an actionable SMTP failure description for UI/API responses."""
    host = str(app.config.get("MAIL_SERVER") or "").strip() or "<unset>"
    if _smtp_resolution_error(exc):
        return f"SMTP DNS/host resolution failed for MAIL_SERVER '{host}'. Verify SMTP host/network DNS and retry."
    return f"SMTP failed: {str(exc)}"


def _get_request_ip() -> str:
    forwarded_for = request.headers.get("X-Forwarded-For", "")
    if forwarded_for:
        return forwarded_for.split(",")[0].strip()
    return request.headers.get("X-Real-IP") or request.remote_addr or "unknown"


def _audit(
    event_category: str,
    event_type: str,
    status: str,
    target_user_id: str | None = None,
    target_scan_id: str | None = None,
    details: dict | None = None,
) -> None:
    if app.config.get("TESTING", False):
        return
    actor_id = getattr(current_user, "id", None) if getattr(current_user, "is_authenticated", False) else None
    actor_username = getattr(current_user, "username", None) if getattr(current_user, "is_authenticated", False) else None
    db.append_audit_log(
        event_category=event_category,
        event_type=event_type,
        status=status,
        actor_user_id=actor_id,
        actor_username=actor_username,
        target_user_id=target_user_id,
        target_scan_id=target_scan_id,
        ip_address=_get_request_ip(),
        user_agent=request.headers.get("User-Agent", "")[:512],
        request_method=request.method,
        request_path=request.path,
        details=details or {},
    )


def _build_encrypted_audit_export_blob(
    logs: list[dict[str, Any]],
    chain_valid: bool,
    chain_issues: list[str],
    password: str,
    exported_by: str,
) -> bytes:
    """Build password-encrypted immutable audit export payload."""
    from cryptography.fernet import Fernet
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

    normalized_password = str(password or "").strip()
    if len(normalized_password) < 12:
        raise ValueError("Export password must be at least 12 characters long.")

    plaintext_payload = {
        "format": "quantumshield.audit.chain.v1",
        "exported_at": datetime.now(timezone.utc).isoformat(),
        "exported_by": exported_by,
        "chain_verified": bool(chain_valid),
        "chain_issues": list(chain_issues or []),
        "record_count": int(len(logs or [])),
        "records": logs or [],
    }
    plaintext_bytes = json.dumps(
        plaintext_payload,
        default=_json_default,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")

    iterations = 390000
    salt = os.urandom(16)
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=iterations,
    )
    key = base64.urlsafe_b64encode(kdf.derive(normalized_password.encode("utf-8")))
    encrypted_token = Fernet(key).encrypt(plaintext_bytes)

    export_envelope = {
        "format": "quantumshield.audit.encrypted-export.v1",
        "encryption": {
            "scheme": "fernet",
            "kdf": "PBKDF2-HMAC-SHA256",
            "iterations": iterations,
            "salt_b64": base64.b64encode(salt).decode("ascii"),
        },
        "integrity": {
            "plaintext_sha256": hashlib.sha256(plaintext_bytes).hexdigest(),
            "ciphertext_sha256": hashlib.sha256(encrypted_token).hexdigest(),
        },
        "record_count": int(len(logs or [])),
        "chain_verified": bool(chain_valid),
        "ciphertext_b64": encrypted_token.decode("utf-8"),
    }
    return json.dumps(export_envelope, indent=2).encode("utf-8")


@app.before_request
def disable_login_in_testing():
    if app.config.get("TESTING"):
        app.config["LOGIN_DISABLED"] = True


@app.before_request
def enforce_https_redirect():
    """Redirect HTTP requests to HTTPS.

    Localhost/127.0.0.1 are exempt by default (dev convenience).
    Set QSS_HTTPS_REDIRECT_LOCALHOST=true in .env to also enforce HTTPS on
    local loopback — useful for testing the full HTTPS-only flow locally.
    """
    if not FORCE_HTTPS:
        return None
    if app.config.get("TESTING") or request.path.startswith("/static/"):
        return None
    if _is_https_request():
        return None
    # Check if localhost redirect enforcement is enabled
    _redirect_localhost = os.environ.get("QSS_HTTPS_REDIRECT_LOCALHOST", "false").lower() == "true"
    if not _redirect_localhost:
        if request.host.startswith("127.0.0.1") or request.host.startswith("localhost"):
            return None  # dev convenience: don't redirect loopback
    secure_url = request.url.replace("http://", "https://", 1)
    return redirect(secure_url, code=301)


@app.before_request
def enforce_session_idle_timeout():
    if not getattr(current_user, "is_authenticated", False):
        session.pop("last_activity", None)
        return None

    now_ts = int(datetime.now(timezone.utc).timestamp())
    last_activity = session.get("last_activity")
    if last_activity and now_ts - int(last_activity) > SESSION_IDLE_TIMEOUT_SECONDS:
        user_name = getattr(current_user, "username", "unknown")
        logout_user()
        session.clear()
        db.append_audit_log(
            event_category="auth",
            event_type="session_timeout",
            status="success",
            actor_username=user_name,
            ip_address=_get_request_ip(),
            user_agent=request.headers.get("User-Agent", "")[:512],
            request_method=request.method,
            request_path=request.path,
            details={"idle_timeout_seconds": SESSION_IDLE_TIMEOUT_SECONDS},
        )
        flash("Session expired due to inactivity. Please sign in again.", "warning")
        return redirect(url_for("login"))

    session.permanent = True
    session["last_activity"] = now_ts
    return None


@app.after_request
def add_security_headers(response):
    """Add supplemental security headers not managed by Flask-Talisman.

    NOTE: Talisman runs as an `after_request` hook registered BEFORE this one,
    so any header Talisman sets will be overridden here. We deliberately re-assert
    X-Frame-Options: DENY and the Permissions-Policy to ensure the desired values
    survive regardless of Talisman's default behaviour.
    """
    # Re-assert framing protection (Talisman may set SAMEORIGIN by default on
    # some versions; we want DENY unless the route decorated itself otherwise).
    if "X-Frame-Options" not in response.headers or response.headers.get("X-Frame-Options") != "SAMEORIGIN":
        # Only force DENY if the route has not explicitly relaxed to SAMEORIGIN.
        response.headers["X-Frame-Options"] = "DENY"
    # Permissions-Policy — Talisman does not set this well by default
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    # Ensure X-Content-Type-Options is always present
    response.headers["X-Content-Type-Options"] = "nosniff"
    return response

# Ensure results directory exists
os.makedirs(RESULTS_DIR, exist_ok=True)

# ── Logging Setup ───────────────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] %(levelname)s in %(module)s: %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(os.path.join(BASE_DIR, "app.log"))
    ]
)
logger = logging.getLogger(__name__)
logger.info("QuantumShield application starting up...")

# In-memory store — hydrated from MySQL on cold start
scan_store: dict = {}
_geo_cache: dict[str, dict] = {}


def _parse_cert_time(value: str) -> str:
    """Convert OpenSSL-style certificate timestamp into ISO date string."""
    raw = str(value or "").strip()
    if not raw:
        return ""
    for fmt in ("%b %d %H:%M:%S %Y %Z", "%Y-%m-%dT%H:%M:%S%z", "%Y-%m-%d"):
        try:
            dt = datetime.strptime(raw, fmt)
            return dt.date().isoformat()
        except ValueError:
            continue
    return raw[:10]


def _parse_cert_datetime(value: str) -> datetime | None:
    """Convert certificate time strings into naive datetimes for SQL persistence."""
    raw = str(value or "").strip()
    if not raw:
        return None
    candidates = (
        "%b %d %H:%M:%S %Y %Z",
        "%Y-%m-%dT%H:%M:%S%z",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%d",
    )
    for fmt in candidates:
        try:
            parsed = datetime.strptime(raw, fmt)
            if parsed.tzinfo is not None:
                return parsed.astimezone(timezone.utc).replace(tzinfo=None)
            return parsed
        except ValueError:
            continue
    try:
        parsed = datetime.fromisoformat(raw.replace("Z", "+00:00"))
        if parsed.tzinfo is not None:
            return parsed.astimezone(timezone.utc).replace(tzinfo=None)
        return parsed
    except ValueError:
        return None


def _days_to_expiry(cert_not_after: str) -> int | None:
    """Return days until expiry from OpenSSL-style notAfter string."""
    raw = str(cert_not_after or "").strip()
    if not raw:
        return None
    try:
        exp_dt = datetime.strptime(raw, "%b %d %H:%M:%S %Y %Z")
        now = datetime.utcnow()
        return int((exp_dt - now).days)
    except ValueError:
        return None


def _cert_component(mapping: dict[str, Any] | None, field_name: str) -> str:
    source = mapping if isinstance(mapping, dict) else {}
    aliases = {
        "cn": ("CN", "commonName"),
        "o": ("O", "organizationName"),
        "ou": ("OU", "organizationalUnitName"),
    }
    for candidate in aliases.get(field_name.lower(), (field_name,)):
        value = str(source.get(candidate) or "").strip()
        if value:
            return value
    return ""


def _principal_display(cn: str, org: str, unit: str) -> str:
    parts = [str(cn or "").strip(), str(org or "").strip(), str(unit or "").strip()]
    return ", ".join(part for part in parts if part)


def _json_text(value: Any) -> str | None:
    if value in (None, "", [], {}):
        return None
    try:
        return json.dumps(value, default=_json_default)
    except Exception:
        return None


def _json_default(value: Any):
    if hasattr(value, "isoformat"):
        try:
            return value.isoformat()
        except Exception:
            pass
    return str(value)


def _coerce_int(value: Any) -> int | None:
    try:
        if value is None or value == "":
            return None
        return int(value)
    except (TypeError, ValueError):
        return None


def _normalize_fingerprint(value: Any) -> str | None:
    """Normalize fingerprint hex strings by stripping separators and lowercasing.

    Returns a canonical lowercase hex string (or None when input is empty/invalid).
    """
    if value is None:
        return None
    try:
        txt = str(value or "").strip()
    except Exception:
        return None
    if not txt:
        return None
    # Remove any non-hex characters (colons, spaces, etc.)
    txt = re.sub(r"[^0-9a-fA-F]", "", txt)
    if not txt:
        return None
    return txt.lower()


def _db_table_exists(table_name: str) -> bool:
    try:
        from sqlalchemy import inspect

        bind = db_session.get_bind()
        return bool(bind is not None and inspect(bind).has_table(table_name))
    except Exception:
        return False


def _persist_split_discovery_rows(
    scan_pk: int | None,
    asset_id: int | None,
    target: str,
    discovered_services: list[dict[str, Any]],
    tls_results: list[dict[str, Any]],
    pqc_assessments: list[dict[str, Any]],
    location_points: list[dict[str, Any]],
    promoted_to_inventory: bool = False,
) -> None:
    """Persist discovery telemetry into the live split discovery tables when present."""
    if not scan_pk:
        return

    from sqlalchemy import text

    now = datetime.now()
    is_promoted = bool(promoted_to_inventory and asset_id is not None and int(asset_id) > 0)
    promoted_at = now if is_promoted else None
    host = _host_from_target(target).strip().lower()
    geo_by_ip = {str(item.get("ip") or ""): item for item in (location_points or [])}
    pqc_by_endpoint: dict[tuple[str, int], dict[str, Any]] = {}
    pqc_by_index = list(pqc_assessments or [])
    for pq in pqc_by_index:
        endpoint_host = _host_from_target(str(pq.get("host") or "")).strip().lower()
        endpoint_port = _coerce_int(pq.get("port")) or 443
        if endpoint_host:
            pqc_by_endpoint[(endpoint_host, endpoint_port)] = pq

    if _db_table_exists("discovery_domains"):
        seen_domains: set[str] = set()
        domains = [host] if host else []
        for tls in tls_results:
            for domain in (tls.get("san_domains") or []):
                normalized = _host_from_target(str(domain or "")).strip().lower()
                if normalized:
                    domains.append(normalized)
        for domain in domains:
            normalized = _host_from_target(domain).strip().lower()
            if not normalized or normalized in seen_domains:
                continue
            seen_domains.add(normalized)
            db_session.execute(
                text(
                    """
                    INSERT INTO discovery_domains (
                        scan_id, asset_id, domain, status, promoted_to_inventory,
                        promoted_at, created_at, updated_at, is_deleted
                    ) VALUES (
                        :scan_id, :asset_id, :domain, :status, :promoted_to_inventory,
                        :promoted_at, :created_at, :updated_at, :is_deleted
                    )
                    """
                ),
                {
                    "scan_id": scan_pk,
                    "asset_id": asset_id,
                    "domain": normalized,
                    "status": "confirmed",
                    "promoted_to_inventory": is_promoted,
                    "promoted_at": promoted_at,
                    "created_at": now,
                    "updated_at": now,
                    "is_deleted": False,
                },
            )

    if _db_table_exists("discovery_ips"):
        seen_ips: set[str] = set()
        for svc in discovered_services:
            ip_addr = str(svc.get("host") or "").strip()
            if not ip_addr or ip_addr in seen_ips:
                continue
            try:
                import ipaddress

                ip_obj = ipaddress.ip_address(ip_addr)
            except ValueError:
                continue
            seen_ips.add(ip_addr)
            geo = geo_by_ip.get(ip_addr, {})
            location = ", ".join(
                part for part in (
                    str(geo.get("city") or "").strip(),
                    str(geo.get("region") or "").strip(),
                    str(geo.get("country") or "").strip(),
                )
                if part
            )
            subnet = f"{ip_addr}/32" if ip_obj.version == 4 else f"{ip_addr}/128"
            db_session.execute(
                text(
                    """
                    INSERT INTO discovery_ips (
                        scan_id, asset_id, ip_address, subnet, location, status,
                        promoted_to_inventory, promoted_at, created_at, updated_at, is_deleted
                    ) VALUES (
                        :scan_id, :asset_id, :ip_address, :subnet, :location, :status,
                        :promoted_to_inventory, :promoted_at, :created_at, :updated_at, :is_deleted
                    )
                    """
                ),
                {
                    "scan_id": scan_pk,
                    "asset_id": asset_id,
                    "ip_address": ip_addr,
                    "subnet": subnet,
                    "location": location or None,
                    "status": "confirmed",
                    "promoted_to_inventory": is_promoted,
                    "promoted_at": promoted_at,
                    "created_at": now,
                    "updated_at": now,
                    "is_deleted": False,
                },
            )

    if _db_table_exists("discovery_software"):
        seen_software: set[tuple[str, str, str]] = set()
        for svc in discovered_services:
            service = str(svc.get("service") or "").strip()
            banner = str(svc.get("banner") or "").strip()
            raw_product = banner or service
            if not raw_product:
                continue
            product = raw_product.split("/", 1)[0].strip() or service or "Unknown"
            version = raw_product.split("/", 1)[1].strip() if "/" in raw_product else ""
            key = (product.lower(), version.lower(), service.lower())
            if key in seen_software:
                continue
            seen_software.add(key)
            db_session.execute(
                text(
                    """
                    INSERT INTO discovery_software (
                        scan_id, asset_id, product, version, category, status,
                        promoted_to_inventory, promoted_at, created_at, updated_at, is_deleted
                    ) VALUES (
                        :scan_id, :asset_id, :product, :version, :category, :status,
                        :promoted_to_inventory, :promoted_at, :created_at, :updated_at, :is_deleted
                    )
                    """
                ),
                {
                    "scan_id": scan_pk,
                    "asset_id": asset_id,
                    "product": product,
                    "version": version or None,
                    "category": service or "software",
                    "status": "confirmed",
                    "promoted_to_inventory": is_promoted,
                    "promoted_at": promoted_at,
                    "created_at": now,
                    "updated_at": now,
                    "is_deleted": False,
                },
            )

    if _db_table_exists("discovery_ssl"):
        def _issuer_text_from_tls_row(tls_row: dict[str, Any]) -> str | None:
            issuer_raw = tls_row.get("issuer")
            if isinstance(issuer_raw, dict):
                issuer_display = _principal_display(
                    _cert_component(issuer_raw, "cn"),
                    _cert_component(issuer_raw, "o"),
                    _cert_component(issuer_raw, "ou"),
                )
                if issuer_display:
                    return issuer_display
            issuer_fallback = str(
                tls_row.get("issuer_cn")
                or tls_row.get("issuer_o")
                or tls_row.get("issuer_ou")
                or (issuer_raw if isinstance(issuer_raw, str) else "")
                or ""
            ).strip()
            if issuer_fallback:
                return issuer_fallback

            cert_details = tls_row.get("certificate_details") if isinstance(tls_row.get("certificate_details"), dict) else {}
            details_issuer = str(cert_details.get("issuer") or "").strip()
            return details_issuer or None

        def _subject_cn_from_tls_row(tls_row: dict[str, Any]) -> str | None:
            subject_raw = tls_row.get("subject")
            if isinstance(subject_raw, dict):
                cn = _cert_component(subject_raw, "cn")
                if cn:
                    return cn
            subject_cn_value = str(tls_row.get("subject_cn") or "").strip()
            if subject_cn_value:
                return subject_cn_value
            cert_details = tls_row.get("certificate_details") if isinstance(tls_row.get("certificate_details"), dict) else {}
            details_subject = str(cert_details.get("subject") or "").strip()
            return details_subject or None

        for idx, tls in enumerate(tls_results):
            endpoint_host = str(tls.get("host") or host or "").strip()
            endpoint_port = int(tls.get("port") or 443)
            endpoint = f"{endpoint_host}:{endpoint_port}" if endpoint_host else host
            endpoint_key = (_host_from_target(endpoint_host).strip().lower(), endpoint_port)
            endpoint_pqc = pqc_by_endpoint.get(endpoint_key, {})
            if not endpoint_pqc and idx < len(pqc_by_index):
                endpoint_pqc = pqc_by_index[idx] if isinstance(pqc_by_index[idx], dict) else {}
            pqc_score_raw = endpoint_pqc.get("score")
            pqc_score = float(pqc_score_raw) if isinstance(pqc_score_raw, (int, float)) else None
            pqc_assessment = str(
                endpoint_pqc.get("status")
                or endpoint_pqc.get("overall_status")
                or ""
            ).strip() or None
            db_session.execute(
                text(
                    """
                    INSERT INTO discovery_ssl (
                        scan_id, asset_id, endpoint, tls_version, cipher_suite, key_exchange,
                        key_length, subject_cn, issuer, valid_until, pqc_score, pqc_assessment, status,
                        promoted_to_inventory, promoted_at, created_at, updated_at, is_deleted
                    ) VALUES (
                        :scan_id, :asset_id, :endpoint, :tls_version, :cipher_suite, :key_exchange,
                        :key_length, :subject_cn, :issuer, :valid_until, :pqc_score, :pqc_assessment, :status,
                        :promoted_to_inventory, :promoted_at, :created_at, :updated_at, :is_deleted
                    )
                    """
                ),
                {
                    "scan_id": scan_pk,
                    "asset_id": asset_id,
                    "endpoint": endpoint or None,
                    "tls_version": tls.get("protocol_version") or tls.get("tls_version") or "Unknown",
                    "cipher_suite": tls.get("cipher_suite") or "Unknown",
                    "key_exchange": tls.get("key_exchange") or "Unknown",
                    "key_length": int(tls.get("key_length") or tls.get("key_size") or 0) or None,
                    "subject_cn": _subject_cn_from_tls_row(tls),
                    "issuer": _issuer_text_from_tls_row(tls),
                    "valid_until": tls.get("valid_until_dt"),
                    "pqc_score": pqc_score,
                    "pqc_assessment": pqc_assessment,
                    "status": "confirmed",
                    "promoted_to_inventory": is_promoted,
                    "promoted_at": promoted_at,
                    "created_at": now,
                    "updated_at": now,
                    "is_deleted": False,
                },
            )
def _normalize_tls_result(raw_result: dict) -> dict:
    """Normalize TLS analyzer output into dashboard/report-friendly schema."""
    raw = dict(raw_result or {})
    cert = typing.cast(dict, raw.get("certificate") if isinstance(raw.get("certificate"), dict) else {})
    issuer = cert.get("issuer") if isinstance(cert.get("issuer"), dict) else {}
    subject = cert.get("subject") if isinstance(cert.get("subject"), dict) else {}

    cipher_suite = str(raw.get("cipher_suite") or "")
    cipher_suites = raw.get("all_cipher_suites") if isinstance(raw.get("all_cipher_suites"), list) else []
    if not cipher_suites and cipher_suite:
        cipher_suites = [cipher_suite]

    cert_days = cert.get("days_until_expiry") if isinstance(cert.get("days_until_expiry"), int) else None
    if cert_days is None:
        cert_days = _days_to_expiry(str(cert.get("not_after") or ""))

    cert_expired = bool(cert.get("is_expired"))
    if cert_days is not None and cert_days < 0:
        cert_expired = True

    cert_status = "Unknown"
    if cert_expired:
        cert_status = "Expired"
    elif cert_days is not None:
        cert_status = "Expiring" if cert_days <= 30 else "Valid"

    key_bits = cert.get("public_key_bits")
    if not isinstance(key_bits, int):
        key_bits = int(raw.get("cipher_bits") or 0)

    subject_cn = str(cert.get("subject_cn") or _cert_component(subject, "cn"))
    subject_o = str(cert.get("subject_o") or _cert_component(subject, "o"))
    subject_ou = str(cert.get("subject_ou") or _cert_component(subject, "ou"))
    issuer_cn = str(cert.get("issuer_cn") or _cert_component(issuer, "cn"))
    issuer_o = str(cert.get("issuer_o") or _cert_component(issuer, "o"))
    issuer_ou = str(cert.get("issuer_ou") or _cert_component(issuer, "ou"))
    valid_from = _parse_cert_time(str(cert.get("not_before") or ""))
    valid_to = _parse_cert_time(str(cert.get("not_after") or ""))

    certificate_details = cert.get("certificate_details") if isinstance(cert.get("certificate_details"), dict) else {}
    spki = certificate_details.get("subject_public_key_info") if isinstance(certificate_details.get("subject_public_key_info"), dict) else {}
    public_key_fp = str(spki.get("public_key_fingerprint_sha256") or "").strip()

    issued_to = {
        "common_name": subject_cn or "<Not Part Of Certificate>",
        "organization": subject_o or "<Not Part Of Certificate>",
        "organizational_unit": subject_ou or "<Not Part Of Certificate>",
    }
    issued_by = {
        "common_name": issuer_cn or "<Not Part Of Certificate>",
        "organization": issuer_o or "<Not Part Of Certificate>",
        "organizational_unit": issuer_ou or "<Not Part Of Certificate>",
    }

    return {
        "host": raw.get("host"),
        "port": raw.get("port"),
        "tls_version": raw.get("protocol_version") or raw.get("tls_version") or "Unknown",
        "protocol_version": raw.get("protocol_version") or raw.get("tls_version") or "Unknown",
        "cipher_suite": cipher_suite or "Unknown",
        "cipher_suites": cipher_suites,
        "cipher_bits": int(raw.get("cipher_bits") or 0),
        "key_exchange": raw.get("key_exchange") or "Unknown",
        "certificate_chain_length": int(raw.get("certificate_chain_length") or 0),
        "issuer": issuer,
        "subject": subject,
        "subject_cn": subject_cn,
        "subject_o": subject_o,
        "subject_ou": subject_ou,
        "issuer_cn": issuer_cn,
        "issuer_o": issuer_o,
        "issuer_ou": issuer_ou,
        "serial_number": str(cert.get("serial_number") or ""),
        "key_type": str(cert.get("public_key_type") or "Unknown"),
        "key_size": key_bits,
        "key_length": key_bits,
        "public_key_type": str(cert.get("public_key_type") or "Unknown"),
        "public_key_pem": str(cert.get("public_key_pem") or ""),
        "signature_algorithm": str(cert.get("signature_algorithm") or ""),
        "cert_sha256": str(cert.get("fingerprint_sha256") or ""),
        "public_key_fingerprint_sha256": public_key_fp,
        "certificate_sha256": str(cert.get("fingerprint_sha256") or ""),
        "san_domains": cert.get("san_domains") if isinstance(cert.get("san_domains"), list) else [],
        "certificate_details": certificate_details,
        "issued_to": issued_to,
        "issued_by": issued_by,
        "valid_from": valid_from,
        "valid_to": valid_to,
        "valid_from_dt": _parse_cert_datetime(str(cert.get("not_before") or "")),
        "valid_until_dt": _parse_cert_datetime(str(cert.get("not_after") or "")),
        "cert_days_remaining": cert_days,
        "days_remaining": cert_days,
        "cert_expired": cert_expired,
        "cert_status": cert_status,
        "cert_chain_length": int(raw.get("certificate_chain_length") or 0),
        "error": raw.get("error"),
    }


def _collect_dns_records(host: str) -> list[dict]:
    """Collect DNS records with stdlib and optional dnspython if available."""
    records: list[dict] = []
    host = _host_from_target(host)
    if not host:
        return records

    now = datetime.now(timezone.utc).isoformat()

    try:
        _, _, ip_list = socket.gethostbyname_ex(host)
        for ip in ip_list:
            records.append({"hostname": host, "record_type": "A", "record_value": ip, "ttl": 300, "resolved_at": now})
    except Exception:
        pass

    try:
        infos = socket.getaddrinfo(host, None, socket.AF_INET6)
        seen = set()
        for info in infos:
            ip6 = info[4][0]
            if ip6 in seen:
                continue
            seen.add(ip6)
            records.append({"hostname": host, "record_type": "AAAA", "record_value": ip6, "ttl": 300, "resolved_at": now})
    except Exception:
        pass

    try:
        reverse_name = socket.gethostbyaddr(host)[0]
        records.append({"hostname": host, "record_type": "PTR", "record_value": reverse_name, "ttl": 300, "resolved_at": now})
    except Exception:
        pass

    try:
        import dns.resolver  # type: ignore

        for record_type in ("CNAME", "MX", "NS", "TXT"):
            try:
                answers = dns.resolver.resolve(host, record_type, lifetime=2.5)
                ttl = int(getattr(answers.rrset, "ttl", 300)) if getattr(answers, "rrset", None) else 300
                for ans in answers:
                    records.append(
                        {
                            "hostname": host,
                            "record_type": record_type,
                            "record_value": str(ans).strip(),
                            "ttl": ttl,
                            "resolved_at": now,
                        }
                    )
            except Exception:
                continue
    except Exception:
        pass

    uniq = set()
    deduped = []
    for r in records:
        key = (r["hostname"], r["record_type"], r["record_value"])
        if key in uniq:
            continue
        uniq.add(key)
        deduped.append(r)
    return deduped


def _collect_related_domains(
    target: str,
    tls_results: list[dict],
    dns_records: list[dict],
) -> list[str]:
    """Aggregate related domain names from TLS SAN data and DNS records.

    Included:
    - The target itself.
    - SANs from TLS certificate (non-wildcard; wildcard prefix stripped to base).
    - Hostnames from CNAME, MX records that share the base domain.

    Excluded:
    - NS records (authoritative name servers are infra, not application endpoints).
    - Domains that do not share the base domain with the target.

    Returns:
        Ordered, deduplicated list of related domain strings.
    """
    collected: list[str] = []
    seen: set[str] = set()

    def _add(domain: str) -> None:
        d = domain.strip().lower().rstrip(".")
        if d and d not in seen:
            seen.add(d)
            collected.append(d)

    target_clean = str(target or "").strip().lower().rstrip(".")
    target_labels = target_clean.split(".")
    base_domain = ".".join(target_labels[-2:]) if len(target_labels) >= 2 else target_clean

    def _is_same_zone(hostname: str) -> bool:
        h = hostname.strip().lower().rstrip(".")
        return h == base_domain or h.endswith(f".{base_domain}")

    # 1. Always include the scan target itself
    _add(target_clean)

    # 2. SANs from all TLS results
    for tls in (tls_results or []):
        san_list = tls.get("san_domains") or []
        cert = tls.get("certificate") or {}
        if not san_list and cert:
            san_list = cert.get("san_domains") or []
        for raw_san in san_list:
            san = str(raw_san or "").strip().lower().rstrip(".")
            if not san:
                continue
            if san.startswith("*."):
                san = san[2:]
            if _is_same_zone(san):
                _add(san)

    # 3. DNS records: CNAME, MX only (skip NS, TXT, A/AAAA which are IPs)
    _SKIP_TYPES = {"NS", "TXT", "SOA", "PTR", "SRV", "A", "AAAA"}
    for rec in (dns_records or []):
        rtype = str(rec.get("record_type") or "").upper().strip()
        if rtype in _SKIP_TYPES:
            continue
        raw_value = str(rec.get("record_value") or "").strip()
        if rtype == "MX":
            parts = raw_value.split(None, 1)
            hostname = parts[-1].rstrip(".")
        else:
            hostname = raw_value.rstrip(".")
        if hostname and _is_same_zone(hostname):
            _add(hostname)

    return collected


def _geolocate_ip(ip_addr: str) -> dict:
    """Resolve IP to approximate geo metadata for map visualization."""
    if not ip_addr:
        return {}
    cached = _geo_cache.get(ip_addr)
    if cached is not None:
        return cached

    result: dict = {}
    try:
        url = f"https://ipapi.co/{urllib.parse.quote(ip_addr)}/json/"
        req = urllib.request.Request(url, headers={"User-Agent": "QuantumShield/1.0"})
        with urllib.request.urlopen(req, timeout=2.0) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
        lat = payload.get("latitude")
        lon = payload.get("longitude")
        if isinstance(lat, (int, float)) and isinstance(lon, (int, float)):
            result = {
                "ip": ip_addr,
                "lat": float(lat),
                "lon": float(lon),
                "city": str(payload.get("city") or ""),
                "region": str(payload.get("region") or ""),
                "country": str(payload.get("country_name") or payload.get("country") or ""),
            }
    except Exception:
        result = {}

    _geo_cache[ip_addr] = result
    return result


def _autodetect_asset_class(target: str, discovered_services: list[dict], manual_class: str | None = None) -> str:
    """Resolve business asset class from operator hint or scan evidence."""
    if manual_class:
        return manual_class

    target_l = str(target).lower()
    ports = {int(s.get("port") or 0) for s in discovered_services if str(s.get("port") or "").isdigit()}
    service_text = " ".join(str(s.get("service") or "") + " " + str(s.get("banner") or "") for s in discovered_services).lower()

    if "vpn" in target_l or 1194 in ports or 500 in ports or 4500 in ports:
        return "Corporate VPN"
    if "consumer" in target_l or "mobile" in target_l or "retail" in target_l:
        return "Consumer App"
    if "api" in target_l or "gateway" in target_l or 8443 in ports:
        return "API Service"
    if "db" in target_l or "oracle" in service_text or "mysql" in service_text:
        return "Core Banking Data"
    if 443 in ports or 80 in ports:
        return "Internet Banking"
    return "Other"

def _bootstrap_runtime_state() -> None:
    """Load scan state from MySQL when running the application for real."""
    global _db_available, _db_initialized

    if app.config.get("TESTING", False):
        _db_available = False
        _db_initialized = True
        return

    if _db_initialized:
        logger.debug("_bootstrap_runtime_state called but db already initialized.")
        return

    with _db_init_lock:
        if _db_initialized:
            logger.debug("_bootstrap_runtime_state already completed by another thread/process.")
            return

        # Retry in case of transient initialization failures (locks, transient disconnects).
        max_attempts = 3
        for attempt in range(1, max_attempts + 1):
            try:
                logger.info("Initializing database connectivity at runtime (attempt %d/%d)...", attempt, max_attempts)
                _db_available = db.init_db()
            except Exception as exc:
                logger.warning("Database bootstrap attempt %d failed: %s", attempt, exc)
                _db_available = False

            if _db_available:
                break

            if attempt < max_attempts:
                import time
                time.sleep(1)

        if not _db_available:
            logger.warning("MySQL unavailable during runtime bootstrap after %d attempts; running in JSON-only mode.", max_attempts)
            # Try to hydrate in-memory scan_store from local JSON files in RESULTS_DIR
            try:
                import glob

                pattern = os.path.join(RESULTS_DIR, "*_report.json")
                files = sorted(glob.glob(pattern), reverse=True)
                for path in files:
                    try:
                        with open(path, "r", encoding="utf-8") as fh:
                            _data = json.load(fh)
                        if isinstance(_data, dict):
                            _sid = str(_data.get("scan_id") or _data.get("report_id") or "").strip()
                            if _sid:
                                scan_store[_sid] = _data
                    except Exception:
                        logger.debug("Failed to load local scan result %s", path, exc_info=True)
                logger.info("Hydrated scan_store from local JSON files: %d", len(scan_store))
            except Exception as exc:
                logger.warning("Failed to hydrate scan_store from RESULTS_DIR: %s", exc)

            _db_initialized = True
            return

        try:
            # Use the repository DB API rather than ORM model hydration.
            # This avoids hard coupling to optional ORM columns in legacy installs.
            for _report in db.list_scans(limit=10000):
                try:
                    _sid = str(_report.get("scan_id", "")).strip()
                    if _sid:
                        scan_store[_sid] = _report
                except Exception:
                    pass
            print(f"  💾 MySQL connected — loaded {len(scan_store)} scans from database")
        except Exception as exc:
            logger.warning("Failed to hydrate scan store from MySQL: %s", exc)
        finally:
            _db_initialized = True

        logger.info("Database initialization complete. Available=%s", _db_available)


# Initialise MySQL (if available) and hydrate scan_store
logger.info("Initializing database connectivity...")
_db_available = False
logger.info("Database bootstrap deferred until runtime startup hook.")

# Run data hydration only from runtime bootstrap path (_bootstrap_runtime_state)
# to avoid early ORM lookups against partially integrated legacy schemas.
print("  ⚙️ Waiting for runtime DB bootstrap...")

# ── Pipeline ─────────────────────────────────────────────────────────


def run_scan_pipeline(
    target: str,
    ports: list[int] | None = None,
    asset_class_hint: str | None = None,
    scan_kind: str = "manual",
    scanned_by: str | None = None,
    add_to_inventory: bool = False,
) -> dict:
    """Execute the full scan pipeline and return a report dict.

    Enforced workflow (no shortcuts):
    1. User Input (inventory / API target) -> Network Scan
    2. TLS Analysis
    3. PQC Detection
    4. Risk Scoring
    5. CBOM Generation (CycloneDX)
    6. SQL persistence (Scan/Asset/Certificate/PQC/CBOM)
    7. Response back to frontend/dashboards
    """
    scan_id = uuid.uuid4().hex[:8]

    # 1. Service Discovery (broad port sweep)
    scanner = NetworkScanner()
    all_services = scanner.discover_services(target, ports)
    discovered_services = [
        {
            "host": ep.host,
            "port": ep.port,
            "service": ep.service,
            "is_tls": ep.is_tls,
            "banner": ep.banner,
        }
        for ep in all_services
    ]
    dns_records = _collect_dns_records(target)

    # 2. Filter to TLS-capable endpoints only
    tls_endpoints = [ep for ep in all_services if ep.is_tls]

    # Fallback: if no TLS endpoints from broad sweep, try deeper discovery
    if not tls_endpoints:
        endpoints = scanner.discover_targets(target, ports)

        if endpoints:
            # Use endpoints found by discover_targets for full TLS analysis
            analyzer = TLSAnalyzer()
            tls_results = []
            for ep in endpoints:
                result = analyzer.analyze_endpoint(ep.host, ep.port)
                if result.is_successful:
                    tls_results.append(_normalize_tls_result(result.to_dict()))
        else:
            # Last resort: direct TLS analysis on port 443
            analyzer = TLSAnalyzer()
            tls_result = analyzer.analyze_endpoint(target, 443)
            if tls_result.is_successful:
                tls_results = [_normalize_tls_result(tls_result.to_dict())]
            else:
                return {
                    "scan_id": scan_id,
                    "target": target,
                    "status": "no_endpoints",
                    "message": f"No TLS endpoints found on {target}",
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "discovered_services": discovered_services,
                }
    else:
        # 3. TLS Analysis for each TLS endpoint
        analyzer = TLSAnalyzer()
        tls_results = []
        for ep in tls_endpoints:
            result = analyzer.analyze_endpoint(ep.host, ep.port)
            if result.is_successful:
                tls_results.append(_normalize_tls_result(result.to_dict()))

    if not tls_results:
        return {
            "scan_id": scan_id,
            "target": target,
            "status": "analysis_failed",
            "message": "TLS analysis failed for all endpoints.",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    # Reconcile discovered_services with tls_results
    # If network_discovery missed TLS (e.g. strict SNI), but the deep analyzer 
    # succeeded, we must update the discovery table so it shows "TLS" instead of "NO TLS"
    verified_tls_endpoints = {(res["host"], res["port"]) for res in tls_results}
    
    # Check if the fallback added a new endpoint (e.g. 443) that wasn't in discovered_services
    discovered_pairs = {(s["host"], s["port"]) for s in discovered_services}
    
    for host, port in verified_tls_endpoints:
        if (host, port) not in discovered_pairs:
            discovered_services.append({
                "host": host,
                "port": port,
                "service": "HTTPS",
                "is_tls": True,
                "banner": "TLSv1.3" # Best guess filler
            })
            
    for svc in discovered_services:
        if (svc["host"], svc["port"]) in verified_tls_endpoints:
            svc["is_tls"] = True  # Force true if analysis succeeded

    # 3. PQC Assessment
    detector = PQCDetector()
    pqc_assessments = [detector.assess_endpoint(tr) for tr in tls_results]
    pqc_dicts = [a.to_dict() for a in pqc_assessments]

    # 4. Build CBOM
    builder = CBOMBuilder()
    cbom = builder.build(tls_results, pqc_dicts)
    cbom_dict = cbom.to_dict()

    # 5. Validation
    checker = QuantumSafeChecker()
    validations = [
        checker.validate(tr, pd).to_dict()
        for tr, pd in zip(tls_results, pqc_dicts)
    ]

    # 6. Issue Labels
    issuer = CertificateIssuer()
    labels = [lb.to_dict() for lb in issuer.issue_labels(validations)]

    # 7. Recommendations
    rec_engine = RecommendationEngine()
    recommendations = []
    for v in validations:
        recommendations.extend(rec_engine.get_recommendations(v))

    # 8. Generate report
    reporter = ReportGenerator()
    report = reporter.generate_summary(cbom_dict, validations, labels)
    asset_class = _autodetect_asset_class(target, discovered_services, asset_class_hint)
    location_points = []
    seen_geo = set()
    for svc in discovered_services:
        ip = str(svc.get("host") or "")
        geo = _geolocate_ip(ip)
        if not geo:
            continue
        key = (geo.get("ip"), geo.get("lat"), geo.get("lon"))
        if key in seen_geo:
            continue
        seen_geo.add(key)
        location_points.append(geo)

    report["scan_id"] = scan_id
    report["target"] = target
    report["asset_class"] = asset_class
    report["status"] = "complete"
    report["scan_kind"] = str(scan_kind or "manual")
    report["scanned_by"] = str(scanned_by or "system")
    report["add_to_inventory"] = bool(add_to_inventory)
    report["tls_results"] = tls_results
    report["pqc_assessments"] = pqc_dicts
    report["recommendations_detailed"] = recommendations
    report["discovered_services"] = discovered_services
    report["dns_records"] = dns_records
    report["asset_locations"] = location_points

    # 9. Export CBOM JSON
    cdx_gen = CycloneDXGenerator()
    cbom_path = os.path.join(RESULTS_DIR, f"{scan_id}_cbom.json")
    cdx_gen.export_json(cbom_dict, cbom_path)
    report["cbom_path"] = cbom_path

    # 10. Save report (JSON file — primary)
    report_path = os.path.join(RESULTS_DIR, f"{scan_id}_report.json")
    reporter.export_json(report, report_path)

    # 11. Save to MySQL natively via SQLAlchemy Models
    from src.db import db_session
    from src.models import Scan, Asset, Certificate, PQCClassification, CBOMSummary, CBOMEntry, \
        DiscoveryDomain, DiscoverySSL, DiscoveryIP, DiscoverySoftware
    from sqlalchemy import func, or_
    from sqlalchemy.exc import SQLAlchemyError
    from src.services.risk_profile_service import derive_risk_level_from_scan_report
    report["orm_persisted"] = False
    try:
        dt = datetime.strptime(report.get("timestamp", datetime.now(timezone.utc).isoformat()), "%Y-%m-%dT%H:%M:%S.%f%z") if "." in report.get("timestamp", "") else datetime.now()
        overall_score = sum(float(pq.get("score", 0)) for pq in pqc_dicts) / max(len(pqc_dicts), 1)
        canonical_target = _host_from_target(target).strip().lower() or str(target or "").strip().lower()
        
        db_scan = Scan(
            scan_id=scan_id,
            target=canonical_target,
            status="complete",
            asset_class=asset_class,
            started_at=dt,
            completed_at=datetime.now(),
            scanned_at=datetime.now(),
            total_assets=len(discovered_services),
            compliance_score=int(overall_score),
            overall_pqc_score=overall_score,
            quantum_safe=sum(1 for x in pqc_dicts if float(x.get("score", 0) or 0) >= 80),
            quantum_vuln=sum(1 for x in pqc_dicts if float(x.get("score", 0) or 0) < 80),
            cbom_path=cbom_path,
            report_json=json.dumps(report, default=_json_default),
            is_encrypted=False,
        )
        db_session.add(db_scan)
        db_session.flush()

        scan_pk = getattr(db_scan, "id", None) or getattr(db_scan, "scan_id", None)
        
        # Resolve Asset for relational sync across discovery/certificates/PQC/CBOM.
        asset_id = None
        raw_target_lower = str(target or "").strip().lower()
        inventory_candidates = (
            db_session.query(Asset)
            .filter(
                or_(
                    func.lower(func.coalesce(Asset.target, "")) == canonical_target,
                    func.lower(func.coalesce(Asset.target, "")) == raw_target_lower,
                    func.lower(func.coalesce(Asset.url, "")).like(f"%{canonical_target}%"),
                )
            )
            .order_by(Asset.is_deleted.asc(), Asset.updated_at.desc(), Asset.id.desc())
            .all()
        )
        inventory_asset = next((a for a in inventory_candidates if not bool(getattr(a, "is_deleted", False))), None)
        if inventory_asset is None and inventory_candidates:
            inventory_asset = inventory_candidates[0]
        if inventory_asset and getattr(inventory_asset, "is_deleted", False):
            inventory_asset.is_deleted = False
            inventory_asset.deleted_at = None
            inventory_asset.deleted_by_user_id = None
        if not inventory_asset:
            score_risk = "Critical"
            if overall_score >= 80:
                score_risk = "Low"
            elif overall_score >= 60:
                score_risk = "Medium"
            elif overall_score >= 40:
                score_risk = "High"
            inventory_asset = Asset(
                target=canonical_target,
                url=f"https://{canonical_target}" if canonical_target and not canonical_target.startswith(("http://", "https://")) else canonical_target,
                asset_type="Web App",
                owner=str(scanned_by or "Unassigned"),
                risk_level=score_risk,
                notes="Auto-created from scan pipeline",
                is_deleted=False,
            )
            db_session.add(inventory_asset)
            db_session.flush()

        # Refresh existing inventory metadata on every scan so stale values are replaced.
        refreshed_risk = derive_risk_level_from_scan_report(
            report,
            fallback=str(getattr(inventory_asset, "risk_level", "") or "Medium"),
        )
        if canonical_target:
            inventory_asset.target = canonical_target
            inventory_asset.asset_key = canonical_target
            inventory_asset.url = f"https://{canonical_target}"
        if asset_class:
            inventory_asset.asset_type = str(asset_class)
        if scanned_by:
            inventory_asset.owner = str(scanned_by)
        inventory_asset.risk_level = refreshed_risk

        asset_id = int(getattr(inventory_asset, "id", 0) or 0)
        inventory_asset.last_scan_id = int(getattr(db_scan, "id", 0) or 0)

        if inventory_asset is not None:
            for svc in discovered_services:
                host = str(svc.get("host") or "").strip()
                if host and not str(getattr(inventory_asset, "ipv4", "") or "") and host.count(":") == 0 and any(ch.isdigit() for ch in host):
                    inventory_asset.ipv4 = host
                if host and not str(getattr(inventory_asset, "ipv6", "") or "") and host.count(":") > 1:
                    inventory_asset.ipv6 = host

        _persist_split_discovery_rows(
            scan_pk=int(scan_pk) if scan_pk is not None else None,
            asset_id=asset_id,
            target=canonical_target,
            discovered_services=discovered_services,
            tls_results=tls_results,
            pqc_assessments=pqc_dicts,
            location_points=location_points,
            promoted_to_inventory=bool(add_to_inventory),
        )
            
        # TLS & Certificates
        for tls in tls_results:
            # Normalize common fields
            subject_cn = str(tls.get("subject_cn") or "")
            subject_o = str(tls.get("subject_o") or "")
            subject_ou = str(tls.get("subject_ou") or "")
            issuer_cn = str(tls.get("issuer_cn") or "")
            issuer_o = str(tls.get("issuer_o") or "")
            issuer_ou = str(tls.get("issuer_ou") or "")
            subject_display = _principal_display(subject_cn, subject_o, subject_ou) or str(tls.get("subject") or "")
            issuer_display = _principal_display(issuer_cn, issuer_o, issuer_ou) or str(tls.get("issuer") or "")
            endpoint_host = str(tls.get("host") or canonical_target or "").strip()
            endpoint_port = int(tls.get("port") or 443)
            endpoint_str = f"{endpoint_host}:{endpoint_port}" if endpoint_host else None

            # Normalize fingerprint and serial for stable deduplication keys
            raw_fp = tls.get("cert_sha256") or tls.get("cert_sha256") or tls.get("fingerprint") or ""
            normalized_fp = _normalize_fingerprint(raw_fp)
            raw_serial = str(tls.get("serial_number") or "").strip()
            normalized_serial = raw_serial if raw_serial else None

            # Conservative upsert: prefer fingerprint, then serial, then endpoint
            existing_cert = None
            try:
                if normalized_fp:
                    existing_cert = db_session.query(Certificate).filter(Certificate.fingerprint_sha256 == normalized_fp).first()
                if existing_cert is None and normalized_serial:
                    existing_cert = db_session.query(Certificate).filter(func.lower(Certificate.serial) == normalized_serial.lower()).first()
                if existing_cert is None and endpoint_str:
                    existing_cert = db_session.query(Certificate).filter(Certificate.endpoint == endpoint_str).first()
            except Exception as existing_cert_exc:
                with open("debug_cert.txt", "a") as f: f.write(f"EXISTING_CERT EXCEPTION: {existing_cert_exc}\\n")
                existing_cert = None

            details_json_text = json.dumps(tls.get("certificate_details") or {}, default=_json_default)

            if existing_cert:
                # Update existing certificate with freshest telemetry (non-destructive)
                existing_cert.scan_id = int(scan_pk) if scan_pk is not None else existing_cert.scan_id
                existing_cert.asset_id = asset_id or existing_cert.asset_id
                existing_cert.endpoint = endpoint_str or existing_cert.endpoint
                existing_cert.port = endpoint_port or existing_cert.port
                existing_cert.issuer = issuer_display or existing_cert.issuer
                existing_cert.subject = subject_display or existing_cert.subject
                existing_cert.subject_cn = subject_cn or existing_cert.subject_cn
                existing_cert.subject_o = subject_o or existing_cert.subject_o
                existing_cert.subject_ou = subject_ou or existing_cert.subject_ou
                existing_cert.issuer_cn = issuer_cn or existing_cert.issuer_cn
                existing_cert.issuer_o = issuer_o or existing_cert.issuer_o
                existing_cert.issuer_ou = issuer_ou or existing_cert.issuer_ou
                existing_cert.serial = normalized_serial or existing_cert.serial
                existing_cert.company_name = subject_o or subject_cn or existing_cert.company_name
                existing_cert.valid_from = tls.get("valid_from_dt") or existing_cert.valid_from
                existing_cert.valid_until = tls.get("valid_until_dt") or existing_cert.valid_until
                existing_cert.expiry_days = _coerce_int(tls.get("cert_days_remaining")) or existing_cert.expiry_days
                existing_cert.fingerprint_sha256 = normalized_fp or existing_cert.fingerprint_sha256
                existing_cert.tls_version = tls.get("protocol_version") or existing_cert.tls_version
                existing_cert.key_length = int(tls.get("key_length", 0) or tls.get("key_size", 0)) or existing_cert.key_length
                existing_cert.key_algorithm = str(tls.get("key_type", "") or "Unknown") or existing_cert.key_algorithm
                existing_cert.public_key_type = str(tls.get("public_key_type") or tls.get("key_type") or "Unknown") or existing_cert.public_key_type
                existing_cert.public_key_pem = str(tls.get("public_key_pem", "") or "") or existing_cert.public_key_pem
                existing_cert.cipher_suite = tls.get("cipher_suite") or existing_cert.cipher_suite
                existing_cert.signature_algorithm = str(tls.get("signature_algorithm", "") or "") or existing_cert.signature_algorithm
                existing_cert.ca = issuer_cn or issuer_o or existing_cert.ca
                existing_cert.ca_name = issuer_o or issuer_cn or existing_cert.ca_name
                existing_cert.san_domains = _json_text(tls.get("san_domains") or []) or existing_cert.san_domains
                existing_cert.cert_chain_length = _coerce_int(tls.get("certificate_chain_length")) or existing_cert.cert_chain_length
                existing_cert.is_self_signed = bool(subject_display and issuer_display and subject_display == issuer_display)
                existing_cert.is_expired = bool(tls.get("cert_expired")) or existing_cert.is_expired
                existing_cert.certificate_details = details_json_text or existing_cert.certificate_details
            else:
                cert_obj = Certificate(
                    scan_id=int(scan_pk) if scan_pk is not None else None,
                    asset_id=asset_id,
                    endpoint=endpoint_str,
                    port=endpoint_port,
                    issuer=issuer_display or "Unknown",
                    subject=subject_display or "Unknown",
                    subject_cn=subject_cn or None,
                    subject_o=subject_o or None,
                    subject_ou=subject_ou or None,
                    issuer_cn=issuer_cn or None,
                    issuer_o=issuer_o or None,
                    issuer_ou=issuer_ou or None,
                    serial=normalized_serial,
                    company_name=subject_o or subject_cn or None,
                    valid_from=tls.get("valid_from_dt"),
                    valid_until=tls.get("valid_until_dt"),
                    expiry_days=_coerce_int(tls.get("cert_days_remaining")),
                    fingerprint_sha256=normalized_fp,
                    tls_version=tls.get("protocol_version", ""),
                    key_length=int(tls.get("key_length", 0) or tls.get("key_size", 0)),
                    key_algorithm=str(tls.get("key_type", "") or "Unknown"),
                    public_key_type=str(tls.get("public_key_type") or tls.get("key_type") or "Unknown"),
                    public_key_pem=str(tls.get("public_key_pem", "") or "") or None,
                    cipher_suite=tls.get("cipher_suite", ""),
                    signature_algorithm=str(tls.get("signature_algorithm", "") or "") or None,
                    ca=issuer_cn or issuer_o or "Unknown",
                    ca_name=issuer_o or issuer_cn or None,
                    san_domains=_json_text(tls.get("san_domains") or []),
                    cert_chain_length=_coerce_int(tls.get("certificate_chain_length")),
                    is_self_signed=bool(subject_display and issuer_display and subject_display == issuer_display),
                    is_expired=bool(tls.get("cert_expired")),
                    certificate_details=details_json_text,
                )
                db_session.add(cert_obj)
        
        db_session.flush() # Ensure certificates have IDs before service calls
            
        # PQC
        for pq in pqc_dicts:
            pqc_obj = PQCClassification(
                scan_id=int(scan_pk) if scan_pk is not None else None,
                asset_id=asset_id,
                algorithm_name=pq.get("algorithm", "Unknown"),
                algorithm_type=pq.get("category", "Unknown"),
                quantum_safe_status=pq.get("status", "Unknown"),
                nist_category=pq.get("nist_status", "None"),
                pqc_score=float(pq.get("score", 0))
            )
            db_session.add(pqc_obj)
            
        # CBOM
        cbom_summary = CBOMSummary(
            asset_id=asset_id,
            scan_id=int(scan_pk) if scan_pk is not None else None,
            total_components=len(pqc_dicts) + len(tls_results),
            weak_crypto_count=sum(1 for tls in tls_results if tls.get("protocol_version") in ("TLS 1.0", "SSLv3")),
            cert_issues_count=0,
            json_path=cbom_path
        )
        db_session.add(cbom_summary)

        def _component_properties(component: dict[str, Any]) -> dict[str, str]:
            props: dict[str, str] = {}
            for item in component.get("properties", []) or []:
                if not isinstance(item, dict):
                    continue
                key = str(item.get("name") or "").strip()
                if not key:
                    continue
                props[key] = str(item.get("value") or "").strip()
            return props

        def _boolish(value: Any) -> bool:
            text_value = str(value or "").strip().lower()
            return text_value in {"1", "true", "yes", "safe", "quantum-safe"}

        def _first_non_empty(*values: Any, default: str = "") -> str:
            for value in values:
                text_value = str(value or "").strip()
                if text_value:
                    return text_value
            return default

        def _first_int(*values: Any, default: int | None = None) -> int | None:
            for value in values:
                parsed = _coerce_int(value)
                if parsed is not None:
                    return parsed
            return default

        def _first_dt(*values: Any):
            for value in values:
                parsed = _parse_cert_datetime(str(value or ""))
                if parsed is not None:
                    return parsed
            return None

        fallback_tls = tls_results[0] if tls_results else {}
        fallback_protocol_name = _first_non_empty(
            fallback_tls.get("protocol_name"),
            "TLS",
            default="TLS",
        )
        fallback_protocol_version = _first_non_empty(
            fallback_tls.get("protocol_version"),
            fallback_tls.get("tls_version"),
        )
        fallback_cipher_suites_raw = fallback_tls.get("cipher_suites")
        fallback_cipher_suites = fallback_cipher_suites_raw if isinstance(fallback_cipher_suites_raw, list) else []
        fallback_cipher_text = ", ".join(str(v) for v in fallback_cipher_suites if str(v or "").strip())
        if not fallback_cipher_text:
            fallback_cipher_text = _first_non_empty(fallback_tls.get("cipher_suite"))

        components = cbom_dict.get("components") or []
        if not isinstance(components, list):
            components = []
        if not components and tls_results:
            for tls in tls_results:
                components.append(
                    {
                        "name": _first_non_empty(tls.get("cipher_suite"), tls.get("protocol_version"), "Unknown Crypto Element"),
                        "type": "algorithm",
                        "properties": [],
                    }
                )
        
        def _find_existing_cbom_entry():
            # Deduplicate on core certificate identity fields across inventory scans.
            if asset_id is None:
                return None
            return (
                db_session.query(CBOMEntry)
                .filter(CBOMEntry.is_deleted == False)
                .filter(CBOMEntry.asset_id == asset_id)
                .filter(func.lower(CBOMEntry.asset_type) == (asset_type or "").lower())
                .filter(func.lower(CBOMEntry.element_name) == (element_name_value or "").lower())
                .filter(func.lower(CBOMEntry.subject_name) == (subject_name_value or "").lower())
                .filter(func.lower(CBOMEntry.issuer_name) == (issuer_name_value or "").lower())
                .filter(func.lower(CBOMEntry.protocol_name) == (protocol_name_value or "").lower())
                .filter(func.lower(CBOMEntry.cipher_suites) == (cipher_suites_value or "").lower())
                .first()
            )

        for cmp in components:
            props = _component_properties(cmp)
            asset_type_raw = _first_non_empty(
                props.get("cert-in:asset_type"),
                props.get("asset_type"),
                cmp.get("type"),
                "algorithm",
            ).lower()
            if asset_type_raw not in {"algorithm", "key", "protocol", "certificate"}:
                if "cert" in asset_type_raw:
                    asset_type_raw = "certificate"
                elif "protocol" in asset_type_raw or "tls" in asset_type_raw:
                    asset_type_raw = "protocol"
                elif "key" in asset_type_raw:
                    asset_type_raw = "key"
                else:
                    asset_type_raw = "algorithm"
            asset_type = asset_type_raw

            key_size_value = _first_int(
                props.get("cert-in:size"),
                props.get("key_size"),
                props.get("quantum-safe:cert_public_key_bits"),
                props.get("quantum-safe:cipher_bits"),
                fallback_tls.get("key_size"),
                fallback_tls.get("key_length"),
            )
            key_length_value = key_size_value

            protocol_name_value = _first_non_empty(
                props.get("cert-in:protocols_name"),
                props.get("cert-in:protocol_name"),
                props.get("protocol_name"),
                fallback_protocol_name,
            )
            protocol_version_value = _first_non_empty(
                props.get("cert-in:version"),
                props.get("protocol_version_name"),
                props.get("quantum-safe:protocol"),
                fallback_protocol_version,
            )

            oid_value = _first_non_empty(
                props.get("cert-in:oid"),
                props.get("oid"),
                props.get("cert-in:signature_algorithm_oid"),
            )

            cipher_suites_value = _first_non_empty(
                props.get("cert-in:cipher_suites"),
                props.get("cipher_suites"),
                fallback_cipher_text,
            )

            crypto_functions_value = props.get("cert-in:crypto_functions") or props.get("crypto_functions")
            if isinstance(crypto_functions_value, list):
                crypto_functions_value = _json_text(crypto_functions_value)
            crypto_functions_text = str(crypto_functions_value or "")

            cert_extension_value = _first_non_empty(
                props.get("cert-in:extension"),
                props.get("certificate_extension"),
                ".crt" if asset_type == "certificate" else "",
            )
            if cert_extension_value and not cert_extension_value.startswith("."):
                cert_extension_value = f".{cert_extension_value}"

            signature_ref = _first_non_empty(
                props.get("cert-in:signature_algorithm_ref"),
                props.get("signature_algorithm_reference"),
                fallback_tls.get("signature_algorithm"),
            )
            public_key_ref = _first_non_empty(
                props.get("cert-in:subject_public_key_ref"),
                props.get("subject_public_key_reference"),
                fallback_tls.get("public_key_type"),
            )
            element_name_value = _first_non_empty(
                props.get("cert-in:name"),
                props.get("name"),
                cmp.get("name"),
            )
            element_list_value = props.get("cert-in:list") or props.get("element_list")
            if isinstance(element_list_value, list):
                element_list_value = _json_text(element_list_value)
            if not str(element_list_value or "").strip() and element_name_value:
                element_list_value = _json_text([element_name_value])

            fallback_subject_display = _first_non_empty(
                fallback_tls.get("subject_cn"),
                _cert_component(fallback_tls.get("subject") if isinstance(fallback_tls.get("subject"), dict) else {}, "cn"),
            )
            fallback_issuer_display = _first_non_empty(
                fallback_tls.get("issuer_cn"),
                fallback_tls.get("issuer_o"),
                _principal_display(
                    _cert_component(fallback_tls.get("issuer") if isinstance(fallback_tls.get("issuer"), dict) else {}, "cn"),
                    _cert_component(fallback_tls.get("issuer") if isinstance(fallback_tls.get("issuer"), dict) else {}, "o"),
                    _cert_component(fallback_tls.get("issuer") if isinstance(fallback_tls.get("issuer"), dict) else {}, "ou"),
                ),
                str(fallback_tls.get("issuer") or "") if isinstance(fallback_tls.get("issuer"), str) else "",
            )
            subject_name_value = _first_non_empty(
                props.get("cert-in:subject_name"),
                props.get("subject_name"),
                fallback_subject_display,
            )
            issuer_name_value = _first_non_empty(
                props.get("cert-in:issuer_name"),
                props.get("issuer_name"),
                fallback_issuer_display,
            )

            existing_entry = _find_existing_cbom_entry()

            if existing_entry is not None:
                # Update provided fields selectively
                update_fields = {
                    "scan_id": int(scan_pk) if scan_pk is not None else None,
                    "asset_id": asset_id,
                    "algorithm_name": element_name_value,
                    "category": cmp.get("type", "crypto-asset"),
                    "asset_type": asset_type,
                    "element_name": element_name_value,
                    "primitive": _first_non_empty(props.get("cert-in:primitive"), props.get("primitive")),
                    "mode": _first_non_empty(props.get("cert-in:mode"), props.get("mode")),
                    "crypto_functions": crypto_functions_text,
                    "classical_security_level": _first_int(props.get("cert-in:classical_security_level"), props.get("classical_security_level")),
                    "oid": oid_value,
                    "element_list": str(element_list_value or ""),
                    "key_id": _first_non_empty(props.get("cert-in:id"), props.get("key_id")),
                    "key_state": _first_non_empty(props.get("cert-in:state"), props.get("key_state")),
                    "key_size": key_size_value,
                    "key_creation_date": _first_dt(props.get("cert-in:creation_date"), props.get("key_creation_date")),
                    "key_activation_date": _first_dt(props.get("cert-in:activation_date"), props.get("key_activation_date")),
                    "protocol_name": protocol_name_value,
                    "protocol_version_name": protocol_version_value,
                    "cipher_suites": cipher_suites_value,
                    "subject_name": subject_name_value,
                    "issuer_name": issuer_name_value,
                    "not_valid_before": _first_dt(props.get("cert-in:not_valid_before"), props.get("not_valid_before"), fallback_tls.get("valid_from")),
                    "not_valid_after": _first_dt(props.get("cert-in:not_valid_after"), props.get("not_valid_after"), fallback_tls.get("valid_to")),
                    "signature_algorithm_reference": signature_ref,
                    "subject_public_key_reference": public_key_ref,
                    "certificate_format": _first_non_empty(props.get("cert-in:format"), props.get("certificate_format"), "X.509" if asset_type == "certificate" else ""),
                    "certificate_extension": cert_extension_value,
                    "key_length": key_length_value,
                    "protocol_version": protocol_version_value,
                    "nist_status": _first_non_empty(props.get("cert-in:quantum_safe_status"), props.get("quantum_safe_status"), "Unknown"),
                    "quantum_safe_flag": _boolish(props.get("cert-in:quantum_safe_status") or props.get("quantum-safe:is_quantum_safe")),
                    "hndl_level": props.get("quantum-safe:risk_level", "Medium"),
                }
                for field_name, field_value in update_fields.items():
                    if getattr(existing_entry, field_name, None) != field_value:
                        setattr(existing_entry, field_name, field_value)
            else:
                cbom_entry = CBOMEntry(
                    scan_id=int(scan_pk) if scan_pk is not None else None,
                    asset_id=asset_id,
                    algorithm_name=element_name_value,
                    category=cmp.get("type", "crypto-asset"),
                    asset_type=asset_type,
                    element_name=element_name_value,
                    primitive=_first_non_empty(props.get("cert-in:primitive"), props.get("primitive")),
                    mode=_first_non_empty(props.get("cert-in:mode"), props.get("mode")),
                    crypto_functions=crypto_functions_text,
                    classical_security_level=_first_int(props.get("cert-in:classical_security_level"), props.get("classical_security_level")),
                    oid=oid_value,
                    element_list=str(element_list_value or ""),
                    key_id=_first_non_empty(props.get("cert-in:id"), props.get("key_id")),
                    key_state=_first_non_empty(props.get("cert-in:state"), props.get("key_state")),
                    key_size=key_size_value,
                    key_creation_date=_first_dt(props.get("cert-in:creation_date"), props.get("key_creation_date")),
                    key_activation_date=_first_dt(props.get("cert-in:activation_date"), props.get("key_activation_date")),
                    protocol_name=protocol_name_value,
                    protocol_version_name=protocol_version_value,
                    cipher_suites=cipher_suites_value,
                    subject_name=subject_name_value,
                    issuer_name=issuer_name_value,
                    not_valid_before=_first_dt(props.get("cert-in:not_valid_before"), props.get("not_valid_before"), fallback_tls.get("valid_from")),
                    not_valid_after=_first_dt(props.get("cert-in:not_valid_after"), props.get("not_valid_after"), fallback_tls.get("valid_to")),
                    signature_algorithm_reference=signature_ref,
                    subject_public_key_reference=public_key_ref,
                    certificate_format=_first_non_empty(props.get("cert-in:format"), props.get("certificate_format"), "X.509" if asset_type == "certificate" else ""),
                    certificate_extension=cert_extension_value,
                    key_length=key_length_value,
                    protocol_version=protocol_version_value,
                    nist_status=_first_non_empty(props.get("cert-in:quantum_safe_status"), props.get("quantum_safe_status"), "Unknown"),
                    quantum_safe_flag=_boolish(props.get("cert-in:quantum_safe_status") or props.get("quantum-safe:is_quantum_safe")),
                    hndl_level=props.get("quantum-safe:risk_level", "Medium")
                )
                db_session.add(cbom_entry)

        if _db_table_exists("findings") and scan_pk is not None:
            db_session.flush()
            try:
                from src.services.finding_detection_service import FindingDetectionService

                finding_result = FindingDetectionService.detect_and_store_findings(
                    asset_id=asset_id,
                    scan_id=int(scan_pk),
                )
                report["finding_summary"] = finding_result
            except Exception as finding_exc:
                report["finding_summary"] = {
                    "created": 0,
                    "error": str(finding_exc),
                }

        if _db_table_exists("asset_metrics") and scan_pk is not None:
            try:
                from src.services.pqc_calculation_service import PQCCalculationService

                metric = PQCCalculationService.calculate_and_store_pqc_metrics(
                    asset_id=asset_id,
                    scan_id=int(scan_pk),
                    auto_commit=False,
                )
                report["pqc_metrics"] = {
                    "pqc_score": float(getattr(metric, "pqc_score", 0) or 0),
                    "pqc_class_tier": str(getattr(metric, "pqc_class_tier", "") or ""),
                    "asset_cyber_score": float(getattr(metric, "asset_cyber_score", 0) or 0),
                }
            except Exception as pqc_exc:
                report["pqc_metrics"] = {
                    "error": str(pqc_exc),
                }

            try:
                from src.services.risk_calculation_service import RiskCalculationService

                risk_result = RiskCalculationService.calculate_and_store_risk_metrics(
                    asset_id=asset_id,
                    scan_id=int(scan_pk),
                    auto_commit=False,
                )
                report["risk_metrics"] = risk_result
            except Exception as risk_exc:
                report["risk_metrics"] = {
                    "error": str(risk_exc),
                }

        if _db_table_exists("digital_labels") and scan_pk is not None:
            try:
                from src.services.digital_label_service import DigitalLabelService
                from src.services.subdomain_service import SubdomainService

                label_result = DigitalLabelService.calculate_and_store_digital_label(
                    asset_id=asset_id,
                    scan_id=int(scan_pk),
                    auto_commit=False,
                )
                report["digital_label"] = label_result

                # Subdomain Discovery Sync (Sprint 1 specialized model)
                sub_count = SubdomainService.sync_from_certificate(asset_id, int(scan_pk))
                report["subdomain_discovery"] = {"new_subdomains": sub_count}

                # Collect all related domains from TLS SANs + DNS (CNAME/MX) and
                # upsert them into discovery_domains so dashboards can surface them.
                if _db_table_exists("discovery_domains") and asset_id is not None:
                    try:
                        related_domains = _collect_related_domains(
                            target,
                            tls_results,
                            dns_records,
                        )
                        from src.models import DiscoveryDomain
                        for domain in related_domains:
                            existing = (
                                db_session.query(DiscoveryDomain)
                                .filter(
                                    DiscoveryDomain.domain == domain,
                                    DiscoveryDomain.asset_id == asset_id,
                                )
                                .first()
                            )
                            if not existing:
                                db_session.add(
                                    DiscoveryDomain(
                                        domain=domain,
                                        asset_id=asset_id,
                                        scan_id=int(scan_pk),
                                        is_deleted=False,
                                    )
                                )
                        db_session.flush()
                    except Exception as dom_exc:
                        logger.warning("discovery_domains upsert failed: %s", dom_exc)

            except Exception as label_exc:
                report["digital_label"] = {
                    "error": str(label_exc),
                }
        report["status"] = "complete"
        report["timestamp"] = datetime.now(timezone.utc).isoformat()

        if tls_results:
            primary_tls = tls_results[0]
            report["latest_certificate"] = {
                "subject_cn": primary_tls.get("subject_cn"),
                "issuer_cn": primary_tls.get("issuer_cn"),
                "fingerprint_sha256": primary_tls.get("fingerprint_sha256") or primary_tls.get("cert_sha256") or primary_tls.get("fingerprint"),
                "valid_until": primary_tls.get("valid_until"),
            }

        # --- SESSION AUDIT START ---
        from src.models import Certificate, Asset, Scan
        new_certs = [o for o in db_session.new if isinstance(o, Certificate)]
        new_assets = [o for o in db_session.new if isinstance(o, Asset)]
        new_scans = [o for o in db_session.new if isinstance(o, Scan)]
        session_audit = {
            "new_certificates_count": len(new_certs),
            "new_assets_count": len(new_assets),
            "new_scans_count": len(new_scans),
            "total_new_objects": len(db_session.new),
            "dirty_objects_count": len(db_session.dirty),
            "deleted_objects_count": len(db_session.deleted),
        }
        report["session_audit"] = session_audit
        # --- SESSION AUDIT END ---

        db_session.commit()
        report["orm_persisted"] = True
    except SQLAlchemyError as err:
        db_session.rollback()
        import traceback
        print(f"Failed to ingest native DB schema: {err}")
        traceback.print_exc()
        report["orm_persisted"] = False
        
    # Store in memory primarily for caching/legacy access if needed
    scan_store[scan_id] = report
    try:
        invalidate_dashboard_cache()
    except Exception:
        pass
    return report


# Expose scan runner for other modules (e.g., inventory background scans)
app.config["RUN_SCAN_PIPELINE_FUNC"] = run_scan_pipeline


# ── Routes ───────────────────────────────────────────────────────────

@app.route("/")
def root_index():
    """Redirects absolute root to the Main Dashboard."""
    return redirect(url_for('quantumshield_dashboard.dashboard_home'))



@app.route("/login", methods=["GET", "POST"])
@limiter.limit("100 per minute")
def login():
    """Secure login page — CSRF protected, rate-limited, lockout-aware."""
    if current_user.is_authenticated:
        return redirect(url_for('quantumshield_dashboard.dashboard_home'))

    locked = False

    if request.method == "POST":
        username = (request.form.get("username") or "").strip()
        password = request.form.get("password") or ""
        remember = bool(request.form.get("remember"))
        request_ip = _get_request_ip()

        user_data = db.get_user_by_username(username)

        # ── Lockout check ─────────────────────────────────────────
        if user_data and user_data.get("lockout_until") and datetime.now(timezone.utc).replace(tzinfo=None) < user_data["lockout_until"]:
            db.append_audit_log(
                event_category="auth",
                event_type="login_blocked_locked_account",
                status="denied",
                actor_user_id=user_data.get("id"),
                actor_username=username,
                ip_address=request_ip,
                user_agent=request.headers.get("User-Agent", "")[:512],
                request_method=request.method,
                request_path=request.path,
                details={
                    "lockout_until": user_data.get("lockout_until").isoformat() if user_data.get("lockout_until") else None,
                    "login_ip": request_ip,
                },
            )
            flash("Account temporarily locked due to repeated failed login attempts. Please try again later or use Forgot Password.", "error")
            locked = True
            return render_template("login.html", locked=locked)

        # ── Credential check ──────────────────────────────────────
        if user_data and check_password_hash(user_data["password_hash"], password):
            if not user_data.get("is_active", True):
                flash("Your account has been suspended. Contact an administrator.", "error")
                return render_template("login.html", locked=False)

            # Force password change first if required
            if user_data.get("must_change_password"):
                token = db.create_password_setup_token(user_data["id"], expires_hours=2)
                if token:
                    _audit("auth", "password_change_required", "success", target_user_id=user_data["id"], details={"reason": "must_change_password"})
                    flash("Please set a new password before continuing.", "warning")
                    return redirect(url_for("setup_password", token=token))

            # If 2FA is required by policy or already enabled for this user, defer full login
            if REQUIRE_2FA or user_data.get("two_factor_enabled"):
                # stash pre-2FA context and redirect to the appropriate 2FA flow
                session["pre_2fa_user_id"] = user_data["id"]
                session["pre_2fa_remember"] = remember
                session["pre_2fa_request_ip"] = request_ip

                _audit(
                    "auth",
                    "mfa_required",
                    "info",
                    target_user_id=user_data["id"],
                    details={"require_2fa": bool(REQUIRE_2FA), "two_factor_enabled": bool(user_data.get("two_factor_enabled"))},
                )

                if user_data.get("two_factor_enabled"):
                    return redirect(url_for("two_factor_login"))
                else:
                    return redirect(url_for("two_factor_setup"))

            # No 2FA required — complete login immediately
            db.mark_login_success(user_data["id"])
            user = User(user_data)
            session.clear()
            login_user(user, remember=remember)
            _audit(
                "auth",
                "login_success",
                "success",
                target_user_id=user_data["id"],
                details={"role": user.role, "remember": remember, "login_ip": request_ip},
            )

            return redirect(url_for('quantumshield_dashboard.dashboard_home'))
        else:
            if user_data:
                db.mark_login_failure(user_data["id"], MAX_LOGIN_ATTEMPTS, LOGIN_LOCKOUT_MINUTES)
            db.append_audit_log(
                event_category="auth",
                event_type="login_failed",
                status="failed",
                actor_user_id=user_data.get("id") if user_data else None,
                actor_username=username,
                ip_address=request_ip,
                user_agent=request.headers.get("User-Agent", "")[:512],
                request_method=request.method,
                request_path=request.path,
                details={"user_exists": bool(user_data), "login_ip": request_ip},
            )
            flash("Invalid credentials. Access denied.", "error")

    return render_template("login.html", locked=locked)


@app.route("/2fa/setup", methods=["GET", "POST"])
def two_factor_setup():
    """TOTP setup flow for users who have successfully passed password verification but need to enable 2FA.

    The pre-2FA context is stored in session['pre_2fa_user_id'] after password verification.
    """
    pre_id = session.get("pre_2fa_user_id")
    if not pre_id:
        flash("Session expired or invalid. Please log in again.", "error")
        return redirect(url_for("login"))

    user = db.get_user_by_id(pre_id)
    if not user:
        flash("User not found. Please log in again.", "error")
        return redirect(url_for("login"))

    if request.method == "GET":
        # Generate one-time secret and provisioning QR
        secret = pyotp.random_base32()
        session["pre_2fa_secret"] = secret
        issuer = "QuantumShield"
        name = user.get("email") or user.get("username") or user.get("id")
        uri = pyotp.totp.TOTP(secret).provisioning_uri(name=name, issuer_name=issuer)

        img = qrcode.make(uri)
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        png_b64 = base64.b64encode(buf.getvalue()).decode("utf-8")

        return render_template("setup_2fa.html", qr_image=f"data:image/png;base64,{png_b64}", secret=secret, user=user)

    # POST: verify the token and persist
    code = (request.form.get("otp") or (request.get_json(silent=True) or {}).get("otp"))
    secret = session.get("pre_2fa_secret")
    if not secret:
        flash("Setup session expired. Start setup again.", "error")
        return redirect(url_for("login"))

    totp = pyotp.TOTP(secret)
    if totp.verify(str(code or "").strip(), valid_window=1):
        # Create backup codes (show once)
        backup_plain = [secrets.token_hex(4) for _ in range(10)]
        hashed_entries = []
        for c in backup_plain:
            hashed_entries.append({"code_hash": hashlib.sha256(c.encode()).hexdigest(), "used": False})

        backup_json = json.dumps(hashed_entries)

        # Persist encrypted secret + backup codes
        if db.set_user_2fa(pre_id, secret, backup_json):
            # complete login
            db.mark_login_success(pre_id)
            user_data = db.get_user_by_id(pre_id)
            remember = bool(session.get("pre_2fa_remember", False))
            session.pop("pre_2fa_secret", None)
            session.pop("pre_2fa_user_id", None)
            session.pop("pre_2fa_remember", None)
            session.pop("pre_2fa_request_ip", None)
            session.clear()
            login_user(User(user_data), remember=remember)
            _audit("auth", "2fa_enabled", "success", target_user_id=pre_id)
            # Show backup codes to user once
            return render_template("show_backup_codes.html", backup_codes=backup_plain)

        flash("Failed to enable 2FA. Try again or contact admin.", "error")
        return redirect(url_for("login"))


@app.route("/2fa/login", methods=["GET", "POST"])
@limiter.limit("10 per minute")
def two_factor_login():
    """Verify TOTP during login for users who have two_factor_enabled.

    Expects session['pre_2fa_user_id'] to be set by the initial password check.
    """
    pre_id = session.get("pre_2fa_user_id")
    if not pre_id:
        flash("Session expired. Please log in again.", "error")
        return redirect(url_for("login"))

    user = db.get_user_by_id(pre_id)
    if not user:
        flash("User not found. Please log in again.", "error")
        return redirect(url_for("login"))

    if request.method == "GET":
        return render_template("two_factor_login.html", user=user)

    code = (request.form.get("otp") or (request.get_json(silent=True) or {}).get("otp"))
    # Attempt TOTP verification
    enc_secret = user.get("two_factor_secret")
    secret = db._decrypt_data(enc_secret) if enc_secret else None
    ok = False
    if secret:
        totp = pyotp.TOTP(secret)
        ok = totp.verify(str(code or "").strip(), valid_window=1)

    if ok:
        db.mark_login_success(pre_id)
        user_data = db.get_user_by_id(pre_id)
        remember = bool(session.get("pre_2fa_remember", False))
        session.pop("pre_2fa_user_id", None)
        session.pop("pre_2fa_remember", None)
        session.pop("pre_2fa_request_ip", None)
        session.clear()
        login_user(User(user_data), remember=remember)
        _audit("auth", "login_success_2fa", "success", target_user_id=pre_id)
        return redirect(url_for('quantumshield_dashboard.dashboard_home'))

    # If TOTP failed, allow backup code usage
    enc_backup = user.get("backup_codes")
    used_backup = False
    if enc_backup:
        try:
            dec = db._decrypt_data(enc_backup)
            backup_list = json.loads(dec or "[]")
            provided_hash = hashlib.sha256(str(code or "").encode()).hexdigest()
            for entry in backup_list:
                if isinstance(entry, dict) and entry.get("code_hash") == provided_hash and not entry.get("used"):
                    # mark used and persist
                    if db.mark_backup_code_used(pre_id, provided_hash):
                        used_backup = True
                        break
        except Exception:
            used_backup = False

    if used_backup:
        db.mark_login_success(pre_id)
        user_data = db.get_user_by_id(pre_id)
        remember = bool(session.get("pre_2fa_remember", False))
        session.pop("pre_2fa_user_id", None)
        session.pop("pre_2fa_remember", None)
        session.pop("pre_2fa_request_ip", None)
        session.clear()
        login_user(User(user_data), remember=remember)
        _audit("auth", "login_success_backup_code", "success", target_user_id=pre_id)
        flash("Logged in using backup code. That code is now invalid.", "warning")
        return redirect(url_for('quantumshield_dashboard.dashboard_home'))

    # Failed verification
    db.mark_login_failure(pre_id, MAX_LOGIN_ATTEMPTS, LOGIN_LOCKOUT_MINUTES)
    flash("Invalid authentication code. Try again.", "error")
    return redirect(url_for("two_factor_login"))


@app.route("/forgot-password", methods=["GET", "POST"])
@limiter.limit("3 per minute")
def forgot_password():
    """Email-based password reset flow."""
    if current_user.is_authenticated:
        return redirect(url_for('quantumshield_dashboard.dashboard_home'))

    if request.method == "POST":
        email = (request.form.get("email") or "").strip().lower()
        if not email:
            flash("Please enter an email address.", "error")
            return render_template("forgot_password.html")

        # Always show success message (prevent user enumeration)
        flash("If an account with that email exists, a password reset link has been sent.", "success")
        _audit("auth", "password_reset_requested", "success", details={"email": email})

        # Check if user exists with this email
        user_data = db.get_user_by_email(email)
        if user_data:
            token = db.create_password_setup_token(user_data["id"], expires_hours=2)
            if token:
                reset_link = _build_setup_link(token)
                try:
                    from flask_mail import Message as MailMessage
                    msg = MailMessage(
                        subject="QuantumShield — Password Reset",
                        recipients=[email],
                        body=f"""Hello {user_data.get('username', 'user')},

A password reset was requested for your QuantumShield account.

Click the link below to set a new password (valid for 2 hours):
{reset_link}

If you did not request this, please ignore this email.

— QuantumShield Security System
""",
                    )
                    mail.send(msg)
                    _audit("auth", "password_reset_email_sent", "success",
                           target_user_id=user_data["id"],
                           details={"email": email})
                except Exception as exc:
                    logger.error("Failed to send password reset email: %s", exc)
                    _audit("auth", "password_reset_email_failed", "failed",
                           target_user_id=user_data["id"],
                           details={"error": str(exc)[:200]})
                    # If mail fails, flash the link directly (dev environments)
                    if DEBUG:
                        flash(f"(DEV) Reset link: {reset_link}", "warning")

        return render_template("forgot_password.html")

    return render_template("forgot_password.html")


@app.route("/logout", methods=["GET", "POST"])
@login_required
def logout():
    """Logout current user."""
    _audit("auth", "logout", "success")
    logout_user()
    session.clear()
    return redirect(url_for('login'))


@app.route("/admin/theme", methods=["GET", "POST"])
@role_required(list(ADMIN_PANEL_ROLES))
def admin_theme():
    """Admin panel to configure dynamic UI theme colors."""
    current_theme = load_theme()
    if request.method == "POST":
        requested_theme = {
            "mode": request.form.get("mode", current_theme.get("mode", "system")),
            "dark": {
                "bg_navbar": request.form.get("dark_bg_navbar", current_theme["dark"]["bg_navbar"]),
                "bg_primary": request.form.get("dark_bg_primary", current_theme["dark"]["bg_primary"]),
                "bg_secondary": request.form.get("dark_bg_secondary", current_theme["dark"]["bg_secondary"]),
                "bg_card": request.form.get("dark_bg_card", current_theme["dark"]["bg_card"]),
                "bg_input": request.form.get("dark_bg_input", current_theme["dark"]["bg_input"]),
                "border_subtle": request.form.get("dark_border_subtle", current_theme["dark"]["border_subtle"]),
                "border_hover": request.form.get("dark_border_hover", current_theme["dark"]["border_hover"]),
                "text_primary": request.form.get("dark_text_primary", current_theme["dark"]["text_primary"]),
                "text_secondary": request.form.get("dark_text_secondary", current_theme["dark"]["text_secondary"]),
                "text_muted": request.form.get("dark_text_muted", current_theme["dark"]["text_muted"]),
                "accent_color": request.form.get("dark_accent_color", current_theme["dark"]["accent_color"]),
                "safe": request.form.get("dark_safe", current_theme["dark"]["safe"]),
                "warn": request.form.get("dark_warn", current_theme["dark"]["warn"]),
                "danger": request.form.get("dark_danger", current_theme["dark"]["danger"]),
            },
            "light": {
                "bg_navbar": request.form.get("light_bg_navbar", current_theme["light"]["bg_navbar"]),
                "bg_primary": request.form.get("light_bg_primary", current_theme["light"]["bg_primary"]),
                "bg_secondary": request.form.get("light_bg_secondary", current_theme["light"]["bg_secondary"]),
                "bg_card": request.form.get("light_bg_card", current_theme["light"]["bg_card"]),
                "bg_input": request.form.get("light_bg_input", current_theme["light"]["bg_input"]),
                "border_subtle": request.form.get("light_border_subtle", current_theme["light"]["border_subtle"]),
                "border_hover": request.form.get("light_border_hover", current_theme["light"]["border_hover"]),
                "text_primary": request.form.get("light_text_primary", current_theme["light"]["text_primary"]),
                "text_secondary": request.form.get("light_text_secondary", current_theme["light"]["text_secondary"]),
                "text_muted": request.form.get("light_text_muted", current_theme["light"]["text_muted"]),
                "accent_color": request.form.get("light_accent_color", current_theme["light"]["accent_color"]),
                "safe": request.form.get("light_safe", current_theme["light"]["safe"]),
                "warn": request.form.get("light_warn", current_theme["light"]["warn"]),
                "danger": request.form.get("light_danger", current_theme["light"]["danger"]),
            },
        }

        action_taken = "save_custom_theme"
        quick_mode = str(request.form.get("quick_mode") or "").strip().lower()
        reset_palette = str(request.form.get("reset_palette") or "").strip().lower()

        if request.form.get("reset_colors"):
            requested_theme = {
                "mode": "system",
                "dark": dict(THEME_DEFAULTS["dark"]),
                "light": dict(THEME_DEFAULTS["light"]),
            }
            action_taken = "reset_all_defaults"
        elif reset_palette in {"dark", "light"}:
            requested_theme[reset_palette] = dict(THEME_DEFAULTS[reset_palette])
            # Operator intent: resetting a palette should immediately preview that mode.
            requested_theme["mode"] = reset_palette
            action_taken = f"reset_{reset_palette}_defaults"

        if quick_mode in {"dark", "light", "system"}:
            requested_theme["mode"] = quick_mode
            action_taken = f"quick_switch_{quick_mode}"

        new_theme = _sanitize_theme(requested_theme)
        try:
            with open(THEME_FILE, 'w') as f:
                json.dump(new_theme, f, indent=4)
            _audit("admin", "update_theme", "success", details={"mode": new_theme.get("mode"), "action": action_taken})
            flash("Theme settings saved successfully.", "success")
        except Exception as e:
            _audit("admin", "update_theme_failed", "failed", details={"error": str(e)})
            flash(f"Failed to save theme: {e}", "danger")
        return redirect(url_for('admin_theme'))
        
    return render_template("admin_theme.html", theme=current_theme, section_title="Theme configuration")

@app.route("/admin/users", methods=["GET", "POST"])
@role_required(list(ADMIN_PANEL_ROLES))
def admin_users():
    """Admin panel to manage users and send setup invites."""
    if request.method == "POST":
        employee_id = (request.form.get("employee_id") or "").strip()
        email = (request.form.get("email") or "").strip().lower()
        username = (request.form.get("username") or "").strip()
        role = db.normalize_role(request.form.get("role") or "Viewer")

        if not employee_id or not email or not username:
            _audit("admin", "create_user_validation_failed", "failed", details={"has_employee_id": bool(employee_id), "has_email": bool(email), "has_username": bool(username)})
            flash("Employee ID, email, and username are required.", "error")
            return redirect(url_for("admin_users"))

        temp_password = uuid.uuid4().hex
        invited_user_id = db.create_invited_user(
            employee_id=employee_id,
            username=username,
            email=email,
            role=role,
            created_by=current_user.id,
            password_hash=generate_password_hash(temp_password),
        )

        if not invited_user_id:
            _audit("admin", "create_user", "failed", details={"email": email, "username": username, "employee_id": employee_id, "role": role})
            flash("Failed to create user. Check for duplicate username/email/employee ID.", "error")
            return redirect(url_for("admin_users"))

        token = db.create_password_setup_token(invited_user_id, expires_hours=24)
        if not token:
            _audit("admin", "create_user_token", "failed", target_user_id=invited_user_id, details={"email": email})
            flash("User created, but setup token generation failed.", "warning")
            return redirect(url_for("admin_users"))

        setup_url = _build_setup_link(token)

        try:
            ok, reason = _smtp_preflight_check()
            if not ok:
                raise RuntimeError(reason)
            msg = Message("Welcome to QuantumShield - Setup Your Password", recipients=[email])
            msg.body = (
                "Hello,\n\n"
                f"Your QuantumShield account has been created by admin.\n"
                f"Employee ID: {employee_id}\n"
                f"Username: {username}\n"
                f"Role: {role}\n\n"
                "Use the secure link below to set your password:\n"
                f"{setup_url}\n\n"
                "This link expires in 24 hours and can only be used once."
            )
            mail.send(msg)
            _audit("admin", "create_user", "success", target_user_id=invited_user_id, details={"email": email, "username": username, "employee_id": employee_id, "role": role, "email_sent": True})
            flash(f"User {username} invited successfully. Setup email sent.", "success")
        except Exception as exc:
            diag = _smtp_failure_message(exc)
            logger.error("Failed to send setup email to %s: %s", email, diag)
            _audit("admin", "create_user", "partial", target_user_id=invited_user_id, details={"email": email, "username": username, "role": role, "email_sent": False, "error": str(exc), "smtp_diagnostic": diag})
            flash(f"User created, but setup email could not be delivered. {diag} Temporary setup link: {setup_url}", "warning")

        return redirect(url_for("admin_users"))

    users = db.list_users()
    return render_template("admin_users.html", users=users)


@app.route("/admin/audit")
@role_required(list(ADMIN_PANEL_ROLES))
def admin_audit_logs():
    logs = db.list_audit_logs(limit=AUDIT_LOG_PAGE_SIZE)
    is_valid, issues = db.verify_audit_log_chain(limit=max(AUDIT_LOG_PAGE_SIZE, 500))
    return render_template("admin_audit.html", logs=logs, chain_valid=is_valid, chain_issues=issues)


@app.route("/admin/audit/export", methods=["POST"])
@role_required(list(ADMIN_PANEL_ROLES))
def admin_audit_logs_export():
    """Admin-only encrypted export of immutable audit chain records."""
    payload = request.get_json(silent=True) if request.is_json else request.form
    payload = payload or {}
    password = str(payload.get("password") or "").strip()
    try:
        limit = int(payload.get("limit") or max(AUDIT_LOG_PAGE_SIZE, 1000))
    except (TypeError, ValueError):
        limit = max(AUDIT_LOG_PAGE_SIZE, 1000)
    limit = max(100, min(limit, 50000))

    if len(password) < 12:
        message = "Password is required and must be at least 12 characters."
        if request.is_json:
            return jsonify({"status": "error", "message": message}), 400
        flash(message, "error")
        return redirect(url_for("admin_audit_logs"))

    logs = db.list_audit_logs(limit=limit)
    chain_valid, issues = db.verify_audit_log_chain(limit=max(limit, 500))
    exported_by = str(getattr(current_user, "username", "admin") or "admin")

    try:
        encrypted_blob = _build_encrypted_audit_export_blob(
            logs=logs,
            chain_valid=chain_valid,
            chain_issues=issues,
            password=password,
            exported_by=exported_by,
        )
    except Exception as exc:
        _audit("admin", "audit_export_encrypted", "failed", details={"error": str(exc)[:200], "limit": limit})
        if request.is_json:
            return jsonify({"status": "error", "message": "Failed to generate encrypted export."}), 500
        flash("Failed to generate encrypted export.", "error")
        return redirect(url_for("admin_audit_logs"))

    _audit(
        "admin",
        "audit_export_encrypted",
        "success",
        details={
            "limit": limit,
            "record_count": len(logs),
            "chain_valid": bool(chain_valid),
        },
    )

    filename = f"audit_export_encrypted_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.json"
    return Response(
        encrypted_blob,
        status=200,
        mimetype="application/json",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "Content-Length": str(len(encrypted_blob)),
            "X-Audit-Encrypted": "true",
        },
    )


@app.route("/admin/api", methods=["GET"])
@role_required(list(ADMIN_PANEL_ROLES))
def admin_api():
    """Admin API portal for key management and integration guidance."""
    user_data = db.get_user_by_id(current_user.id)
    key_issued = db.has_api_key(current_user.id)
    return render_template("admin_api.html", user=user_data, key_issued=key_issued)


@app.route("/admin/api/rotate-key", methods=["POST"])
@role_required(list(ADMIN_PANEL_ROLES))
def admin_rotate_api_key():
    """Rotate the current admin user's API key from the admin API portal."""
    db.revoke_api_key(current_user.id)
    new_key = db.generate_api_key(current_user.id)
    if new_key:
        _audit("admin", "api_key_rotated", "success", target_user_id=current_user.id)
        flash(f"NEW_API_KEY: {new_key}", "api_key")
    else:
        _audit("admin", "api_key_rotated", "failed", target_user_id=current_user.id)
        flash("Failed to rotate API key. Try again.", "error")
    return redirect(url_for("admin_api"))


@app.route("/admin/users/<user_id>/reset-password", methods=["POST"])
@role_required(list(ADMIN_PANEL_ROLES))
def admin_reset_user_password(user_id: str):
    """Admin-triggered password reset email for an existing user. Supports form OR JSON."""
    wants_json = _expects_json_response()
    
    user = db.get_user_by_id(user_id)
    if not user:
        _audit("admin", "reset_password", "failed", target_user_id=user_id, details={"reason": "user_not_found"})
        if wants_json:
            return jsonify({"status": "error", "message": "User not found or inactive."}), 404
        flash("User not found or inactive.", "error")
        return redirect(url_for("admin_users"))
    if not user.get("email"):
        _audit("admin", "reset_password", "failed", target_user_id=user_id, details={"reason": "missing_email"})
        if wants_json:
            return jsonify({"status": "error", "message": "User has no email configured."}), 400
        flash("User has no email configured.", "error")
        return redirect(url_for("admin_users"))

    token = db.create_password_setup_token(user_id, expires_hours=24)
    if not token:
        _audit("admin", "reset_password", "failed", target_user_id=user_id, details={"reason": "token_generation_failed"})
        if wants_json:
            return jsonify({"status": "error", "message": "Failed to generate reset token."}), 500
        flash("Failed to generate reset token.", "error")
        return redirect(url_for("admin_users"))

    setup_url = _build_setup_link(token)
    try:
        ok, reason = _smtp_preflight_check()
        if not ok:
            raise RuntimeError(reason)
        msg = Message("QuantumShield Password Reset", recipients=[user["email"]])
        msg.body = (
            "Hello,\n\n"
            f"A password reset was initiated by admin for username: {user['username']}\n\n"
            "Use this secure one-time link to set a new password:\n"
            f"{setup_url}\n\n"
            "This link expires in 24 hours."
        )
        mail.send(msg)
        _audit("admin", "reset_password", "success", target_user_id=user_id, details={"email": user["email"], "email_sent": True})
        if wants_json:
            return jsonify({
                "status": "success",
                "message": "Password reset email sent.",
                "user_id": user_id,
                "username": user["username"]
            }), 200
        flash("Password reset email sent.", "success")
    except Exception as exc:
        diag = _smtp_failure_message(exc)
        logger.error("Password reset email failed for %s: %s", user["email"], diag)
        _audit("admin", "reset_password", "partial", target_user_id=user_id, details={"email": user["email"], "email_sent": False, "error": str(exc), "smtp_diagnostic": diag})
        if wants_json:
            return jsonify({
                "status": "partial",
                "message": f"{diag}",
                "setup_url": setup_url,
            }), 200
        flash(f"Email not delivered. {diag} Temporary setup link: {setup_url}", "warning")
    return redirect(url_for("admin_users"))


@app.route("/admin/users/<user_id>/reset-2fa", methods=["POST"])
@role_required(list(ADMIN_PANEL_ROLES))
def admin_reset_user_2fa(user_id: str):
    """Admin endpoint to clear a user's 2FA configuration so they must re-setup on next login."""
    wants_json = _expects_json_response()

    user = db.get_user_by_id(user_id)
    if not user:
        _audit("admin", "reset_2fa", "failed", target_user_id=user_id, details={"reason": "user_not_found"})
        if wants_json:
            return jsonify({"status": "error", "message": "User not found."}), 404
        flash("User not found.", "error")
        return redirect(url_for("admin_users"))

    if not db.reset_user_2fa(user_id):
        _audit("admin", "reset_2fa", "failed", target_user_id=user_id, details={"reason": "db_update_failed"})
        if wants_json:
            return jsonify({"status": "error", "message": "Failed to reset 2FA."}), 500
        flash("Failed to reset 2FA.", "error")
        return redirect(url_for("admin_users"))

    _audit("admin", "reset_2fa", "success", target_user_id=user_id, details={"initiated_by": current_user.id})
    if wants_json:
        return jsonify({"status": "success", "message": "2FA reset."}), 200
    flash("2FA reset for user.", "success")
    return redirect(url_for("admin_users"))


@app.route("/admin/users/<user_id>/update", methods=["POST"])
@role_required(list(ADMIN_PANEL_ROLES))
def admin_update_user(user_id: str):
    """Update user role and active status. Supports form OR JSON."""
    wants_json = _expects_json_response()
    
    if request.is_json:
        data = request.get_json() or {}
        role = db.normalize_role(data.get("role") or "Viewer")
        is_active = data.get("is_active", True)
        email = str(data.get("email") or "").strip().lower()
    else:
        role = db.normalize_role(request.form.get("role") or "Viewer")
        is_active = request.form.get("is_active") == "on"
        email = str(request.form.get("email") or "").strip().lower()

    if not email:
        _audit("admin", "update_user", "failed", target_user_id=user_id, details={"reason": "missing_email", "role": role, "is_active": bool(is_active)})
        if wants_json:
            return jsonify({"status": "error", "message": "Email is required."}), 400
        flash("Email is required.", "error")
        return redirect(url_for("admin_users"))

    if not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", email):
        _audit("admin", "update_user", "failed", target_user_id=user_id, details={"reason": "invalid_email_format", "role": role, "is_active": bool(is_active), "email": email})
        if wants_json:
            return jsonify({"status": "error", "message": "Invalid email format."}), 400
        flash("Invalid email format.", "error")
        return redirect(url_for("admin_users"))

    existing = db.get_user_by_email(email)
    if existing and str(existing.get("id") or "") != str(user_id):
        _audit("admin", "update_user", "failed", target_user_id=user_id, details={"reason": "duplicate_email", "role": role, "is_active": bool(is_active), "email": email})
        if wants_json:
            return jsonify({"status": "error", "message": "Email is already used by another user."}), 409
        flash("Email is already used by another user.", "error")
        return redirect(url_for("admin_users"))
    
    if db.update_user_profile(user_id, role=role, is_active=is_active, email=email):
        _audit("admin", "update_user", "success", target_user_id=user_id, details={"role": role, "is_active": is_active, "email": email})
        if wants_json:
            return jsonify({
                "status": "success",
                "message": "User profile updated.",
                "user_id": user_id,
                "role": role,
                "is_active": is_active,
                "email": email,
            }), 200
        flash("User profile updated.", "success")
    else:
        _audit("admin", "update_user", "failed", target_user_id=user_id, details={"role": role, "is_active": is_active, "email": email})
        if wants_json:
            return jsonify({"status": "error", "message": "Failed to update user profile."}), 500
        flash("Failed to update user profile.", "error")
    return redirect(url_for("admin_users"))


@app.route("/admin/users/bulk", methods=["POST"])
@role_required(list(ADMIN_PANEL_ROLES))
def admin_bulk_users():
    """Bulk user management endpoint for role updates and deletion."""
    data = request.get_json(silent=True) or {}
    action = str(data.get("action") or "").strip().lower()
    raw_user_ids = data.get("user_ids")

    if not isinstance(raw_user_ids, list):
        return jsonify({"status": "error", "message": "'user_ids' must be an array."}), 400

    user_ids = [str(uid).strip() for uid in raw_user_ids if str(uid).strip()]
    if not user_ids:
        return jsonify({"status": "error", "message": "Select at least one user."}), 400

    current_uid = str(getattr(current_user, "id", "") or "").strip()
    protected_ids = [uid for uid in user_ids if uid == current_uid]

    if action == "update_role":
        role = db.normalize_role(data.get("role") or "Viewer")
        updated_count = db.bulk_update_user_role(user_ids, role=role)
        _audit(
            "admin",
            "bulk_update_user_role",
            "success",
            details={"updated_count": updated_count, "requested_count": len(user_ids), "role": role},
        )
        return jsonify(
            {
                "status": "success",
                "message": f"Updated role for {updated_count} user(s).",
                "updated_count": int(updated_count),
                "role": role,
            }
        ), 200

    if action == "delete":
        deletable_ids = [uid for uid in user_ids if uid != current_uid]
        deleted_count = db.bulk_delete_users(deletable_ids)
        _audit(
            "admin",
            "bulk_delete_users",
            "success",
            details={
                "deleted_count": deleted_count,
                "requested_count": len(user_ids),
                "protected_count": len(protected_ids),
            },
        )
        if protected_ids:
            return jsonify(
                {
                    "status": "success",
                    "message": "Bulk delete completed. Logged-in user was protected from deletion.",
                    "deleted_count": int(deleted_count),
                    "protected_ids": protected_ids,
                }
            ), 200

        return jsonify(
            {
                "status": "success",
                "message": f"Deleted {deleted_count} user(s).",
                "deleted_count": int(deleted_count),
            }
        ), 200

    return jsonify({"status": "error", "message": "Invalid bulk action. Use 'update_role' or 'delete'."}), 400


@app.route("/setup-password/<token>", methods=["GET", "POST"])
@app.route("/SETUP-PASSWORD/<token>", methods=["GET", "POST"])  # Accept uppercase variant (user typo/paste tolerance)
def setup_password(token):
    """Secure link to allow new users to set their password."""
    user_data = db.get_user_by_setup_token(token)
    if not user_data:
        db.append_audit_log(
            event_category="auth",
            event_type="password_setup_invalid_token",
            status="failed",
            ip_address=_get_request_ip(),
            user_agent=request.headers.get("User-Agent", "")[:512],
            request_method=request.method,
            request_path=request.path,
            details={},
        )
        flash("The setup link is invalid or has expired.", "error")
        return redirect(url_for('login'))

    if request.method == "POST":
        password = request.form.get("password") or ""
        confirm_password = request.form.get("confirm_password") or ""

        is_valid, message = _validate_password_strength(password)
        if not is_valid:
            _audit("auth", "password_setup", "failed", target_user_id=user_data["id"], details={"reason": message})
            flash(message, "error")
            return render_template("setup_password.html", token=token)
        if password != confirm_password:
            _audit("auth", "password_setup", "failed", target_user_id=user_data["id"], details={"reason": "confirmation_mismatch"})
            flash("Password and confirmation do not match.", "error")
            return render_template("setup_password.html", token=token)

        if db.set_user_password(user_data["id"], generate_password_hash(password)):
            db.append_audit_log(
                event_category="auth",
                event_type="password_setup_completed",
                status="success",
                actor_user_id=user_data["id"],
                actor_username=user_data.get("username"),
                target_user_id=user_data["id"],
                ip_address=_get_request_ip(),
                user_agent=request.headers.get("User-Agent", "")[:512],
                request_method=request.method,
                request_path=request.path,
                details={},
            )
            flash("Password set successfully. You can now log in.", "success")
            return redirect(url_for('login'))

        _audit("auth", "password_setup", "failed", target_user_id=user_data["id"], details={"reason": "database_update_failed"})
        flash("Failed to update password.", "error")

    return render_template("setup_password.html", token=token)



@dashboard_bp.route("/")
@login_required
def index():
    """Scanner dashboard with enterprise metrics directly populated from DB view aggregate for performance."""
    recent_scans = db.list_scans(limit=10)

    from src.services.asset_service import AssetService

    asset_svc = AssetService()
    assets = asset_svc.load_combined_assets()
    summary = asset_svc.get_dashboard_summary(assets)

    if not summary or summary.get("total_assets", 0) == 0:
        logger.info("AssetService summary empty. Falling back to MySQL enterprise metrics.")
        summary = db.get_enterprise_metrics()
        assets = asset_svc.load_combined_assets()

    summary = {
        **summary,
        "latest_scan": summary.get("latest_scan") or (recent_scans[0].get("scanned_at") if recent_scans else "Never"),
    }

    return render_template(
        "home.html",
        recent_scans=recent_scans,
        assets=assets,
        summary=summary,
        enterprise_metrics=summary,
    )

# Register Main Dashboard Blueprint
from web.blueprints.dashboard import dashboard_bp
from web.routes.assets import assets_bp
from web.routes.dashboard_api import api_dashboards_bp
from web.routes.scans import scans_bp
from web.blueprints.api_blueprint_init import register_api_blueprints

app.register_blueprint(dashboard_bp)
app.register_blueprint(assets_bp)
app.register_blueprint(api_dashboards_bp)
app.register_blueprint(scans_bp)

# Register all API blueprints (API-first refactor V2)
register_api_blueprints(app)

# Inventory status polling runs frequently from UI; keep it outside tight default limits.
if "quantumshield_dashboard.inventory_scan_status" in app.view_functions:
    limiter.limit("2000 per hour")(app.view_functions["quantumshield_dashboard.inventory_scan_status"])




@app.route("/scan-center")
@role_required(list(SCAN_ROLES))
def scan_center():
    """Legacy scan center route preserved for compatibility tests/links."""
    user_role = str(getattr(current_user, "role", "") or "").strip().title()
    can_bulk_scan = user_role in {r.strip().title() for r in BULK_SCAN_ROLES}
    return render_template(
        "scans.html",
        can_single_scan=True,
        can_bulk_scan=can_bulk_scan,
    )


def _score_to_risk(score: float) -> str:
    if score >= 700:
        return "Low"
    if score >= 400:
        return "Medium"
    if score >= 200:
        return "High"
    return "Critical"


def _iso_date(value: str) -> str:
    if not value:
        return ""
    return str(value)[:10]


def _host_from_target(target: str) -> str:
    raw = str(target or "").strip()
    if not raw:
        return ""
    if "://" in raw:
        raw = raw.split("://", 1)[1]
    return raw.split("/", 1)[0].split(":", 1)[0]


def _build_asset_inventory_view() -> dict:
    """Build inventory view-model from MySQL tables only."""
    from src.services.asset_service import AssetService

    service = AssetService()
    return service.get_inventory_view_model(testing_mode=app.config.get("TESTING", False))


def _build_asset_discovery_view(
    include_in_progress: bool = False,
    page: int = 1,
    page_size: int = 100,
    search_term: str = "",
) -> dict:
    """Build discovery view from persisted scan table data (with testing fallback)."""
    from collections import Counter
    import ipaddress
    from src.db import db_session
    from src.models import Asset, Scan as ScanModel

    testing_mode = app.config.get("TESTING", False)
    domains: list[dict] = []
    ssl: list[dict] = []
    ip_subnets: list[dict] = []
    software: list[dict] = []
    nodes: list[dict] = []
    edges: list[dict] = []

    node_ids: set[str] = set()
    edge_ids: set[str] = set()
    normalized_search = str(search_term or "").strip().lower()

    try:
        known_assets = {
            str(getattr(a, "name", "") or "").strip().lower()
            for a in db_session.query(Asset).filter(Asset.is_deleted == False).all()
            if str(getattr(a, "name", "") or "").strip()
        }
    except Exception as exc:
        logger.warning("Asset discovery known-asset load failed: %s", exc)
        known_assets = set()

    def add_node(node_id: str, label: str, group: str, title: str) -> None:
        if node_id in node_ids:
            return
        node_ids.add(node_id)
        nodes.append({"id": node_id, "label": label, "group": group, "title": title})

    def add_edge(src: str, dst: str) -> None:
        key = f"{src}->{dst}"
        if key in edge_ids:
            return
        edge_ids.add(key)
        edges.append({"id": key, "from": src, "to": dst})

    scans_feed = []
    if testing_mode:
        for scan in scan_store.values():
            if isinstance(scan, dict):
                scans_feed.append(scan)
    else:
        try:
            offset = max(page - 1, 0) * page_size
            rows = (
                db_session.query(ScanModel)
                .filter(ScanModel.is_deleted == False)
                .order_by(ScanModel.started_at.desc(), ScanModel.id.desc())
                .offset(offset)
                .limit(page_size)
                .all()
            )
            for scan_row in rows:
                row_status = str(getattr(scan_row, "status", "") or "").strip().lower()
                if row_status != "complete" and not include_in_progress:
                    continue
                target = str(getattr(scan_row, "target", "") or "").strip()
                if not target:
                    continue
                report_payload = {}
                raw_report = getattr(scan_row, "report_json", None)
                if isinstance(raw_report, str) and raw_report.strip().startswith("{"):
                    try:
                        parsed = json.loads(raw_report)
                        report_payload = parsed if isinstance(parsed, dict) else {}
                    except Exception:
                        report_payload = {}
                scans_feed.append(
                    {
                        "scan_id": str(getattr(scan_row, "scan_id", "") or getattr(scan_row, "id", "")),
                        "target": target,
                        "status": str(getattr(scan_row, "status", "") or ""),
                        "generated_at": (
                            getattr(scan_row, "scanned_at", None)
                            or getattr(scan_row, "completed_at", None)
                            or getattr(scan_row, "started_at", None)
                        ).isoformat()
                        if (
                            getattr(scan_row, "scanned_at", None)
                            or getattr(scan_row, "completed_at", None)
                            or getattr(scan_row, "started_at", None)
                        )
                        else "",
                        "discovered_services": report_payload.get("discovered_services", []),
                        "tls_results": report_payload.get("tls_results", []),
                    }
                )
        except Exception as exc:
            logger.warning("Asset discovery DB scan load failed: %s", exc)

    for scan in scans_feed:
        if scan.get("status") != "complete" and not include_in_progress:
            continue

        target = str(scan.get("target", "")).strip().lower()
        
        # Only show discovery details of the asset added to the asset inventory
        if not testing_mode and target not in known_assets:
            # Also try matching host
            host = _host_from_target(target)
            if host not in known_assets:
                continue

        host = _host_from_target(target)
        if not host:
            continue

        detection_date = _iso_date(str(scan.get("generated_at", "")))
        add_node(f"domain:{host}", host, "domain", f"Domain · {host}")

        is_inventoried = (host in known_assets) or (target in known_assets)

        domains.append(
            {
                "status": "Confirmed" if scan.get("status") == "complete" else "New",
                "detection_date": detection_date,
                "domain_name": host,
                "registration_date": "",
                "registrar": "",
                "company": "Internal" if is_inventoried else "External",
                "is_inventoried": is_inventoried,
            }
        )

        discovered_services = scan.get("discovered_services") or []
        tls_results = scan.get("tls_results") or []

        for svc in discovered_services:
            svc_host = str(svc.get("host", "")).strip()
            port = svc.get("port")
            service_name = str(svc.get("service", "unknown"))
            banner = str(svc.get("banner", ""))

            if svc_host:
                try:
                    parsed = ipaddress.ip_address(svc_host)
                    geo = _geolocate_ip(svc_host) if parsed.version == 4 else {}
                    location_text = ", ".join(
                        part
                        for part in (
                            str(geo.get("city") or "").strip(),
                            str(geo.get("region") or "").strip(),
                            str(geo.get("country") or "").strip(),
                        )
                        if part
                    )
                    subnet = f"{svc_host}/32" if parsed.version == 4 else f"{svc_host}/128"
                    ip_subnets.append(
                        {
                            "status": "Confirmed" if scan.get("status") == "complete" else "New",
                            "detection_date": detection_date,
                            "ip": svc_host,
                            "ports": str(port or ""),
                            "subnet": subnet,
                            "asn": "",
                            "netname": "",
                            "location": location_text,
                            "lat": geo.get("lat"),
                            "lon": geo.get("lon"),
                            "company": "Internal" if is_inventoried else "External",
                            "is_inventoried": is_inventoried,
                        }
                    )
                    add_node(f"ip:{svc_host}", svc_host, "ip", f"IP · {svc_host}")
                    add_edge(f"domain:{host}", f"ip:{svc_host}")
                    if port:
                        add_node(
                            f"service:{svc_host}:{port}",
                            f"{service_name.upper()}:{port}",
                            "service",
                            f"Service · {service_name}:{port}",
                        )
                        add_edge(f"ip:{svc_host}", f"service:{svc_host}:{port}")
                except ValueError:
                    pass

            if banner:
                version = ""
                if "/" in banner:
                    pieces = banner.split("/", 1)
                    service_name = pieces[0] or service_name
                    version = pieces[1]
                software.append(
                    {
                        "status": "Confirmed" if scan.get("status") == "complete" else "New",
                        "detection_date": detection_date,
                        "product": service_name,
                        "version": version,
                        "type": "Service",
                        "port": port or "",
                        "host": host,
                        "company": "Internal" if is_inventoried else "External",
                        "is_inventoried": is_inventoried,
                    }
                )

        for tr in tls_results:
            fingerprint = str(tr.get("cert_sha256") or tr.get("fingerprint") or "")
            issuer = tr.get("issuer") if isinstance(tr.get("issuer"), dict) else {}
            ssl.append(
                {
                    "status": "Confirmed" if scan.get("status") == "complete" else "New",
                    "detection_date": detection_date,
                    "fingerprint": fingerprint,
                    "valid_from": str(tr.get("valid_from", ""))[:10],
                    "common_name": str(tr.get("server_name") or host),
                    "company": "Internal" if is_inventoried else "External",
                    "ca": issuer.get("O") or issuer.get("CN") or "Unknown",
                    "is_inventoried": is_inventoried,
                }
            )

    # Keep rows unique and stable.
    def _uniq(rows: list[dict], key_fn):
        seen = set()
        out = []
        for row in rows:
            k = key_fn(row)
            if k in seen:
                continue
            seen.add(k)
            out.append(row)
        return out

    domains = _uniq(domains, lambda r: (r["domain_name"], r["detection_date"]))
    ssl = _uniq(ssl, lambda r: (r["fingerprint"], r["common_name"], r["detection_date"]))
    ip_subnets = _uniq(ip_subnets, lambda r: (r["ip"], r["ports"], r["detection_date"]))
    software = _uniq(software, lambda r: (r["host"], r["product"], r["port"], r["detection_date"]))

    if normalized_search:
        domains = [
            r for r in domains
            if normalized_search in str(r.get("domain_name", "")).lower()
            or normalized_search in str(r.get("registrar", "")).lower()
            or normalized_search in str(r.get("company", "")).lower()
        ]
        ssl = [
            r for r in ssl
            if normalized_search in str(r.get("common_name", "")).lower()
            or normalized_search in str(r.get("ca", "")).lower()
            or normalized_search in str(r.get("fingerprint", "")).lower()
            or normalized_search in str(r.get("company", "")).lower()
        ]
        ip_subnets = [
            r for r in ip_subnets
            if normalized_search in str(r.get("ip", "")).lower()
            or normalized_search in str(r.get("subnet", "")).lower()
            or normalized_search in str(r.get("location", "")).lower()
            or normalized_search in str(r.get("company", "")).lower()
        ]
        software = [
            r for r in software
            if normalized_search in str(r.get("product", "")).lower()
            or normalized_search in str(r.get("version", "")).lower()
            or normalized_search in str(r.get("host", "")).lower()
            or normalized_search in str(r.get("company", "")).lower()
        ]

    status_counts = Counter(
        [r.get("status", "") for r in domains + ssl + ip_subnets + software if r.get("status")]
    )

    asset_locations = []
    seen_locations: set[tuple[Any, Any, str]] = set()
    for row in ip_subnets:
        lat = row.get("lat")
        lon = row.get("lon")
        if lat is None or lon is None:
            continue
        key = (lat, lon, str(row.get("ip") or ""))
        if key in seen_locations:
            continue
        seen_locations.add(key)
        asset_locations.append(
            {
                "ip": str(row.get("ip") or ""),
                "lat": lat,
                "lon": lon,
                "location": str(row.get("location") or ""),
            }
        )

    return {
        "empty": not (domains or ssl or ip_subnets or software),
        "overview": {
            "domains": len(domains),
            "ssl": len(ssl),
            "ip_subnets": len(ip_subnets),
            "software": len(software),
        },
        "status_counts": {
            "New": status_counts.get("New", 0),
            "False Positive": status_counts.get("False Positive", 0),
            "Confirmed": status_counts.get("Confirmed", 0),
            "All": len(domains) + len(ssl) + len(ip_subnets) + len(software),
        },
        "domains": domains,
        "ssl": ssl,
        "ip_subnets": ip_subnets,
        "software": software,
        "asset_locations": asset_locations,
        "graph_payload": {
            "nodes": nodes,
            "edges": edges,
            "updated_at": datetime.now(timezone.utc).isoformat(),
        },
    }


def _render_api_dashboard_page(
    page_title: str,
    api_endpoint: str,
    columns: list[dict[str, str]],
    default_sort: str,
    default_order: str = "asc",
    default_page_size: int = 25,
    extra_params: dict | None = None,
):
    return render_template(
        "api_dashboard_example.html",
        page_title=page_title,
        api_endpoint=api_endpoint,
        columns=columns,
        default_sort=default_sort,
        default_order=default_order,
        default_page_size=default_page_size,
        extra_params=extra_params or {},
    )


@app.route("/asset-inventory")
@login_required
def asset_inventory_page():
    from web.routes.assets import render_assets_inventory_page

    return render_assets_inventory_page()



@app.route("/asset-discovery")
@login_required
def asset_discovery():
    from flask import request
    from src.db import db_session
    from src.models import Scan
    from src.table_helper import paginate_query
    
    page = int(request.args.get("page", 1) or 1)
    page_size = min(int(request.args.get("page_size", 100) or 100), 250)
    search_term = str(request.args.get("q", "") or "").strip()

    # We will use 'tab' parameter to define which model to paginate in future revisions
    # For now, we will pass an empty page_data to avoid crashing the macro injection UI until Discovery DB tables operate
    page_data: typing.Dict[str, typing.Any] = {"items": [], "total_count": 0, "has_next": False, "has_prev": False}

    try:
        vm = _build_asset_discovery_view(page=page, page_size=page_size, search_term=search_term)
    except Exception:
        vm = {
            "empty": True,
            "overview": {"domains": 0, "ssl": 0, "ip_subnets": 0, "software": 0},
            "status_counts": {"New": 0, "False Positive": 0, "Confirmed": 0, "All": 0},
            "domains": [],
            "ssl": [],
            "ip_subnets": [],
            "software": [],
            "graph_payload": {"nodes": [], "edges": []}
        }

        
    return render_template("asset_discovery.html", vm=vm, page_data=page_data)


@app.route("/api/discovery-graph")
@csrf.exempt
@login_required
def discovery_graph_payload():
    """Realtime discovery graph payload for incremental frontend updates."""
    _audit("scan", "discovery_graph_requested", "success")
    try:
        nodes: list[dict] = []
        edges: list[dict] = []
        node_ids: set[str] = set()
        edge_ids: set[str] = set()

        def add_node(node_id: str, label: str, group: str, title: str) -> None:
            if node_id in node_ids:
                return
            node_ids.add(node_id)
            nodes.append({"id": node_id, "label": label, "group": group, "title": title})

        def add_edge(src: str, dst: str) -> None:
            key = f"{src}->{dst}"
            if key in edge_ids:
                return
            edge_ids.add(key)
            edges.append({"id": key, "from": src, "to": dst})

        for scan in scan_store.values():
            if not isinstance(scan, dict):
                continue
            if scan.get("status") != "complete":
                continue
            target = str(scan.get("target", "")).strip().lower()
            host = _host_from_target(target)
            if not host:
                continue
            add_node(f"domain:{host}", host, "domain", f"Domain · {host}")
            for svc in scan.get("discovered_services") or []:
                svc_host = str(svc.get("host", "")).strip()
                port = svc.get("port")
                if svc_host:
                    add_node(f"ip:{svc_host}", svc_host, "ip", f"IP · {svc_host}")
                    add_edge(f"domain:{host}", f"ip:{svc_host}")
                    if port:
                        service_label = f"{str(svc.get('service', 'service')).upper()}:{port}"
                        add_node(f"service:{svc_host}:{port}", service_label, "service", f"Service · {svc_host}:{port}")
                        add_edge(f"ip:{svc_host}", f"service:{svc_host}:{port}")

        payload = {"nodes": nodes, "edges": edges, "updated_at": datetime.now(timezone.utc).isoformat()}
        payload["status"] = "success"
        return _deprecated_json(payload, 200, "dashboard.refresh(include_discovery=true)")
    except Exception as exc:
        return _deprecated_json({"status": "error", "message": str(exc)}, 500, "dashboard.refresh(include_discovery=true)")


def _inventory_scan_service_for_api():
    """Create inventory scan service bound to the app's scan pipeline."""
    from src.services.inventory_scan_service import InventoryScanService

    scan_runner = app.config.get("RUN_SCAN_PIPELINE_FUNC")
    return InventoryScanService(scan_runner=scan_runner)


def _can_access_roles(roles: set[str]) -> bool:
    if not getattr(current_user, "is_authenticated", False):
        return False
    user_role = str(getattr(current_user, "role", "") or "").strip().title()
    return user_role in {r.strip().title() for r in roles}


def _parse_ports_from_payload(value) -> list[int] | None:
    """Parse optional ports from JSON/form payload into list[int]."""
    if value is None:
        return None
    if isinstance(value, list):
        out = []
        for item in value:
            try:
                port = int(item)
                if 1 <= port <= 65535:
                    out.append(port)
            except (TypeError, ValueError):
                continue
        return out or None

    if isinstance(value, str):
        out = []
        for token in value.replace(" ", ",").split(","):
            token = token.strip()
            if not token:
                continue
            try:
                port = int(token)
                if 1 <= port <= 65535:
                    out.append(port)
            except (TypeError, ValueError):
                continue
        return out or None

    return None


def _build_unified_dashboard_payload(include_discovery: bool = False) -> dict:
    """Build a single API payload for the full dashboard and scan center surfaces."""
    dashboard_data = get_dashboard_data()
    inventory_vm = _build_asset_inventory_view()

    payload = {
        "dashboard": dashboard_data,
        "inventory": inventory_vm,
        "recent_scans": db.list_scans(limit=20),
        "scan_status": _inventory_scan_service_for_api().get_scan_status(),
    }

    if include_discovery:
        payload["discovery"] = _build_asset_discovery_view()

    return payload


def _deprecated_json(payload: dict, status_code: int, replacement_action: str) -> Response:
    """Attach deprecation headers while preserving legacy endpoint payload shape."""
    response = jsonify(payload or {})
    response.status_code = status_code
    response.headers["Deprecation"] = "true"
    response.headers["Sunset"] = "2026-12-31"
    response.headers["Link"] = '</api/dashboard>; rel="successor-version"'
    response.headers["X-Replacement-Endpoint"] = "/api/dashboard"
    response.headers["X-Replacement-Action"] = replacement_action
    response.headers["Warning"] = (
        f'299 - "Deprecated endpoint, migrate to /api/dashboard with action={replacement_action}"'
    )
    return response


@app.route("/api/dashboard", methods=["GET", "POST"])
@csrf.exempt
@login_required
def api_dashboard_unified():
    """Single API entry point for dashboard reads and scan operations.

    GET query params:
      - include_discovery=true|false

    POST body/form fields:
      - action (required)
      Actions:
        - scan.run
        - scan.inventory.all
        - scan.inventory.status
        - scan.inventory.asset
        - scan.inventory.history
        - scan.inventory.schedule.get
        - scan.inventory.schedule.set
        - dashboard.refresh
    """
    try:
        if request.method == "GET":
            include_discovery = str(request.args.get("include_discovery", "false")).strip().lower() == "true"
            data = _build_unified_dashboard_payload(include_discovery=include_discovery)
            return jsonify({"status": "success", "data": data}), 200

        payload = request.get_json(silent=True) or {}
        if not payload:
            payload = request.form.to_dict(flat=True)

        action = str(payload.get("action", "")).strip().lower()
        if not action:
            return jsonify({"status": "error", "message": "Missing 'action'"}), 400

        # ── Targeted Scan ────────────────────────────────────────────────
        if action == "scan.run":
            if not _can_access_roles(SCAN_ROLES):
                return jsonify({"status": "error", "message": "Insufficient role for scan.run"}), 403

            target = str(payload.get("target", "")).strip()
            if not target:
                return jsonify({"status": "error", "message": "Missing 'target'"}), 400

            asset_class_hint = str(payload.get("asset_class_hint", "")).strip() or None
            ports = _parse_ports_from_payload(payload.get("ports"))
            clean_target, _ = sanitize_target(target)
            scanned_by = getattr(current_user, "username", None) if getattr(current_user, "is_authenticated", False) else None
            add_to_inventory = bool(payload.get("add_to_inventory", False))
            report = run_scan_pipeline(
                clean_target,
                ports=ports,
                asset_class_hint=asset_class_hint,
                scan_kind="api_scan_run",
                scanned_by=scanned_by,
                add_to_inventory=add_to_inventory,
            )

            if not app.config.get("TESTING", False) and not bool(report.get("orm_persisted")):
                db.save_scan(report)
            scan_store[report.get("scan_id")] = report

            _audit("scan", "api_dashboard_scan_run", "success", target_scan_id=report.get("scan_id"), details={"target": clean_target})
            return jsonify({"status": "success", "data": report}), 200

        # ── Inventory Bulk Scan ─────────────────────────────────────────
        if action == "scan.inventory.all":
            if not _can_access_roles(BULK_SCAN_ROLES):
                return jsonify({"status": "error", "message": "Insufficient role for scan.inventory.all"}), 403

            background = str(payload.get("background", "true")).strip().lower() != "false"
            result = _inventory_scan_service_for_api().scan_all_assets(background=background)
            code = 200 if result.get("status") in {"started", "complete", "in_progress"} else 500
            return jsonify({"status": "success", "data": result}), code

        # ── Inventory Scan Status ───────────────────────────────────────
        if action == "scan.inventory.status":
            if not _can_access_roles(SCAN_ROLES):
                return jsonify({"status": "error", "message": "Insufficient role for scan.inventory.status"}), 403

            status_data = _inventory_scan_service_for_api().get_scan_status()
            return jsonify({"status": "success", "data": status_data}), 200

        # ── Inventory Single Asset Scan ────────────────────────────────
        if action == "scan.inventory.asset":
            if not _can_access_roles(SCAN_ROLES):
                return jsonify({"status": "error", "message": "Insufficient role for scan.inventory.asset"}), 403

            from src.db import db_session
            from src.models import Asset

            try:
                asset_id_raw = payload.get("asset_id", "")
                asset_id = int(str(asset_id_raw).strip())
            except (TypeError, ValueError):
                return jsonify({"status": "error", "message": "Missing or invalid 'asset_id'"}), 400

            asset = db_session.query(Asset).filter_by(id=asset_id, is_deleted=False).first()
            if not asset:
                return jsonify({"status": "error", "message": "Asset not found"}), 404

            result = _inventory_scan_service_for_api().scan_asset(asset)
            db_session.commit()
            code = 200 if result.get("status") == "complete" else 202
            return jsonify({"status": result.get("status") or "error", "data": result}), code

        # ── Inventory Asset History ────────────────────────────────────
        if action == "scan.inventory.history":
            if not _can_access_roles(SCAN_ROLES):
                return jsonify({"status": "error", "message": "Insufficient role for scan.inventory.history"}), 403

            try:
                asset_id_raw = payload.get("asset_id", "")
                asset_id = int(str(asset_id_raw).strip())
            except (TypeError, ValueError):
                return jsonify({"status": "error", "message": "Missing or invalid 'asset_id'"}), 400

            history = _inventory_scan_service_for_api().get_asset_scan_history(asset_id)
            return jsonify({"status": "success", "data": history}), 200

        # ── Inventory Schedule Get/Set ────────────────────────────────
        if action == "scan.inventory.schedule.get":
            if not _can_access_roles(BULK_SCAN_ROLES):
                return jsonify({"status": "error", "message": "Insufficient role for scan.inventory.schedule.get"}), 403

            from config import AUTOMATED_SCAN_ENABLED, AUTOMATED_SCAN_INTERVAL_HOURS

            return jsonify({
                "status": "success",
                "data": {"enabled": AUTOMATED_SCAN_ENABLED, "interval_hours": AUTOMATED_SCAN_INTERVAL_HOURS},
            }), 200

        if action == "scan.inventory.schedule.set":
            if not _can_access_roles(BULK_SCAN_ROLES):
                return jsonify({"status": "error", "message": "Insufficient role for scan.inventory.schedule.set"}), 403

            enabled = str(payload.get("enabled", "false")).strip().lower() == "true"
            try:
                interval_hours = int(payload.get("interval_hours", 24))
            except (TypeError, ValueError):
                return jsonify({"status": "error", "message": "Invalid 'interval_hours'"}), 400

            if interval_hours < 1 or interval_hours > 168:
                return jsonify({"status": "error", "message": "Interval must be between 1 and 168 hours"}), 400

            os.environ["INVENTORY_SCAN_ENABLED"] = str(enabled)
            os.environ["INVENTORY_SCAN_INTERVAL_HOURS"] = str(interval_hours)

            return jsonify({
                "status": "success",
                "message": "Schedule updated",
                "settings": {"enabled": enabled, "interval_hours": interval_hours},
            }), 200

        # ── Dashboard Refresh Payload ──────────────────────────────────
        if action == "dashboard.refresh":
            include_discovery = str(payload.get("include_discovery", "false")).strip().lower() == "true"
            data = _build_unified_dashboard_payload(include_discovery=include_discovery)
            return jsonify({"status": "success", "data": data}), 200

        return jsonify({
            "status": "error",
            "message": "Unsupported action",
            "supported_actions": [
                "scan.run",
                "scan.inventory.all",
                "scan.inventory.status",
                "scan.inventory.asset",
                "scan.inventory.history",
                "scan.inventory.schedule.get",
                "scan.inventory.schedule.set",
                "dashboard.refresh",
            ],
        }), 400
    except Exception as exc:
        _audit("api", "api_dashboard_unified", "failed", details={"error": str(exc)})
        return jsonify({"status": "error", "message": str(exc)}), 500


@app.route("/api/inventory/scan", methods=["POST"])
@role_required(list(SCAN_ROLES))
def api_inventory_scan_all():
    """Start or run inventory-wide scan and return JSON status."""
    try:
        payload = request.get_json(silent=True) or {}
        background_raw = payload.get("background", request.form.get("background", "true"))
        background = str(background_raw).strip().lower() != "false"

        scan_service = _inventory_scan_service_for_api()
        result = scan_service.scan_all_assets(background=background)
        _audit("scan", "inventory_scan_all", "success", details={"background": background, "status": result.get("status")})
        code = 200 if result.get("status") in {"started", "complete", "in_progress"} else 500
        return _deprecated_json(result, code, "scan.inventory.all")
    except Exception as exc:
        _audit("scan", "inventory_scan_all", "failed", details={"error": str(exc)})
        return _deprecated_json({"status": "error", "message": str(exc)}, 500, "scan.inventory.all")


@app.route("/api/inventory/scan-status", methods=["GET"])
@role_required(list(SCAN_ROLES))
def api_inventory_scan_status():
    """Return inventory scan progress/status payload."""
    try:
        scan_service = _inventory_scan_service_for_api()
        status_data = scan_service.get_scan_status()
        _audit("scan", "inventory_scan_status_requested", "success", details={"status": status_data.get("status")})
        return _deprecated_json({"status": "success", "data": status_data}, 200, "scan.inventory.status")
    except Exception as exc:
        _audit("scan", "inventory_scan_status_requested", "failed", details={"error": str(exc)})
        return _deprecated_json({"status": "error", "message": str(exc)}, 500, "scan.inventory.status")


@app.route("/api/inventory/asset/<int:asset_id>/scan", methods=["POST"])
@role_required(list(SCAN_ROLES))
def api_inventory_scan_asset(asset_id: int):
    """Run a single inventory asset scan and return JSON result."""
    from src.db import db_session
    from src.models import Asset

    try:
        asset = db_session.query(Asset).filter_by(id=asset_id, is_deleted=False).first()
        if not asset:
            _audit("scan", "inventory_scan_asset", "failed", details={"asset_id": asset_id, "error": "asset_not_found"})
            return _deprecated_json({"status": "error", "message": "Asset not found"}, 404, "scan.inventory.asset")

        scan_service = _inventory_scan_service_for_api()
        result = scan_service.scan_asset(asset)
        db_session.commit()
        code = 200 if result.get("status") == "complete" else 202
        _audit("scan", "inventory_scan_asset", "success", details={"asset_id": asset_id, "status": result.get("status")})
        return _deprecated_json({"status": result.get("status"), "data": result}, code, "scan.inventory.asset")
    except Exception as exc:
        db_session.rollback()
        _audit("scan", "inventory_scan_asset", "failed", details={"asset_id": asset_id, "error": str(exc)})
        return _deprecated_json({"status": "error", "message": str(exc)}, 500, "scan.inventory.asset")


@app.route("/api/inventory/asset/<int:asset_id>/history", methods=["GET"])
@role_required(list(SCAN_ROLES))
def api_inventory_asset_history(asset_id: int):
    """Return scan history for a single inventory asset."""
    try:
        scan_service = _inventory_scan_service_for_api()
        history = scan_service.get_asset_scan_history(asset_id)
        _audit("scan", "inventory_asset_history_requested", "success", details={"asset_id": asset_id})
        return _deprecated_json({"status": "success", "data": history}, 200, "scan.inventory.history")
    except Exception as exc:
        _audit("scan", "inventory_asset_history_requested", "failed", details={"asset_id": asset_id, "error": str(exc)})
        return _deprecated_json({"status": "error", "message": str(exc)}, 500, "scan.inventory.history")


@app.route("/api/inventory/schedule", methods=["GET", "POST"])
@role_required(list(BULK_SCAN_ROLES))
def api_inventory_schedule():
    """Get or update inventory schedule settings using JSON API semantics."""
    try:
        if request.method == "POST":
            payload = request.get_json(silent=True) or {}
            enabled_raw = payload.get("enabled", request.form.get("enabled", "false"))
            interval_raw = payload.get("interval_hours", request.form.get("interval_hours", 24))
            enabled = str(enabled_raw).strip().lower() == "true"
            try:
                interval_hours = int(interval_raw)
            except (ValueError, TypeError):
                interval_hours = 24

            if interval_hours < 1 or interval_hours > 168:
                return _deprecated_json({"status": "error", "message": "Interval must be between 1 and 168 hours"}, 400, "scan.inventory.schedule.set")

            os.environ["INVENTORY_SCAN_ENABLED"] = str(enabled)
            os.environ["INVENTORY_SCAN_INTERVAL_HOURS"] = str(interval_hours)
            return _deprecated_json({
                "status": "success",
                "message": "Schedule updated",
                "settings": {"enabled": enabled, "interval_hours": interval_hours},
            }, 200, "scan.inventory.schedule.set")

        from config import AUTOMATED_SCAN_ENABLED, AUTOMATED_SCAN_INTERVAL_HOURS
        return _deprecated_json({
            "status": "success",
            "data": {"enabled": AUTOMATED_SCAN_ENABLED, "interval_hours": AUTOMATED_SCAN_INTERVAL_HOURS},
        }, 200, "scan.inventory.schedule.get")
    except Exception as exc:
        return _deprecated_json({"status": "error", "message": str(exc)}, 500, "scan.inventory.schedule.get")


@app.route("/cbom-dashboard")
@login_required
def cbom_dashboard():
    """Build CBOM view with aggregated cryptographic metrics from MySQL.
    
    Always queries live database—never returns hardcoded KPIs. Service failures
    fall back to minimal DB aggregation to ensure KPIs always reflect current state.
    """
    from src.services.cbom_service import CbomService

    try:
        asset_filter_id = request.args.get("asset_id", type=int)
        start_date_str = request.args.get("start_date")
        end_date_str = request.args.get("end_date")
        page = max(1, request.args.get("page", 1, type=int) or 1)
        page_size = min(max(1, request.args.get("page_size", 25, type=int) or 25), 250)
        sort_field = (request.args.get("sort") or "asset_name").strip()
        sort_order = (request.args.get("order") or "asc").strip().lower()
        search_term = (request.args.get("q") or "").strip()

        cbom_data = CbomService.get_cbom_dashboard_data(
            asset_id=asset_filter_id,
            start_date=start_date_str,
            end_date=end_date_str,
            limit=200,
            page=page,
            page_size=page_size,
            sort_field=sort_field,
            sort_order=sort_order,
            search_term=search_term,
        )

        vm = {
            "empty": (cbom_data.get("meta", {}).get("certificate_count", 0) or 0) == 0,
            "kpis": cbom_data.get("kpis", {}),
            "key_length_distribution": cbom_data.get("key_length_distribution", {"No Data": 0}),
            "cipher_usage": cbom_data.get("cipher_usage", {"No Data": 0}),
            "top_cas": cbom_data.get("top_cas", {"No Data": 0}),
            "protocols": cbom_data.get("protocols", {"No Data": 0}),
            "minimum_elements": cbom_data.get("minimum_elements", {"total_entries": 0, "asset_type_distribution": {}, "field_coverage": {}, "items": []}),
            "rows": [],
            "weakness_heatmap": cbom_data.get("weakness_heatmap", []),
        }

        page_data = cbom_data.get("page_data", {
            "items": [], "total_count": 0, "page": 1, "page_size": 0, "total_pages": 1, "has_next": False, "has_prev": False
        })

    except Exception as e:
        current_app.logger.error("CBOM dashboard error: %s", e)
        # On error, query DB directly for KPI counts instead of hardcoding zeros
        try:
            from src.db import db_session
            from src.models import Certificate
            from sqlalchemy import func
            
            cert_count = db_session.query(Certificate).filter(Certificate.is_deleted == False).count()
            active_certs = db_session.query(func.count(Certificate.id)).filter(
                Certificate.is_deleted == False,
                Certificate.valid_until >= func.now()
            ).scalar() or 0
            
            fallback_kpis = {
                "total_applications": cert_count,
                "sites_surveyed": cert_count,
                "active_certificates": active_certs,
                "weak_cryptography": 0,
                "certificate_issues": 0,
            }
        except Exception as db_e:
            current_app.logger.error("CBOM KPI fallback DB query failed: %s", db_e)
            fallback_kpis = {
                "total_applications": 0,
                "sites_surveyed": 0,
                "active_certificates": 0,
                "weak_cryptography": 0,
                "certificate_issues": 0,
            }
        
        vm = {
            "empty": True,
            "kpis": fallback_kpis,
            "key_length_distribution": {"No Data": 0},
            "cipher_usage": {"No Data": 0},
            "top_cas": {"No Data": 0},
            "protocols": {"No Data": 0},
            "minimum_elements": {"total_entries": 0, "asset_type_distribution": {}, "field_coverage": {}, "items": []},
            "rows": [],
            "weakness_heatmap": [],
        }
        page_data: typing.Dict[str, typing.Any] = {"items": [], "total_count": 0, "page": 1, "page_size": 0, "total_pages": 1, "has_next": False, "has_prev": False}

    return render_template("cbom_dashboard.html", vm=vm, page_data=page_data)


@app.route("/pqc-posture")
@login_required
def pqc_posture():
    """Build PQC posture with aggregated quantum-safe readiness metrics from service.
    
    Only includes active (non-deleted) assets. Metrics aggregated by asset count,
    not scan count. Joins Asset -> PQCClassification to ensure consistency.
    Always queries live database—never returns hardcoded KPIs.
    """
    from src.services.pqc_service import PQCService
    
    try:
        page = max(1, request.args.get("page", 1, type=int) or 1)
        page_size = min(max(1, request.args.get("page_size", 25, type=int) or 25), 250)
        sort_field = (request.args.get("sort") or "asset_name").strip()
        sort_order = (request.args.get("order") or "asc").strip().lower()
        search_term = (request.args.get("q") or "").strip()

        # Load PQC dashboard data from service (asset-based aggregation, soft-delete filtering)
        data = PQCService.get_pqc_dashboard_data(
            page=page,
            page_size=page_size,
            sort_field=sort_field,
            sort_order=sort_order,
            search_term=search_term,
            limit=500,
        )
        
        # Build view model with percentages and counts
        vm = {
            "empty": data["meta"]["total_assets"] == 0,
            "overall": {
                "elite": data["kpis"]["elite_pct"],
                "standard": data["kpis"]["standard_pct"],
                "legacy": data["kpis"]["legacy_pct"],
                "critical_apps": data["kpis"]["critical_count"],
            },
            "grade_counts": data["grade_counts"],
            "average_pqc_score": data["kpis"]["avg_score"],
            "status_distribution": data["status_distribution"],
            "recommendations": data["recommendations"],
            "support_rows": data["applications"],
            "risk_heatmap": data["risk_heatmap"],
        }
        
        # Build pagination data (applications are asset-based)
        page_data = data.get("page_data", {
            "items": data.get("applications", []),
            "total_count": len(data.get("applications", [])),
            "page": 1,
            "page_size": len(data.get("applications", [])),
            "total_pages": 1,
            "has_next": False,
            "has_prev": False,
        })
        
    except Exception as e:
        current_app.logger.error(f"PQC dashboard error: {e}")
        # On error, return minimal KPI structure instead of hardcoded zeros
        vm = {
            "empty": True,
            "overall": {"elite": 0, "standard": 0, "legacy": 0, "critical_apps": 0},
            "grade_counts": {"Elite": 0, "Standard": 0, "Legacy": 0, "Critical": 0},
            "average_pqc_score": 0,
            "status_distribution": {},
            "recommendations": ["Run scans to populate PQC posture."],
            "support_rows": [],
            "risk_heatmap": []
        }
        page_data: typing.Dict[str, typing.Any] = {"items": [], "total_count": 0, "page": 1, "page_size": 0, "total_pages": 1, "has_next": False, "has_prev": False}
    
    return render_template("pqc_posture.html", vm=vm, page_data=page_data)


@app.route("/cyber-rating")
@login_required
def cyber_rating():
    """Build cyber rating from active inventory assets and live DB telemetry.
    
    Always queries live database—never returns hardcoded KPIs.
    """
    from src.services.cyber_reporting_service import CyberReportingService
    try:
        data = CyberReportingService.get_cyber_rating_data(limit=200)

        avg_score_100 = float(data.get("kpis", {}).get("avg_score", 0) or 0)
        avg_score = max(0.0, min(1000.0, avg_score_100 * 10.0))
        if avg_score >= 700:
            label = "Elite"
        elif avg_score >= 400:
            label = "Standard"
        elif avg_score >= 200:
            label = "Legacy"
        else:
            label = "Critical"

        items = []
        for row in data.get("applications", []):
            row_score = max(0.0, min(1000.0, float(row.get("score", 0) or 0) * 10.0))
            if row_score >= 700:
                row_tier = "Elite"
            elif row_score >= 400:
                row_tier = "Standard"
            elif row_score >= 200:
                row_tier = "Legacy"
            else:
                row_tier = "Critical"
            items.append(
                {
                    **row,
                    "score": round(row_score, 1),
                    "tier": row_tier,
                }
            )
        page_data: typing.Dict[str, typing.Any] = {
            "items": items,
            "total_count": len(items),
            "page": 1,
            "page_size": len(items),
            "total_pages": 1,
            "has_next": False,
            "has_prev": False,
        }

        vm = {
            "empty": data.get("meta", {}).get("total_assets", 0) == 0,
            "overall_score": avg_score,
            "label": label,
            "tier_counts": {
                "Critical": data.get("grade_counts", {}).get("Critical", 0),
                "Legacy": data.get("grade_counts", {}).get("Legacy", 0),
                "Standard": data.get("grade_counts", {}).get("Standard", 0),
                "Elite": data.get("grade_counts", {}).get("Elite", 0),
            },
            "tier_heatmap": data.get("risk_heatmap", []),
            "recommendations": data.get("recommendations", []),
        }
    except Exception as e:
        current_app.logger.error("Cyber rating error: %s", e)
        vm = {
            "empty": True,
            "overall_score": 0,
            "label": "Unknown",
            "tier_counts": {"Critical": 0, "Legacy": 0, "Standard": 0, "Elite-PQC": 0},
            "tier_heatmap": [],
            "recommendations": ["Run scans to populate cyber posture."],
        }
        page_data: typing.Dict[str, typing.Any] = {"items": [], "total_count": 0, "page": 1, "page_size": 0, "total_pages": 1, "has_next": False, "has_prev": False}
    return render_template("cyber_rating.html", vm=vm, page_data=page_data)


@app.route("/reporting")
@login_required
def reporting():
    """Build reporting dashboard from live database metrics.
    
    Always queries live database—never returns hardcoded KPIs.
    """
    from src.services.cyber_reporting_service import CyberReportingService
    try:
        summary = CyberReportingService.get_reporting_summary()

        vm = {
            "summary": summary,
            "empty": "Targets: 0" in str(summary.get("discovery", "")),
        }
    except Exception as e:
        current_app.logger.error("Reporting dashboard error: %s", e)
        vm = {
            "summary": {
                "discovery": "Targets: 0 | Complete Scans: 0 | Assessed Endpoints: 0",
                "pqc": "Assessed endpoints: 0 | Average PQC Score: 0%",
                "cbom": "Total certificates: 0 | Weak cryptography: 0",
                "cyber_rating": "Average enterprise score: 0/100",
                "inventory": "Assets: 0 | Critical Apps: 0 | Legacy: 0",
            }, 
            "empty": True
        }
    return render_template("reporting.html", vm=vm)


# Sprint 6: Vulnerabilities page route
@app.route("/vulnerabilities")
@login_required
def vulnerabilities_page():
    """
    Render the Vulnerabilities Intelligence dashboard.

    The page is a pure API-first shell — all data is fetched client-side
    via /api/v1/vulnerabilities (paginated CVE list) and
    /api/v1/vulnerabilities/stats (severity counters).

    No data is passed from this server-side view to prevent stale renders.
    """
    return render_template("vulnerabilities.html")


@app.route("/scan", methods=["POST"])
@limiter.limit("20 per hour")
@role_required(list(SCAN_ROLES))
def scan():
    """Run a scan on one or multiple targets (text input + CSV upload)."""
    import re
    import csv
    import io

    target_input = request.form.get("target", "").strip()
    ports_str = request.form.get("ports", "").strip()
    autodiscovery = request.form.get("autodiscovery") == "on"
    add_to_inventory = request.form.get("add_to_inventory") == "on"
    
    # Extract metadata options supporting single/bulk fallback names
    inv_owner = (request.form.get("inv_owner") or request.form.get("inv_owner_bulk") or "").strip() or None
    inv_risk = (request.form.get("inv_risk") or request.form.get("inv_risk_bulk") or "Medium").strip()
    inv_notes = (request.form.get("inv_notes") or request.form.get("inv_notes_bulk") or "").strip() or None

    asset_class_mode = (
        request.form.get("asset_class_mode")
        or request.form.get("asset_class_mode_bulk")
        or "auto"
    ).strip().lower()
    asset_class_value = (
        request.form.get("asset_class_value")
        or request.form.get("asset_class_value_bulk")
        or ""
    ).strip()
    asset_class_hint = asset_class_value if asset_class_mode == "manual" and asset_class_value else None

    # Parse global custom ports
    custom_ports = None
    if ports_str:
        try:
            custom_ports = [
                int(p.strip()) for p in ports_str.replace(" ", ",").split(",")
                if p.strip().isdigit()
            ]
        except ValueError:
            pass

    # Autodiscovery mode: use the exhaustive port list
    if autodiscovery and not custom_ports:
        custom_ports = list(AUTODISCOVERY_PORTS)

    # ── Collect targets from text input ──
    targets = []  # list of (host, per_target_ports_or_None)
    if target_input:
        raw_targets = re.split(r'[,\n]+', target_input)
        for t in raw_targets:
            t = t.strip()
            if t:
                targets.append((t, custom_ports))

    # ── Collect targets from CSV upload ──
    csv_file = request.files.get("csv_file")
    if csv_file and csv_file.filename:
        try:
            stream = io.StringIO(csv_file.stream.read().decode("utf-8-sig"))
            reader = csv.DictReader(stream)
            # Normalize column headers to lowercase
            if reader.fieldnames is not None:
                reader.fieldnames = [f.strip().lower() for f in reader.fieldnames]
            for row in reader:
                host = (
                    row.get("ip", "")
                    or row.get("host", "")
                    or row.get("target", "")
                    or row.get("domain", "")
                ).strip()
                if not host:
                    continue
                port_val = row.get("port", "").strip()
                if port_val and port_val.isdigit():
                    row_ports = [int(port_val)]
                else:
                    row_ports = custom_ports
                targets.append((host, row_ports))
        except Exception:
            pass  # silently skip malformed CSV

    if not targets:
        _audit("scan", "scan_requested", "failed", details={"reason": "no_targets"})
        return redirect(url_for("quantumshield_dashboard.dashboard_home"))
        
    # Enforce advanced RBAC
    is_bulk = (csv_file and csv_file.filename) or len(targets) > 1
    if is_bulk and current_user.role not in BULK_SCAN_ROLES:
        _audit("scan", "bulk_scan_denied", "denied", details={"role": current_user.role, "target_count": len(targets)})
        flash("Your role allows single-target scans only.", "error")
        return redirect(url_for("quantumshield_dashboard.dashboard_home"))

    try:
        if len(targets) == 1:
            # Single scan: redirect directly to results page
            host, ports = targets[0]
            clean_target, _ = sanitize_target(host)
            report = run_scan_pipeline(
                clean_target,
                ports,
                asset_class_hint=asset_class_hint,
                scan_kind="manual_single",
                scanned_by=getattr(current_user, "username", None),
                add_to_inventory=add_to_inventory,
            )
            
            # Ensure persistence to both JSON and MySQL
            try:
                if not app.config.get("TESTING", False) and not bool(report.get("orm_persisted")):
                    db.save_scan(report)
                    
                    if add_to_inventory:
                        from src.db import db_session
                        from src.models import Asset
                        exists = db_session.query(Asset).filter(Asset.name == clean_target, Asset.is_deleted == False).first()
                        if not exists:
                            asset_type = asset_class_hint or "Web App"
                            new_asset = Asset(
                                name=clean_target,
                                url=f"https://{clean_target}" if not clean_target.startswith('http') else clean_target,
                                asset_type=asset_type,
                                owner=inv_owner,
                                risk_level=inv_risk,
                                notes=inv_notes,
                                is_deleted=False
                            )
                            db_session.add(new_asset)
                            db_session.commit()
                            flash(f"Asset {clean_target} added to inventory.", "success")
                            logger.info(f"Auto-added model {clean_target} to Asset Inventory.")
            except Exception as db_err:
                logger.warning(f"Failed to save scan/asset to MySQL: {db_err}")
            
            scan_store[report.get("scan_id")] = report
            _audit("scan", "single_scan", "success", target_scan_id=report.get("scan_id"), details={"target": clean_target})
            return redirect(url_for("results", scan_id=report.get("scan_id", "")))

        else:
            # Bulk scan: run all and redirect to dashboard
            successful_scans = []
            failed_scans = []
            for host, ports in targets:
                try:
                    clean_target, _ = sanitize_target(host)
                    report = run_scan_pipeline(
                        clean_target,
                        ports,
                        asset_class_hint=asset_class_hint,
                        scan_kind="manual_bulk",
                        scanned_by=getattr(current_user, "username", None),
                        add_to_inventory=add_to_inventory,
                    )
                    
                    # Persist to both JSON and MySQL
                    try:
                        if not app.config.get("TESTING", False) and not bool(report.get("orm_persisted")):
                            db.save_scan(report)
                            
                            if add_to_inventory:
                                from src.db import db_session
                                from src.models import Asset
                                exists = db_session.query(Asset).filter(Asset.name == clean_target, Asset.is_deleted == False).first()
                                if not exists:
                                    asset_type = asset_class_hint or "Web App"
                                    new_asset = Asset(
                                        name=clean_target,
                                        url=f"https://{clean_target}" if not clean_target.startswith('http') else clean_target,
                                        asset_type=asset_type,
                                        owner=inv_owner,
                                        risk_level=inv_risk,
                                        notes=inv_notes,
                                        is_deleted=False
                                    )
                                    db_session.add(new_asset)
                                    db_session.commit()
                                    flash(f"Asset {clean_target} added to inventory.", "success")
                    except Exception as db_err:
                            logger.warning(f"Failed to save scan/asset to MySQL for {clean_target}: {db_err}")
                    
                    scan_store[report.get("scan_id")] = report
                    successful_scans.append(clean_target)
                    _audit("scan", "bulk_scan_item", "success", target_scan_id=report.get("scan_id"), details={"target": clean_target})
                except Exception as item_err:
                    failed_scans.append({"target": host, "error": str(item_err)})
                    logger.warning(f"Failed to scan {host}: {item_err}")
                    continue

            _audit("scan", "bulk_scan", "success", details={"target_count": len(targets), "successful": len(successful_scans), "failed": len(failed_scans)})
            return redirect(url_for("quantumshield_dashboard.dashboard_home"))

    except Exception as exc:
        _audit("scan", "scan_error", "failed", details={"error": str(exc), "target_count": len(targets)})
        error_id = uuid.uuid4().hex[:8]
        return render_template(
            "error.html",
            error_id=error_id,
            error_message=str(exc),
            traceback_info=traceback.format_exc(),
        )


@app.route("/results/<scan_id>")
@login_required
@talisman(
    frame_options="SAMEORIGIN",
    content_security_policy={**CSP_CONFIG, "frame-ancestors": ["'self'"]},
)
def results(scan_id: str):
    """Display scan results (memory → disk → MySQL fallback)."""
    import re as _re
    if not _re.match(r'^[a-f0-9A-F\-]+$', scan_id):
        return render_template("error.html", error_message="Invalid scan ID."), 404
    report = scan_store.get(scan_id)
    if not report:
        # Try loading from disk
        report_path = os.path.join(RESULTS_DIR, f"{scan_id}_report.json")
        if os.path.exists(report_path):
            with open(report_path, "r", encoding="utf-8") as fh:
                report = json.load(fh)
                scan_store[scan_id] = report
        else:
            # Try loading from MySQL
            report = db.get_scan(scan_id)
            if report:
                scan_store[scan_id] = report
            else:
                _audit("scan", "view_result", "failed", target_scan_id=scan_id, details={"reason": "not_found"})
                return render_template("error.html", error_message="Scan not found."), 404

    # Attach CBOM JSON to the report object for inline preview if available on disk or in DB
    try:
        if report.get("cbom") is None:
            cbom_data = None
            cbom_path = report.get("cbom_path") or os.path.join(RESULTS_DIR, f"{scan_id}_cbom.json")
            if isinstance(cbom_path, str) and os.path.exists(cbom_path):
                try:
                    with open(cbom_path, 'r', encoding='utf-8') as cbfh:
                        cbom_data = json.load(cbfh)
                except Exception:
                    cbom_data = None
            else:
                try:
                    cbom_data = db.get_cbom(scan_id)
                except Exception:
                    cbom_data = None
            report["cbom"] = cbom_data
    except Exception:
        # Be defensive — never fail the results view due to CBOM preview errors
        try:
            report["cbom"] = None
        except Exception:
            pass

    _audit("scan", "view_result", "success", target_scan_id=scan_id, details={"target": report.get("target")})

    # Sanitize nested report fields so template |tojson() calls won't fail on Jinja Undefined or non-serializable values
    try:
        import jinja2 as _jinja
        from datetime import datetime as _dt
        from collections.abc import Mapping, Sequence

        def _is_undefined(o):
            # Some environments expose Undefined as jinja2.runtime.Undefined
            try:
                if isinstance(o, _jinja.Undefined):
                    return True
            except Exception:
                pass
            try:
                return getattr(o, "__class__", None) and getattr(o.__class__, "__name__", "") == "Undefined"
            except Exception:
                return False

        def _sanitize(obj):
            try:
                # Handle explicit Jinja Undefined
                if _is_undefined(obj):
                    return None

                # Primitives
                if obj is None or isinstance(obj, (str, int, float, bool)):
                    return obj

                # Datetime -> isoformat
                if isinstance(obj, _dt):
                    return obj.isoformat()

                # Bytes -> decode
                if isinstance(obj, (bytes, bytearray)):
                    try:
                        return obj.decode("utf-8", "replace")
                    except Exception:
                        return str(obj)

                # Mapping-like -> dict
                if isinstance(obj, Mapping):
                    out = {}
                    for k, v in obj.items():
                        try:
                            key = k if isinstance(k, str) else str(k)
                        except Exception:
                            key = str(k)
                        out[key] = _sanitize(v)
                    return out

                # Sequence-like -> list
                if isinstance(obj, Sequence) and not isinstance(obj, (str, bytes, bytearray)):
                    return [_sanitize(v) for v in obj]

                # Fallback: attempt JSON dump, else str()
                import json as _json
                try:
                    _json.dumps(obj)
                    return obj
                except Exception:
                    try:
                        return str(obj)
                    except Exception:
                        return None
            except Exception:
                return None
    except Exception:
        # Conservative fallback if jinja2 isn't available
        def _sanitize(x):
            try:
                import json as _json
                _json.dumps(x)
                return x
            except Exception:
                try:
                    return str(x)
                except Exception:
                    return None

    try:
        # Ensure the entire report is safe and JSON-serializable (coerce Mapping/Rows/etc.)
        try:
            report = _sanitize(report) or {}
        except Exception:
            report = report or {}

        # tls_results sanitization and KPI computation
        tls_rows = report.get('tls_results') if isinstance(report.get('tls_results'), list) else []
        cert_total = len(tls_rows)
        cert_expired = 0
        cert_expiring = 0
        cert_weak_keys = 0
        for tls in tls_rows:
            if not isinstance(tls, dict):
                continue
            # Normalize certificate_details and ensure it's safe
            if tls.get('certificate_details') is not None:
                try:
                    tls['certificate_details'] = _sanitize(tls.get('certificate_details'))
                except Exception:
                    tls['certificate_details'] = {}
            else:
                tls['certificate_details'] = {}

            # Ensure days_remaining exists (prefer explicit fields, else compute from valid_to/valid_until)
            if tls.get('days_remaining') is None:
                dr = tls.get('cert_days_remaining')
                if dr is not None:
                    try:
                        tls['days_remaining'] = int(dr)
                    except Exception:
                        tls['days_remaining'] = None
                else:
                    valid_to = tls.get('valid_to') or tls.get('valid_until') or (tls.get('certificate_details') or {}).get('validity', {}).get('not_after')
                    if valid_to:
                        try:
                            vt = _dt.fromisoformat(str(valid_to).replace('Z', '+00:00'))
                            tls['days_remaining'] = int((vt - _dt.utcnow()).total_seconds() // 86400)
                        except Exception:
                            tls['days_remaining'] = None
                    else:
                        tls['days_remaining'] = None
            else:
                try:
                    tls['days_remaining'] = int(tls.get('days_remaining'))
                except Exception:
                    tls['days_remaining'] = None


            # Key length normalization
            try:
                key_len = int(tls.get('key_length') or tls.get('key_size') or (tls.get('certificate_details') or {}).get('subject_public_key_info', {}).get('subject_public_key_bits') or 0)
            except Exception:
                key_len = 0
            tls['key_length'] = key_len

            # Update KPI counters
            if bool(tls.get('is_expired')) or (str(tls.get('cert_status') or '').strip().lower() == 'expired'):
                cert_expired += 1
            elif tls.get('days_remaining') is not None and isinstance(tls.get('days_remaining'), int) and tls.get('days_remaining') <= 30:
                cert_expiring += 1
            if 0 < key_len < 2048:
                cert_weak_keys += 1

            # Sanitize all fields in tls to remove Undefined objects
            for k in list(tls.keys()):
                try:
                    tls[k] = _sanitize(tls[k])
                except Exception:
                    tls[k] = None

        # Attach computed certificate summary and sanitize asset_locations and cbom for safe JSON embedding
        try:
            report['cert_summary'] = {
                'total': int(cert_total),
                'expired': int(cert_expired),
                'expiring': int(cert_expiring),
                'weak_keys': int(cert_weak_keys),
            }
        except Exception:
            report['cert_summary'] = {'total': 0, 'expired': 0, 'expiring': 0, 'weak_keys': 0}

        if isinstance(report.get('asset_locations'), list):
            try:
                report['asset_locations'] = _sanitize(report['asset_locations'])
            except Exception:
                report['asset_locations'] = []
        if report.get('cbom') is not None:
            try:
                report['cbom'] = _sanitize(report.get('cbom'))
            except Exception:
                report['cbom'] = None
    except Exception:
        # Don't fail view rendering because of sanitization issues
        pass

    # Add previous scan history for the same target/host (real DB data only)
    try:
        from sqlalchemy import or_, func
        from src.db import db_session
        from src.models import Scan

        report_target_raw = str(report.get("target") or "").strip()
        report_target_norm = report_target_raw.lower()
        history_items: list[dict[str, typing.Any]] = []

        if report_target_norm:
            scan_rows = (
                db_session.query(Scan)
                .filter(
                    Scan.is_deleted == False,
                    or_(
                        func.lower(func.coalesce(Scan.normalized_target, "")) == report_target_norm,
                        func.lower(func.coalesce(Scan.target, "")) == report_target_norm,
                        func.lower(func.coalesce(Scan.requested_target, "")) == report_target_norm,
                    ),
                )
                .order_by(func.coalesce(Scan.scanned_at, Scan.completed_at, Scan.started_at, Scan.created_at).desc())
                .limit(25)
                .all()
            )

            for row in scan_rows:
                row_scan_id = str(getattr(row, "scan_id", "") or getattr(row, "scan_uid", "") or "").strip()
                if not row_scan_id or row_scan_id == str(scan_id):
                    continue

                history_items.append(
                    {
                        "scan_id": row_scan_id,
                        "target": str(getattr(row, "target", "") or getattr(row, "requested_target", "") or ""),
                        "status": str(getattr(row, "status", "") or "unknown"),
                        "started_at": getattr(row, "started_at", None).isoformat() if getattr(row, "started_at", None) else None,
                        "completed_at": (
                            getattr(row, "completed_at", None).isoformat()
                            if getattr(row, "completed_at", None)
                            else (
                                getattr(row, "scanned_at", None).isoformat()
                                if getattr(row, "scanned_at", None)
                                else None
                            )
                        ),
                        "total_assets": int(getattr(row, "total_assets", 0) or 0),
                        "compliance_score": float(getattr(row, "compliance_score", 0) or 0),
                        "overall_pqc_score": float(getattr(row, "overall_pqc_score", 0) or 0),
                    }
                )

        report["related_scan_history"] = history_items
    except Exception as history_exc:
        logger.warning("Could not build related scan history for results(%s): %s", scan_id, history_exc)
        report["related_scan_history"] = []
    finally:
        try:
            db_session.remove()
        except Exception:
            pass

    return render_template("results.html", report=report, scan_id=scan_id)


def _load_report_for_scan(scan_id: str) -> dict[str, Any] | None:
    """Resolve a scan report from memory, disk, or database."""
    if not re.match(r'^[a-f0-9A-F\-]+$', str(scan_id or '')):
        return None

    report = scan_store.get(scan_id)
    if report:
        return typing.cast(dict[str, Any], report)

    report_path = os.path.join(RESULTS_DIR, f"{scan_id}_report.json")
    if os.path.exists(report_path):
        try:
            with open(report_path, "r", encoding="utf-8") as fh:
                report = json.load(fh)
            if isinstance(report, dict):
                scan_store[scan_id] = report
                return typing.cast(dict[str, Any], report)
        except Exception:
            return None

    try:
        report = db.get_scan(scan_id)
        if isinstance(report, dict):
            scan_store[scan_id] = report
            return typing.cast(dict[str, Any], report)
    except Exception:
        return None
    return None


def _label_variant_for_report(report: dict[str, Any] | None) -> str:
    """Classify label variant based on persisted scan posture."""
    payload = report if isinstance(report, dict) else {}
    overview = payload.get("overview") if isinstance(payload.get("overview"), dict) else {}
    q_vuln = int(overview.get("quantum_vulnerable") or payload.get("quantum_vuln") or 0)
    score = float(overview.get("average_compliance_score") or overview.get("compliance_score") or 0)
    if q_vuln > 0:
        return "vulnerable"
    if score >= 80:
        return "proof"
    return "hybrid"


def _build_public_embed_payload(scan_id: str, report: dict[str, Any] | None) -> dict[str, Any]:
    """Build a safe, text-first embed payload from persisted scan telemetry."""
    payload = report if isinstance(report, dict) else {}
    overview = payload.get("overview") if isinstance(payload.get("overview"), dict) else {}
    tls_rows = payload.get("tls_results") if isinstance(payload.get("tls_results"), list) else []
    recs = payload.get("recommendations_detailed") if isinstance(payload.get("recommendations_detailed"), list) else []

    def _to_float(value: Any, default: float = 0.0) -> float:
        try:
            return float(value)
        except (TypeError, ValueError):
            return default

    def _to_int(value: Any, default: int = 0) -> int:
        try:
            return int(value)
        except (TypeError, ValueError):
            return default

    target = str(payload.get("target") or "").strip()
    scanned_at = (
        str(payload.get("generated_at") or payload.get("scanned_at") or payload.get("completed_at") or "").strip()
    )
    compliance_score = _to_float(
        overview.get("average_compliance_score")
        if isinstance(overview, dict)
        else payload.get("compliance_score"),
        0.0,
    )
    quantum_vulnerable = _to_int(
        overview.get("quantum_vulnerable") if isinstance(overview, dict) else payload.get("quantum_vuln"),
        0,
    )

    tls_versions: list[str] = []
    key_exchanges: list[str] = []
    for row in tls_rows:
        if not isinstance(row, dict):
            continue
        version = str(row.get("tls_version") or row.get("protocol_version") or "").strip()
        key_exchange = str(row.get("key_exchange") or row.get("key_exchange_method") or "").strip()
        if version and version not in tls_versions:
            tls_versions.append(version)
        if key_exchange and key_exchange not in key_exchanges:
            key_exchanges.append(key_exchange)

    recommendation_titles: list[str] = []
    for rec in recs:
        if isinstance(rec, dict):
            title = str(rec.get("title") or rec.get("name") or "").strip()
        else:
            title = str(rec or "").strip()
        if title and title not in recommendation_titles:
            recommendation_titles.append(title)
        if len(recommendation_titles) >= 3:
            break

    variant = _label_variant_for_report(payload)
    status_label = {
        "proof": "QUANTUM PROOF",
        "hybrid": "QUANTUM HYBRID",
        "vulnerable": "QUANTUM VULNERABLE",
    }.get(variant, "QUANTUM STATUS")

    return {
        "scan_id": str(scan_id),
        "target": target,
        "status": status_label,
        "variant": variant,
        "compliance_score": round(compliance_score, 2),
        "quantum_vulnerable": quantum_vulnerable,
        "tls_versions": tls_versions,
        "key_exchanges": key_exchanges,
        "recommendations": recommendation_titles,
        "scanned_at": scanned_at,
    }


@app.route('/labels/badge/<scan_id>.svg', methods=['GET'])
def label_badge_svg(scan_id: str):
    """Public embeddable SVG badge for a scan result.

    Query params:
      - variant: auto|proof|hybrid|vulnerable (default: auto)
    """
    report = _load_report_for_scan(scan_id)
    if not report:
        return Response("Scan not found", status=404, mimetype='text/plain')

    variant = str(request.args.get("variant") or "auto").strip().lower()
    if variant not in {"auto", "proof", "hybrid", "vulnerable"}:
        variant = "auto"
    if variant == "auto":
        variant = _label_variant_for_report(report)

    palette = {
        "proof": {
            "bg": "#166534",
            "border": "#00f5a0",
            "icon_bg": "#00d084",
            "icon_fg": "#ffffff",
            "title": "QUANTUM PROOF",
            "dot": "#00f5a0",
            "sub": "Scanned by QuantumShield by ParaCipher",
            "symbol": "✓",
        },
        "hybrid": {
            "bg": "#1e2a78",
            "border": "#5da3ff",
            "icon_bg": "#4f86ff",
            "icon_fg": "#ffffff",
            "title": "QUANTUM HYBRID ALGORITHM USED",
            "dot": "#5da3ff",
            "sub": "Scanned by QuantumShield by ParaCipher",
            "symbol": "⚛",
        },
        "vulnerable": {
            "bg": "#7f1019",
            "border": "#ff4d4f",
            "icon_bg": "#ff4d4f",
            "icon_fg": "#ffffff",
            "title": "QUANTUM VULNERABLE SITE",
            "dot": "#ff4d4f",
            "sub": "Scanned by QuantumShield by ParaCipher",
            "symbol": "⚠",
        },
    }[variant]

    svg = f"""<?xml version=\"1.0\" encoding=\"UTF-8\"?>
<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"900\" height=\"220\" viewBox=\"0 0 900 220\" role=\"img\" aria-label=\"{palette['title']}\">
  <rect x=\"1\" y=\"1\" width=\"898\" height=\"218\" fill=\"{palette['bg']}\" stroke=\"{palette['border']}\" stroke-width=\"2\" />
  <circle cx=\"64\" cy=\"110\" r=\"44\" fill=\"{palette['icon_bg']}\" stroke=\"#ffffff\" stroke-width=\"2\" />
  <text x=\"64\" y=\"124\" text-anchor=\"middle\" font-size=\"48\" font-family=\"Inter, Arial, sans-serif\" fill=\"{palette['icon_fg']}\" font-weight=\"700\">{palette['symbol']}</text>
  <text x=\"140\" y=\"92\" font-family=\"Inter, Arial, sans-serif\" font-size=\"50\" fill=\"#ffffff\" font-weight=\"800\">{palette['title']}</text>
  <text x=\"140\" y=\"132\" font-family=\"Inter, Arial, sans-serif\" font-size=\"26\" fill=\"#d1d5db\" font-weight=\"500\">{palette['sub']}</text>
  <text x=\"845\" y=\"205\" text-anchor=\"end\" font-family=\"Inter, Arial, sans-serif\" font-size=\"32\" fill=\"{palette['dot']}\" font-weight=\"700\">QuantumShield™</text>
  <g fill=\"{palette['dot']}\"> 
    <circle cx=\"816\" cy=\"28\" r=\"3\"/><circle cx=\"832\" cy=\"28\" r=\"3\"/><circle cx=\"848\" cy=\"28\" r=\"3\"/><circle cx=\"864\" cy=\"28\" r=\"3\"/>
    <circle cx=\"816\" cy=\"42\" r=\"3\"/><circle cx=\"832\" cy=\"42\" r=\"3\"/><circle cx=\"848\" cy=\"42\" r=\"3\"/><circle cx=\"864\" cy=\"42\" r=\"3\"/>
    <circle cx=\"816\" cy=\"56\" r=\"3\"/><circle cx=\"832\" cy=\"56\" r=\"3\"/><circle cx=\"848\" cy=\"56\" r=\"3\"/><circle cx=\"864\" cy=\"56\" r=\"3\"/>
  </g>
</svg>"""
    return Response(svg, mimetype='image/svg+xml')


@app.route('/labels/embed.js', methods=['GET'])
def labels_embed_js():
    """Public script for third-party embedding of QuantumShield text labels."""
    js = """
(function(){
  function currentScript(){
    if(document.currentScript) return document.currentScript;
    var scripts = document.getElementsByTagName('script');
    return scripts[scripts.length - 1];
  }
  var script = currentScript();
  if(!script) return;

  var scanId = script.getAttribute('data-scan-id') || script.getAttribute('data-scan') || '';
  if(!scanId){
    console.error('[QuantumShield] Missing data-scan-id for embedded label.');
    return;
  }
  var variant = script.getAttribute('data-variant') || 'auto';
    var width = parseInt(script.getAttribute('data-width') || '920', 10);
  var maxWidth = script.getAttribute('data-max-width') || '100%';
    var theme = (script.getAttribute('data-theme') || 'dark').toLowerCase();
  var base = script.getAttribute('data-domain') || script.src.split('/labels/embed.js')[0];
    var dataUrl = base + '/labels/embed-data/' + encodeURIComponent(scanId) + '.json?variant=' + encodeURIComponent(variant);

    function paletteFor(v){
        if(v === 'proof'){
            return {bg:'#123f2c', border:'#2ed39a', accent:'#2ed39a', title:'#f8fffb', text:'#d6f6ea'};
        }
        if(v === 'hybrid'){
            return {bg:'#152347', border:'#67a3ff', accent:'#67a3ff', title:'#f5f9ff', text:'#d8e7ff'};
        }
        if(v === 'vulnerable'){
            return {bg:'#4a1a1f', border:'#ff6b6b', accent:'#ff6b6b', title:'#fff5f5', text:'#ffd9d9'};
        }
        return theme === 'light'
            ? {bg:'#f8fafc', border:'#334155', accent:'#0ea5e9', title:'#0f172a', text:'#334155'}
            : {bg:'#0b1220', border:'#334155', accent:'#38bdf8', title:'#f1f5f9', text:'#cbd5e1'};
    }

    function makeChip(label, value, palette){
        var chip = document.createElement('span');
        chip.style.display = 'inline-flex';
        chip.style.alignItems = 'center';
        chip.style.gap = '6px';
        chip.style.border = '1px solid ' + palette.border;
        chip.style.borderRadius = '999px';
        chip.style.padding = '4px 10px';
        chip.style.fontSize = '12px';
        chip.style.lineHeight = '1.2';
        chip.style.color = palette.text;
        chip.style.background = 'rgba(255,255,255,0.03)';
        chip.textContent = label + ': ' + value;
        return chip;
    }

    function renderFallback(mount, message){
        mount.textContent = message;
        mount.style.fontFamily = 'Inter, Segoe UI, Arial, sans-serif';
        mount.style.border = '1px solid #475569';
        mount.style.borderRadius = '12px';
        mount.style.padding = '12px 14px';
        mount.style.maxWidth = maxWidth;
        mount.style.width = '100%';
        mount.style.background = '#0b1220';
        mount.style.color = '#dbeafe';
    }

    function renderCard(mount, data){
        var v = String(data.variant || variant || 'auto').toLowerCase();
        var palette = paletteFor(v);
        var recs = Array.isArray(data.recommendations) ? data.recommendations : [];
        var tlsVersions = Array.isArray(data.tls_versions) ? data.tls_versions : [];
        var keyExchanges = Array.isArray(data.key_exchanges) ? data.key_exchanges : [];

        mount.innerHTML = '';
        mount.style.maxWidth = maxWidth;
        mount.style.width = '100%';

        var card = document.createElement('section');
        card.style.fontFamily = 'Inter, Segoe UI, Arial, sans-serif';
        card.style.border = '1px solid ' + palette.border;
        card.style.borderRadius = '14px';
        card.style.padding = '14px';
        card.style.background = palette.bg;
        card.style.color = palette.text;
        card.style.boxSizing = 'border-box';
        card.style.width = (width > 0 ? width + 'px' : '100%');
        card.style.maxWidth = '100%';

        var h = document.createElement('div');
        h.style.display = 'flex';
        h.style.justifyContent = 'space-between';
        h.style.alignItems = 'center';
        h.style.gap = '10px';

        var title = document.createElement('strong');
        title.style.fontSize = '18px';
        title.style.letterSpacing = '0.02em';
        title.style.color = palette.title;
        title.textContent = String(data.status || 'QUANTUM STATUS');

        var brand = document.createElement('span');
        brand.style.fontSize = '12px';
        brand.style.color = palette.accent;
        brand.textContent = 'QuantumShield™';

        h.appendChild(title);
        h.appendChild(brand);
        card.appendChild(h);

        var sub = document.createElement('div');
        sub.style.marginTop = '6px';
        sub.style.fontSize = '13px';
        sub.style.lineHeight = '1.45';
        sub.textContent = 'Target: ' + (data.target || 'Unknown') + ' · Scan: ' + (data.scan_id || scanId);
        card.appendChild(sub);

        var chipRow = document.createElement('div');
        chipRow.style.display = 'flex';
        chipRow.style.flexWrap = 'wrap';
        chipRow.style.gap = '8px';
        chipRow.style.marginTop = '10px';

        chipRow.appendChild(makeChip('Compliance', String(data.compliance_score != null ? data.compliance_score : 0) + '%', palette));
        chipRow.appendChild(makeChip('TLS', tlsVersions.length ? tlsVersions.join(', ') : 'Unknown', palette));
        chipRow.appendChild(makeChip('Key Exchange', keyExchanges.length ? keyExchanges.join(', ') : 'Unknown', palette));
        card.appendChild(chipRow);

        var footer = document.createElement('div');
        footer.style.marginTop = '10px';
        footer.style.fontSize = '12px';
        footer.style.lineHeight = '1.45';
        var recText = recs.length ? recs.slice(0, 2).join(' | ') : 'No remediation notes in current scan.';
        footer.textContent = 'Recommendations: ' + recText;
        card.appendChild(footer);

        if(data.scanned_at){
            var ts = document.createElement('div');
            ts.style.marginTop = '6px';
            ts.style.fontSize = '11px';
            ts.style.opacity = '0.9';
            ts.textContent = 'Scanned at: ' + data.scanned_at;
            card.appendChild(ts);
        }

        mount.appendChild(card);
    }

  var targetId = script.getAttribute('data-target');
  var mount = targetId ? document.getElementById(targetId) : null;
  if(!mount){
    mount = document.createElement('div');
    script.parentNode.insertBefore(mount, script.nextSibling);
  }

    fetch(dataUrl, { credentials: 'omit', cache: 'no-store' })
        .then(function(resp){
            if(!resp.ok) throw new Error('embed data http ' + resp.status);
            return resp.json();
        })
        .then(function(payload){
            if(!payload || payload.status !== 'success' || !payload.data){
                throw new Error('invalid payload');
            }
            renderCard(mount, payload.data);
        })
        .catch(function(err){
            console.error('[QuantumShield] text embed render failed:', err);
            renderFallback(mount, 'QuantumShield label unavailable for scan ' + scanId + '.');
        });
})();
"""
    return Response(js, mimetype='application/javascript')


@app.route('/labels/embed-data/<scan_id>.json', methods=['GET'])
def labels_embed_data(scan_id: str):
    """Public JSON payload for third-party text embed labels."""
    report = _load_report_for_scan(scan_id)
    if not report:
        response = jsonify({"status": "error", "message": "Scan not found"})
        response.status_code = 404
        response.headers["Access-Control-Allow-Origin"] = "*"
        response.headers["Cache-Control"] = "no-store"
        return response

    requested_variant = str(request.args.get("variant") or "auto").strip().lower()
    payload = _build_public_embed_payload(scan_id, report)
    if requested_variant in {"proof", "hybrid", "vulnerable"}:
        payload["variant"] = requested_variant
        payload["status"] = {
            "proof": "QUANTUM PROOF",
            "hybrid": "QUANTUM HYBRID",
            "vulnerable": "QUANTUM VULNERABLE",
        }.get(requested_variant, payload.get("status"))

    response = jsonify({"status": "success", "data": payload})
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Cache-Control"] = "no-store"
    return response


@app.route('/results/<scan_id>/export_pdf')
@login_required
def export_pdf(scan_id: str):
    """Server-side PDF export for a scan result.

    Generates charts server-side and returns a PDF file.
    """
    import re as _re
    if not _re.match(r'^[a-f0-9A-F\-]+$', scan_id):
        return jsonify({'error': 'Invalid scan ID.'}), 404

    report = scan_store.get(scan_id)
    if not report:
        report_path = os.path.join(RESULTS_DIR, f"{scan_id}_report.json")
        if os.path.exists(report_path):
            with open(report_path, 'r', encoding='utf-8') as fh:
                report = json.load(fh)
                scan_store[scan_id] = report
        else:
            report = db.get_scan(scan_id)
            if report:
                scan_store[scan_id] = report
            else:
                return jsonify({'error': 'Scan not found.'}), 404

    try:
        pdf_io = generate_report_pdf(report, scan_id=scan_id)
        return send_file(pdf_io, mimetype='application/pdf', download_name=f"{scan_id}_report.pdf", as_attachment=True)
    except Exception as e:
        logger.exception('Failed to generate/export PDF: %s', e)
        return jsonify({'error': 'PDF generation failed.'}), 500


@app.route("/cbom/<scan_id>")
@login_required
def download_cbom(scan_id: str):
    """Download CBOM JSON file (disk → MySQL fallback)."""
    import re as _re
    if not _re.match(r'^[a-f0-9A-F\-]+$', scan_id):
        return jsonify({"error": "Invalid scan ID."}), 404
    cbom_path = os.path.join(RESULTS_DIR, f"{scan_id}_cbom.json")
    if os.path.exists(cbom_path):
        try:
            _audit("scan", "download_cbom", "success", target_scan_id=scan_id, details={"source": "disk"})
            return send_file(
                cbom_path,
                mimetype="application/json",
                as_attachment=True,
                download_name=f"cbom_{scan_id}.json",
            )
        except Exception as err:
            logger.error(f"Error serving CBOM from disk: {err}")
            return jsonify({"error": "Could not serve CBOM file"}), 500
    
    # Fallback: try MySQL
    try:
        cbom_data = db.get_cbom(scan_id)
        if cbom_data:
            _audit("scan", "download_cbom", "success", target_scan_id=scan_id, details={"source": "database"})
            return jsonify({"status": "success", "data": cbom_data}), 200
    except Exception as db_err:
        logger.warning(f"Failed to retrieve CBOM from database: {db_err}")
    
    _audit("scan", "download_cbom", "failed", target_scan_id=scan_id, details={"reason": "not_found"})
    return jsonify({"error": "CBOM not found"}), 404


@app.route('/api/ai/chat', methods=['POST'])
@login_required
def api_ai_chat():
    """Proxy endpoint to local LM server (LM Studio).
    Accepts JSON: { message: str, history: [...], model: str (optional) }
    """
    payload = request.get_json(silent=True) or {}
    message = str(payload.get('message') or '')
    history = payload.get('history') or []
    model = str(payload.get('model') or 'liquid/lfm2.5-1.2b')
    # Prefer system prompt provided in request, otherwise allow override from environment
    base_system_prompt = payload.get('system_prompt') or os.environ.get('QSS_AI_SYSTEM_PROMPT') or (
        "You are the QuantumShield assistant. Provide concise, factual, and actionable security guidance based on any scan data supplied."
    )

    # Non-negotiable assistant guardrails for data truthfulness and soft-delete awareness.
    # These are appended even when callers provide an explicit system prompt.
    hard_guardrails = (
        "\n\n"
        "QuantumShield data truth policy (mandatory):\n"
        "1) Use only attached/internal context data. Never invent assets, metrics, endpoint states, or vulnerabilities.\n"
        "2) Treat soft-deleted records as excluded from active posture. Active records are those not marked deleted (e.g., is_deleted=false and/or deleted_at is null where applicable).\n"
        "3) If an endpoint/context fetch is unavailable or returns errors (including 404), classify it as a data retrieval gap, not a security incident by itself.\n"
        "4) If evidence is incomplete, explicitly say 'insufficient data' and request the exact missing data needed.\n"
        "5) Prefer persisted realtime telemetry semantics over stale assumptions; cite the provided values directly when possible."
    )
    system_prompt = f"{str(base_system_prompt).strip()}{hard_guardrails}"

    # Build message list in OpenAI chat format
    messages = []
    messages.append({"role": "system", "content": system_prompt})
    try:
        for m in history:
            if isinstance(m, dict) and m.get('role') and m.get('content'):
                messages.append({"role": m.get('role'), "content": m.get('content')})
            elif isinstance(m, str):
                messages.append({"role": "user", "content": m})
    except Exception:
        pass
    messages.append({"role": "user", "content": message})

    ai_host = os.environ.get('AI_SERVER_URL', 'http://127.0.0.1:1234')
    endpoint = f"{ai_host.rstrip('/')}/v1/chat/completions"

    result = None
    try:
        # Build optional headers including API key for external AI servers
        headers = {'Content-Type': 'application/json'}
        ai_key = os.environ.get('AI_SERVER_API_KEY') or os.environ.get('QSS_AI_SERVER_API_KEY')
        if ai_key:
            # Prefer standard Bearer Authorization, also include X-API-Key for compatibility
            headers['Authorization'] = f"Bearer {ai_key}"
            headers['X-API-Key'] = ai_key

        try:
            import requests as _requests
            resp = _requests.post(endpoint, json={"model": model, "messages": messages}, headers=headers, timeout=60)
            resp.raise_for_status()
            result = resp.json()
        except Exception as _err:
            # Fallback to stdlib (urllib) if requests not available or direct call failed
            import urllib.request as _ur, json as _json
            req = _ur.Request(endpoint, data=_json.dumps({"model": model, "messages": messages}).encode('utf-8'), headers=headers)
            with _ur.urlopen(req, timeout=60) as r:
                result = _json.load(r)
    except Exception as exc:
        logger.exception("AI proxy error: %s", exc)
        return jsonify({'ok': False, 'error': 'AI backend unreachable'}), 502

    # Try to extract assistant text from common response shapes
    reply = None
    try:
        if isinstance(result, dict):
            # OpenAI-like: choices[0].message.content
            choices = result.get('choices') or result.get('outputs') or None
            if isinstance(choices, list) and len(choices) > 0:
                ch = choices[0]
                if isinstance(ch.get('message'), dict):
                    content = ch['message'].get('content')
                    if isinstance(content, str):
                        reply = content
                    elif isinstance(content, dict):
                        reply = content.get('text') or content.get('message')
                    elif isinstance(content, list):
                        parts = []
                        for p in content:
                            if isinstance(p, str): parts.append(p)
                            elif isinstance(p, dict): parts.append(p.get('text') or '')
                        reply = ''.join(parts)
                elif 'text' in ch:
                    reply = ch.get('text')
            # Fallback: /v1/responses style
            if not reply:
                out = result.get('output') or result.get('outputs') or result.get('response') or None
                if out:
                    if isinstance(out, list) and len(out) > 0:
                        first = out[0]
                        if isinstance(first, dict):
                            if 'content' in first:
                                c = first['content']
                                if isinstance(c, list):
                                    for item in c:
                                        if isinstance(item, dict) and item.get('type') in ('output_text','text'):
                                            reply = item.get('text') or item.get('data') or item.get('content')
                                            if reply: break
                                elif isinstance(c, str):
                                    reply = c
                            if not reply and 'text' in first:
                                reply = first.get('text')
    except Exception:
        reply = None

    # Final fallback: stringify full result
    if not reply:
        try:
            import json as _json
            reply = _json.dumps(result)
        except Exception:
            reply = str(result)

    return jsonify({'ok': True, 'reply': reply, 'raw': result}), 200


@app.route("/api/badge/<path:target>")
def api_badge(target: str):
    """Dynamic SVG badge showing Quantum-Safe status."""
    report = db.get_latest_scan_by_target(target)
    
    if not report:
        status_text = "Unknown"
        color = "#9ca3af" # gray-400
    else:
        overview = report.get("overview", {})
        if overview.get("quantum_vulnerable", 0) > 0:
            status_text = "Vulnerable"
            color = "#c45c5c" # muted red
        elif overview.get("quantum_safe", 0) > 0:
            status_text = "Quantum Safe"
            color = "#5b9e6f" # muted green
        elif report.get("status") == "error":
            status_text = "Scan Failed"
            color = "#c9a24e" # muted amber
        else:
            status_text = "Status: OK"
            color = "#5ba4b5" # teal
            
    # Simple standardized SVG badge layout (similar to shields.io)
    svg = f'''<svg xmlns="http://www.w3.org/2000/svg" width="220" height="28" role="img" aria-label="QuantumShield: {status_text}">
      <title>QuantumShield: {status_text}</title>
      <linearGradient id="s" x2="0" y2="100%">
        <stop offset="0" stop-color="#bbb" stop-opacity=".1"/>
        <stop offset="1" stop-opacity=".1"/>
      </linearGradient>
      <clipPath id="r">
        <rect width="220" height="28" rx="4" fill="#fff"/>
      </clipPath>
      <g clip-path="url(#r)">
        <rect width="110" height="28" fill="#1e2128"/>
        <rect x="110" width="110" height="28" fill="{color}"/>
        <rect width="220" height="28" fill="url(#s)"/>
      </g>
      <g fill="#fff" text-anchor="middle" font-family="Verdana,Geneva,DejaVu Sans,sans-serif" text-rendering="geometricPrecision" font-size="110">
        <text aria-hidden="true" x="550" y="190" fill="#010101" fill-opacity=".3" transform="scale(.1)" textLength="900">QuantumShield</text>
        <text x="550" y="180" transform="scale(.1)" fill="#fff" textLength="900">QuantumShield</text>
        <text aria-hidden="true" x="1650" y="190" fill="#010101" fill-opacity=".3" transform="scale(.1)" textLength="900">{status_text}</text>
        <text x="1650" y="180" transform="scale(.1)" fill="#fff" textLength="900">{status_text}</text>
      </g>
    </svg>'''
    
    response = Response(svg, mimetype="image/svg+xml")
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    return response


@app.route("/api/scan", methods=["GET", "POST"])
@csrf.exempt  # Machine clients send API keys, not CSRF tokens
@limiter.limit("60 per hour")
@require_api_key
def api_scan():
    """REST API endpoint for CI/CD integration. Requires X-API-Key header.

    GET  /api/scan?target=example.com&api_key=qss_...
    POST /api/scan  {"target": "example.com", "api_key": "qss_..."}
    """
    from flask import g as _g
    api_user = _g.api_user

    if request.method == "GET":
        target = request.args.get("target", "")
    else:
        data = request.get_json(silent=True) or {}
        target = data.get("target", "") or request.form.get("target", "")

    if not target:
        return jsonify({"error": "Missing 'target' parameter"}), 400

    # Enforce role on API users too
    if api_user.get("role") not in SCAN_ROLES:
        db.append_audit_log(
            event_category="api",
            event_type="api_scan_forbidden",
            status="denied",
            actor_user_id=api_user.get("id"),
            actor_username=api_user.get("username"),
            ip_address=_get_request_ip(),
            request_method=request.method,
            request_path=request.path,
            details={"role": api_user.get("role"), "required_roles": list(SCAN_ROLES)},
        )
        return jsonify({"error": "Your API key role does not permit scanning"}), 403

    try:
        clean_target, _ = sanitize_target(target)
        report = run_scan_pipeline(
            clean_target,
            scan_kind="api_key_scan",
            scanned_by=api_user.get("username"),
        )
        
        # Ensure persistence: save to both JSON and MySQL
        try:
            if not app.config.get("TESTING", False) and not bool(report.get("orm_persisted")):
                db.save_scan(report)
        except Exception as db_err:
            logger.warning(f"Failed to save scan to MySQL: {db_err}")
        
        db.append_audit_log(
            event_category="api",
            event_type="api_scan",
            status="success",
            actor_user_id=api_user.get("id"),
            actor_username=api_user.get("username"),
            target_scan_id=report.get("scan_id"),
            ip_address=_get_request_ip(),
            request_method=request.method,
            request_path=request.path,
            details={"target": clean_target},
        )
        return jsonify({"status": "success", "data": report}), 200
    except Exception as exc:
        _audit("scan", "api_scan", "failed", details={"target": target, "error": str(exc)})
        logger.exception(f"API scan failed for target {target}: {exc}")
        return jsonify({"status": "error", "message": str(exc)}), 500



@app.route("/api/scans-legacy")
@csrf.exempt
@require_api_key
def api_list_scans():
    """List all stored scan results. Requires X-API-Key header."""
    from flask import g as _g
    api_user = _g.api_user
    try:
        scans = [
            {
                "scan_id": r.get("scan_id"),
                "target": r.get("target"),
                "status": r.get("status"),
                "generated_at": r.get("generated_at"),
                "overview": r.get("overview"),
            }
            for r in scan_store.values()
        ]
        _audit("api", "api_list_scans", "success", details={"scan_count": len(scans)})
        return jsonify(scans), 200
    except Exception as exc:
        _audit("api", "api_list_scans", "failed", details={"error": str(exc)})
        return jsonify({"status": "error", "message": str(exc)}), 500


@app.route("/docs")
def docs():
    """Comprehensive documentation and technical guide."""
    return render_template("docs.html")


@app.route("/profile", methods=["GET"])
@login_required
def profile():
    """User profile page for account details."""
    user_data = db.get_user_by_id(current_user.id)
    return render_template("profile.html", user=user_data)


@app.route("/profile/rotate-api-key", methods=["POST"])
@login_required
def rotate_api_key():
    """Legacy route: API key rotation now lives in the admin API portal."""
    if str(getattr(current_user, "role", "") or "").strip().lower() != "admin":
        flash("API key rotation is managed by administrators.", "error")
        return redirect(url_for("profile"))

    db.revoke_api_key(current_user.id)
    new_key = db.generate_api_key(current_user.id)
    if new_key:
        _audit("api", "api_key_rotated", "success")
        flash(f"NEW_API_KEY: {new_key}", "api_key")  # One-time display
    else:
        _audit("api", "api_key_rotated", "failed")
        flash("Failed to rotate API key. Try again.", "error")
    return redirect(url_for("admin_api"))


@app.route("/admin/users/<user_id>/regen-api-key", methods=["POST"])
@role_required(list(ADMIN_PANEL_ROLES))
def admin_regen_api_key(user_id: str):
    """Admin: revoke and reissue an API key for any user. Supports form OR JSON."""
    wants_json = _expects_json_response()
    
    user = db.get_user_by_id(user_id)
    if not user:
        if wants_json:
            return jsonify({"status": "error", "message": "User not found."}), 404
        flash("User not found.", "error")
        return redirect(url_for("admin_users"))
    
    db.revoke_api_key(user_id)
    new_key = db.generate_api_key(user_id)
    if new_key:
        _audit("admin", "api_key_regen", "success", target_user_id=user_id,
               details={"username": user.get("username")})
        if wants_json:
            return jsonify({
                "status": "success",
                "message": f"API key regenerated for {user.get('username')}.",
                "user_id": user_id,
                "username": user.get("username"),
                "api_key": new_key
            }), 200
        flash(f"New API key for {user.get('username')}: {new_key}", "api_key")
    else:
        _audit("admin", "api_key_regen", "failed", target_user_id=user_id)
        if wants_json:
            return jsonify({"status": "error", "message": "Failed to regenerate API key."}), 500
        flash("Failed to regenerate API key.", "error")
    return redirect(url_for("admin_users"))


# ── Report Generation Engine ─────────────────────────────────────────

def _make_pdf_report(report_type: str, username: str, sections: list[str], pdf_password: str | None = None) -> bytes:
    """Build a PDF byte-stream for the requested report type.

    Uses reportlab for full cross-platform support (Windows + Linux).
    Returns raw PDF bytes suitable for serving as a download.
    """
    from io import BytesIO
    from reportlab.lib.pagesizes import A4
    from reportlab.lib import colors
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import cm
    from reportlab.platypus import (
        SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
    )

    buf = BytesIO()
    doc_kwargs = {
        "pagesize": A4,
        "leftMargin": 2.2 * cm,
        "rightMargin": 2.2 * cm,
        "topMargin": 2.5 * cm,
        "bottomMargin": 2 * cm,
        "title": f"PNB Hackathon 2026 — {report_type}",
        "author": "QuantumShield Platform",
    }

    password_text = str(pdf_password or "").strip()
    if password_text:
        try:
            from reportlab.lib.pdfencrypt import StandardEncryption

            doc_kwargs["encrypt"] = StandardEncryption(
                userPassword=password_text,
                ownerPassword=password_text,
                canPrint=1,
                canModify=0,
                canCopy=0,
                canAnnotate=0,
                strength=128,
            )
        except Exception as exc:
            logger.warning("PDF encryption unavailable; generating plain PDF: %s", exc)

    doc = SimpleDocTemplate(buf, **doc_kwargs)

    styles = getSampleStyleSheet()
    TEAL = colors.HexColor("#4a9ead")
    DARK = colors.HexColor("#0f1219")
    GREY = colors.HexColor("#64748b")

    h1 = ParagraphStyle("H1", parent=styles["Title"], fontSize=20, leading=26,
                         textColor=DARK, spaceAfter=4)
    h2 = ParagraphStyle("H2", parent=styles["Heading2"], fontSize=13, leading=18,
                         textColor=TEAL, spaceBefore=14, spaceAfter=4)
    body = ParagraphStyle("Body", parent=styles["Normal"], fontSize=9.5, leading=14,
                          textColor=colors.HexColor("#1a2030"))
    caption = ParagraphStyle("Caption", parent=styles["Normal"], fontSize=8,
                              textColor=GREY, spaceAfter=6)

    now_str = datetime.now(timezone.utc).strftime("%d/%m/%Y %H:%M UTC")
    story = [
        Paragraph("PNB Hackathon 2026", ParagraphStyle("Brand", parent=styles["Normal"],
                  fontSize=9, textColor=TEAL, spaceAfter=2)),
        Paragraph(report_type, h1),
        HRFlowable(width="100%", thickness=1, color=TEAL, spaceAfter=8),
        Paragraph(f"Generated: {now_str} &nbsp;|&nbsp; Prepared for: {username}", caption),
        Spacer(1, 0.3 * cm),
    ]

    inv = _build_asset_inventory_view()
    dis = _build_asset_discovery_view()

    cb_rows: list[tuple[str, str, str, str]] = []
    cb_key_dist: dict[str, int] = {}
    cb_cipher_usage: dict[str, int] = {}
    cb_protocols: dict[str, int] = {}
    pqc_rows: list[tuple[str, str, str]] = []
    cyber_rows: list[tuple[str, str]] = []

    if app.config.get("TESTING", False):
        for scan in scan_store.values():
            if scan.get("status") != "complete":
                continue
            for tr in (scan.get("tls_results") or []):
                key = str(tr.get("key_size") or tr.get("key_length") or "0")
                cb_key_dist[key] = cb_key_dist.get(key, 0) + 1
                for cs in (tr.get("cipher_suites") or []):
                    cb_cipher_usage[cs] = cb_cipher_usage.get(cs, 0) + 1
                proto = str(tr.get("tls_version") or "Unknown")
                cb_protocols[proto] = cb_protocols.get(proto, 0) + 1
                cb_rows.append((
                    _host_from_target(str(scan.get("target", ""))) or str(scan.get("target", "")),
                    key,
                    (tr.get("cipher_suites") or ["Unknown"])[0],
                    (tr.get("issuer") or {}).get("O", "Unknown") if isinstance(tr.get("issuer"), dict) else "Unknown",
                ))

        for scan in scan_store.values():
            if scan.get("status") != "complete":
                continue
            host = _host_from_target(str(scan.get("target", "")))
            for pqc in (scan.get("pqc_assessments") or []):
                score = int(pqc.get("pqc_score") or pqc.get("score") or 0)
                status = "Elite" if score >= 800 else ("Standard" if score >= 500 else ("Legacy" if score >= 300 else "Critical"))
                pqc_rows.append((host, str(score), status))

        for scan in scan_store.values():
            if scan.get("status") != "complete":
                continue
            overview = scan.get("overview") or {}
            raw = overview.get("average_compliance_score") or 0
            norm = min(int(raw * 10) if raw <= 100 else int(raw), 1000)
            cyber_rows.append((
                str(scan.get("target", "")),
                str(norm),
            ))
    else:
        from src.services.cbom_service import CbomService
        from src.services.pqc_service import PQCService
        from src.services.cyber_reporting_service import CyberReportingService
        from src.services.certificate_telemetry_service import CertificateTelemetryService

        cbom_data = CbomService.get_cbom_dashboard_data(limit=20)
        for key, count in cbom_data.get("key_length_distribution", {}).items():
            cb_key_dist[str(key)] = int(count or 0)
        for cipher, count in cbom_data.get("cipher_usage", {}).items():
            cb_cipher_usage[str(cipher)] = int(count or 0)
        for proto, count in cbom_data.get("protocols", {}).items():
            cb_protocols[str(proto)] = int(count or 0)
        for row in cbom_data.get("applications", [])[:20]:
            cb_rows.append((
                str(row.get("asset_name") or "Unknown"),
                str(row.get("key_length") or "0"),
                str(row.get("cipher_suite") or "Unknown"),
                str(row.get("ca") or "Unknown"),
            ))

        pqc_data = PQCService.get_pqc_dashboard_data(limit=20)
        for row in pqc_data.get("applications", [])[:20]:
            pqc_rows.append((
                str(row.get("asset_name") or row.get("target") or "Unknown"),
                str(int(float(row.get("score") or 0))),
                str(row.get("status") or "Critical"),
            ))

        cyber_data = CyberReportingService.get_cyber_rating_data(limit=20)
        for row in cyber_data.get("applications", [])[:20]:
            cyber_rows.append((
                str(row.get("target") or "Unknown"),
                str(int(float(row.get("score") or 0))),
            ))

        cert_service = CertificateTelemetryService()
        cert_inventory = cert_service.get_certificate_inventory(limit=20)
        for cert in cert_inventory:
            key = str(cert.get("key_length") or "0")
            cb_key_dist[key] = cb_key_dist.get(key, 0) + 1
            cb_cipher_usage[str(cert.get("cipher_suite") or "Unknown")] = cb_cipher_usage.get(str(cert.get("cipher_suite") or "Unknown"), 0) + 1
            cb_protocols[str(cert.get("tls_version") or "Unknown")] = cb_protocols.get(str(cert.get("tls_version") or "Unknown"), 0) + 1
            cb_rows.append((
                str(cert.get("asset") or "Unknown"),
                key,
                str(cert.get("cipher_suite") or "Unknown"),
                str(cert.get("issuer") or "Unknown"),
            ))

    section_data: dict[str, list] = {
        "Asset Inventory": [
            ("KPI", "Value"),
            ("Total Assets", str(inv["kpis"]["total_assets"])),
            ("Public Web Apps", str(inv["kpis"]["public_web_apps"])),
            ("APIs", str(inv["kpis"]["apis"])),
            ("Servers", str(inv["kpis"]["servers"])),
            ("Expiring Certificates", str(inv["kpis"]["expiring_certificates"])),
            ("High Risk Assets", str(inv["kpis"]["high_risk_assets"])),
        ],
        "Asset Discovery": [
            ("Category", "Count"),
            ("Domains discovered", str(dis["overview"]["domains"])),
            ("SSL certificates", str(dis["overview"]["ssl"])),
            ("IP/Subnets", str(dis["overview"]["ip_subnets"])),
            ("Software components", str(dis["overview"]["software"])),
            ("New (unconfirmed)", str(dis["status_counts"].get("New", 0))),
        ],
        "CBOM": [("Metric", "Value")] + [
            ("Unique Applications", str(len({r[0] for r in cb_rows}))),
            ("Active Certificates", str(len(cb_rows))),
            ("Key Length Buckets", str(len(cb_key_dist))),
            ("Cipher Suites", str(len(cb_cipher_usage))),
            ("TLS Protocol Families", str(len(cb_protocols))),
        ],
        "PQC Posture": [("Asset", "Score", "Status")] + (pqc_rows[:20] if pqc_rows else [("No data", "0", "N/A")]),
        "Cyber Rating": [("URL", "PQC Score")] + (cyber_rows[:20] if cyber_rows else [("No data", "0")]),
    }

    # ── Aggregate metrics from live scan store ───────────────────────
    live_scans = [s for s in scan_store.values() if s.get("status") == "complete"]
    if live_scans:
        story.append(Paragraph("Live Scan Summary", h2))
        live_rows = [("Target", "Score", "Status")]
        for s in live_scans[:15]:
            overview = s.get("overview") or {}
            live_rows.append((
                str(s.get("target", ""))[:60],
                str(overview.get("average_compliance_score", "—")),
                str(s.get("status", "")),
            ))
        t = Table(live_rows, colWidths=[10 * cm, 3 * cm, 3.5 * cm])
        t.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), TEAL),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTSIZE", (0, 0), (-1, -1), 8.5),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.HexColor("#f8fafb"), colors.white]),
            ("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#d1d5db")),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
            ("TOPPADDING", (0, 0), (-1, -1), 4),
        ]))
        story.append(t)
        story.append(Spacer(1, 0.4 * cm))

    # ── Requested sections ───────────────────────────────────────────
    selected = sections if sections else list(section_data.keys())
    for sec in selected:
        rows = section_data.get(sec)
        if not rows:
            continue
        story.append(Paragraph(sec, h2))
        col_count = len(rows[0])
        col_width = 16.6 * cm / col_count
        t = Table(rows, colWidths=[col_width] * col_count)
        t.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), TEAL),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTSIZE", (0, 0), (-1, -1), 9),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.HexColor("#f8fafb"), colors.white]),
            ("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#d1d5db")),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
            ("TOPPADDING", (0, 0), (-1, -1), 4),
        ]))
        story.append(t)
        story.append(Spacer(1, 0.3 * cm))

    # ── Footer note ──────────────────────────────────────────────────
    story.append(Spacer(1, 0.8 * cm))
    story.append(HRFlowable(width="100%", thickness=0.5, color=GREY))
    story.append(Paragraph(
        "This report is confidential and intended for authorised PNB personnel only. "
        "Generated by QuantumShield | PNB Hackathon 2026.",
        ParagraphStyle("Footer", parent=styles["Normal"], fontSize=7.5, textColor=GREY, spaceBefore=4),
    ))

    doc.build(story)
    buf.seek(0)
    return buf.read()


# ── Scheduled-report JSON store (DB-independent) ─────────────────────
# Stored as: RESULTS_DIR/report_schedules.json
_SCHEDULES_PATH = os.path.join(RESULTS_DIR, "report_schedules.json")


def _load_schedules() -> list[dict]:
    db_rows = db.list_report_schedules(limit=1000)
    if db_rows:
        return db_rows
    try:
        with open(_SCHEDULES_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return []


def _save_schedules(schedules: list[dict]) -> None:
    ok_count = 0
    for row in schedules:
        if db.save_report_schedule(row):
            ok_count += 1
    if ok_count == len(schedules):
        return
    with open(_SCHEDULES_PATH, "w", encoding="utf-8") as f:
        json.dump(schedules, f, indent=2, default=str)


def _safe_report_output_path(save_path: str, filename: str) -> str:
    base_dir = os.path.join(RESULTS_DIR, "generated_reports")
    raw_subdir = str(save_path or "").strip().replace("\\", "/")
    if not raw_subdir:
        subdir = "manual"
    else:
        parts = [p for p in raw_subdir.split("/") if p and p not in (".", "..")]
        cleaned = []
        for part in parts:
            safe = "".join(ch for ch in part if ch.isalnum() or ch in ("-", "_", "."))
            if safe:
                cleaned.append(safe)
        subdir = os.path.join(*cleaned) if cleaned else "manual"

    out_dir = os.path.join(base_dir, subdir)
    os.makedirs(out_dir, exist_ok=True)
    return os.path.join(out_dir, filename)


def _send_report_email(email_list: str, report_type: str, filename: str, pdf_bytes: bytes) -> tuple[bool, str]:
    recipients = [e.strip() for e in re.split(r"[;,]", str(email_list or "")) if e.strip()]
    if not recipients:
        return False, "no_recipients"

    msg = Message(
        subject=f"QuantumShield Report — {report_type}",
        recipients=recipients,
        body=(
            "Attached is your generated QuantumShield report.\n\n"
            f"Report Type: {report_type}\n"
            f"Generated At: {datetime.now(timezone.utc).isoformat()}\n"
        ),
    )
    msg.attach(filename=filename, content_type="application/pdf", data=pdf_bytes)
    mail.send(msg)
    return True, "sent"


@app.route("/favicon.ico")
def favicon():
    """Silence browser 404s on favicon."""
    return "", 204


@app.route("/report/generate", methods=["POST"])
@login_required
@limiter.limit("10 per hour")
def generate_report():
    """Generate a PDF report on demand and return it as a file download.

    Accepts JSON or form data. Input fields:
      report_type  – string label (e.g. "Executive Reporting")
      sections     – JSON array of section names to include (optional)
      password     – optional password to note in filename (not encrypted yet)
    """
    if request.is_json:
        data = request.get_json(silent=True) or {}
    else:
        data = request.form

    report_type = (data.get("report_type") or "Executive Reporting").strip()[:120]
    raw_sections = data.get("sections") or "[]"
    if isinstance(raw_sections, str):
        try:
            sections = json.loads(raw_sections)
        except (ValueError, TypeError):
            sections = []
    else:
        sections = list(raw_sections)

    username = getattr(current_user, "username", "user")
    email_enabled = str(data.get("email_enabled") or "").lower() in ("true", "1", "on")
    email_list = str(data.get("email_list") or "").strip()
    save_enabled = str(data.get("save_enabled") or "").lower() in ("true", "1", "on")
    save_path = str(data.get("save_path") or "").strip()
    password_protect = str(data.get("password_protect") or "").lower() in ("true", "1", "on")
    password = str(data.get("password") or "").strip()
    if password_protect and not password:
        return jsonify({"status": "error", "message": "Password is required when password protection is enabled."}), 400

    _audit("report", "generate_pdf", "success", details={
        "report_type": report_type,
        "sections": sections,
        "username": username,
        "email_enabled": email_enabled,
        "save_enabled": save_enabled,
        "password_protect": password_protect,
    })

    pdf_bytes = _make_pdf_report(
        report_type,
        username,
        sections,
        pdf_password=password if password_protect else None,
    )
    safe_type = "".join(c if c.isalnum() else "_" for c in report_type)[:40]
    filename = f"PNB_{safe_type}_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.pdf"

    if save_enabled:
        try:
            out_path = _safe_report_output_path(save_path, filename)
            with open(out_path, "wb") as f:
                f.write(pdf_bytes)
        except Exception as exc:
            logger.error("Failed to save generated report: %s", exc)
            _audit("report", "save_pdf_failed", "failed", details={"error": str(exc), "save_path": save_path})

    if email_enabled:
        try:
            sent, info = _send_report_email(email_list, report_type, filename, pdf_bytes)
            if not sent:
                _audit("report", "email_pdf_skipped", "failed", details={"reason": info})
            else:
                _audit("report", "email_pdf", "success", details={"recipients": email_list})
        except Exception as exc:
            logger.error("Failed to email generated report: %s", exc)
            _audit("report", "email_pdf", "failed", details={"error": str(exc), "recipients": email_list})

    return Response(
        pdf_bytes,
        status=200,
        mimetype="application/pdf",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "Content-Length": str(len(pdf_bytes)),
            "X-Report-Encrypted": "true" if password_protect else "false",
        },
    )


@app.route("/report/schedule", methods=["POST"])
@login_required
@limiter.limit("20 per hour")
def schedule_report():
    """Save a scheduled report configuration.

    Accepts JSON or form data and persists to report_schedules.json.
    Returns JSON with the created schedule id.
    """
    if request.is_json:
        data = request.get_json(silent=True) or {}
    else:
        data = dict(request.form)

    # Normalise form multi-values to single values where applicable
    def _single(v):
        return v[0] if isinstance(v, list) else (v or "")

    password_protect = str(_single(data.get("password_protect", ""))).lower() in ("true", "1", "on")
    password = str(_single(data.get("password", ""))).strip()
    if password_protect and not password:
        return jsonify({"status": "error", "message": "Password is required when password protection is enabled."}), 400

    schedule = {
        "id": uuid.uuid4().hex[:12],
        "created_by_id": str(getattr(current_user, "id", "")) or None,
        "created_by": getattr(current_user, "username", "unknown"),
        "created_at": datetime.now(timezone.utc).isoformat(),
        "enabled": str(_single(data.get("enabled", "true"))).lower() not in ("false", "0", "off", ""),
        "report_type": _single(data.get("report_type", "Executive Summary Report"))[:120],
        "frequency": _single(data.get("frequency", "Weekly"))[:32],
        "assets": _single(data.get("assets", "All Assets"))[:256],
        "sections": data.get("sections") if isinstance(data.get("sections"), list) else [],
        "schedule_date": _single(data.get("schedule_date", ""))[:20],
        "schedule_time": _single(data.get("schedule_time", ""))[:10],
        "timezone": _single(data.get("timezone", "UTC"))[:64],
        "email_list": _single(data.get("email_list", ""))[:512],
        "password_protect": password_protect,
        "pdf_password": password if password_protect else "",
        "save_path": _single(data.get("save_path", ""))[:512],
        "download_link": _single(data.get("download_link", "false")).lower() in ("true", "1", "on"),
        "status": "scheduled",
    }

    if not db.save_report_schedule(schedule):
        schedules = _load_schedules()
        schedules.append(schedule)
        _save_schedules(schedules)

    _audit("report", "schedule_created", "success", details={
        "schedule_id": schedule["id"],
        "report_type": schedule["report_type"],
        "frequency": schedule["frequency"],
        "password_protected": password_protect,
    })

    return jsonify({"status": "ok", "id": schedule["id"], "message": "Schedule saved successfully."})


@app.route("/report/schedules", methods=["GET"])
@login_required
def list_report_schedules():
    """Return all saved report schedules as JSON."""
    schedules = db.list_report_schedules(limit=1000)
    if schedules:
        return jsonify(schedules)
    return jsonify(_load_schedules())


# ── HTTP → HTTPS redirect server (stdlib only, no extra deps) ──────────────

def _make_http_redirect_app(https_port: int, https_host: str):
    """Minimal WSGI app that 301-redirects every HTTP request to HTTPS."""
    def _redirect(environ, start_response):
        host = environ.get("HTTP_HOST") or https_host
        base = host.split(":")[0]          # strip any port in Host header
        path = environ.get("PATH_INFO", "/")
        qs   = environ.get("QUERY_STRING", "")
        url  = f"https://{base}:{https_port}{path}"
        if qs:
            url += "?" + qs
        start_response("301 Moved Permanently", [
            ("Location", url),
            ("Content-Type", "text/plain"),
            ("Content-Length", "0"),
        ])
        return [b""]
    return _redirect


def _start_http_redirect_server(http_port: int, https_port: int, https_host: str) -> None:
    """Launch the redirect WSGI server in a background daemon thread."""
    import threading
    from wsgiref.simple_server import WSGIServer, WSGIRequestHandler

    class _Quiet(WSGIRequestHandler):
        def log_message(self, *_):
            pass   # suppress noisy per-request logs

    app_redirect = _make_http_redirect_app(https_port, https_host)
    try:
        srv = WSGIServer(("0.0.0.0", http_port), _Quiet)
        srv.set_app(app_redirect)
        threading.Thread(target=srv.serve_forever, daemon=True, name="http-redirect").start()
        print(f"  \u21a9\ufe0f  HTTP redirect active  http://0.0.0.0:{http_port} \u2192 HTTPS :{https_port}")
    except OSError as exc:
        print(f"  \u26a0\ufe0f  HTTP redirect server could not bind to port {http_port}: {exc}")
        print(f"     Change QSS_HTTP_REDIRECT_PORT in .env to a free port.")


# ── Main (WSGI-ready) ────────────────────────────────────────────────

@app.route("/recycle-bin", methods=["GET", "POST"])
@login_required
def recycle_bin():
    """Isolated dashboard for soft-deleted assets and scans.

    GET: Display soft-deleted items (Admin-only).
    POST actions (Admin-only):
      - restore_assets: Restore deleted assets
      - restore_scans: Restore deleted scans
      - delete_assets: Permanently purge deleted assets (hard delete, Admin-only)
      - delete_scans: Permanently purge deleted scans (hard delete, Admin-only)
    """
    from src.db import db_session
    from src.models import Asset, Scan, Certificate, PQCClassification, CBOMEntry, ComplianceScore, CBOMSummary, CyberRating, \
        DiscoveryDomain, DiscoverySSL, DiscoveryIP, DiscoverySoftware, Subdomain
    
    # Check admin/manager permission for destructive actions
    ALLOWED_RESTORE_ROLES = {"Admin", "Manager"}
    ALLOWED_HARD_DELETE_ROLES = {"Admin"}
    
    is_admin = current_user.role in ALLOWED_HARD_DELETE_ROLES if hasattr(current_user, 'role') else False
    is_manager = current_user.role in ALLOWED_RESTORE_ROLES if hasattr(current_user, 'role') else False
    wants_json = request.is_json or (request.accept_mimetypes.best == "application/json")

    def _payload() -> dict:
        if request.is_json:
            return request.get_json(silent=True) or {}
        return request.form.to_dict(flat=False)

    def _payload_value(data: dict, key: str, default: str = "") -> str:
        raw = data.get(key, default)
        if isinstance(raw, list):
            raw = raw[0] if raw else default
        return str(raw or default)

    def _payload_ids(data: dict, key: str) -> list[int]:
        raw = data.get(key)
        values: list[str] = []
        if isinstance(raw, list):
            values.extend(str(v).strip() for v in raw if str(v).strip())
        elif raw is not None:
            values.extend(part.strip() for part in str(raw).split(",") if part.strip())
        return [int(v) for v in values if v.isdigit()]

    def _json(message: str, code: int, **extra):
        return jsonify({
            "status": "success" if code < 400 else "error",
            "message": message,
            **extra,
        }), code

    if not is_admin:
        _audit("recycle_bin", "view", "denied", details={"required_role": "Admin", "actual_role": getattr(current_user, 'role', None)})
        if wants_json:
            return _json("Recycle Bin is restricted to Admin users.", 403)
        flash("Recycle Bin is restricted to Admin users.", "error")
        return redirect(url_for("quantumshield_dashboard.dashboard_home"))
    
    if request.method == "POST":
        payload = _payload()
        action = _payload_value(payload, "action")
        
        # Check permission for the action being requested
        if action in ["restore_assets", "restore_scans"] and not is_manager:
            _audit("recycle_bin", action, "denied", details={"required_role": "Admin or Manager", "actual_role": current_user.role})
            if wants_json:
                return _json("Only Admins and Managers can restore items.", 403)
            flash("Only Admins and Managers can restore items.", "error")
            return redirect(url_for("recycle_bin"))
        
        if action in ["delete_assets", "delete_scans"] and not is_admin:
            _audit("recycle_bin", action, "denied", details={"required_role": "Admin", "actual_role": current_user.role})
            if wants_json:
                return _json("Only Admins can permanently delete items.", 403)
            flash("Only Admins can permanently delete items.", "error")
            return redirect(url_for("recycle_bin"))
        
        try:
            if action == "restore_assets":
                asset_ids = _payload_ids(payload, "asset_ids")
                if asset_ids:
                    assets_to_restore = db_session.query(Asset).filter(Asset.id.in_(asset_ids), Asset.is_deleted == True).all()
                    for asset in assets_to_restore:
                        asset.is_deleted = False
                        asset.deleted_at = None
                        asset.deleted_by_user_id = None

                        # Restore child records tied to this asset
                        for model in (DiscoveryDomain, DiscoverySSL, DiscoveryIP, DiscoverySoftware, Certificate, PQCClassification, CBOMEntry, ComplianceScore, Subdomain):
                            try:
                                rows = db_session.query(model).filter(model.asset_id == asset.id, model.is_deleted == True).all()
                            except Exception:
                                rows = []
                            for row in rows:
                                row.is_deleted = False
                                row.deleted_at = None
                                row.deleted_by_user_id = None

                        # Restore scans linked by target and scan-bound child tables.
                        asset_target = str(getattr(asset, "name", "") or "").strip().lower()
                        if asset_target:
                            related_scans = db_session.query(Scan).filter(Scan.target.ilike(asset_target)).all()
                            for scan in related_scans:
                                if getattr(scan, "is_deleted", False):
                                    scan.is_deleted = False
                                    scan.deleted_at = None
                                    scan.deleted_by_user_id = None

                                for s_model in (Certificate, PQCClassification, CBOMEntry):
                                    try:
                                        s_rows = db_session.query(s_model).filter(s_model.scan_id == scan.id, s_model.is_deleted == True).all()
                                    except Exception:
                                        s_rows = []
                                    for s_row in s_rows:
                                        s_row.is_deleted = False
                                        s_row.deleted_at = None
                                        s_row.deleted_by_user_id = None

                                for s_model in (DiscoveryDomain, DiscoverySSL, DiscoveryIP, DiscoverySoftware, ComplianceScore, CyberRating, Subdomain):
                                    s_rows = db_session.query(s_model).filter(s_model.scan_id == scan.id, s_model.is_deleted == True).all()
                                    for s_row in s_rows:
                                        s_row.is_deleted = False
                                        s_row.deleted_at = None
                                        s_row.deleted_by_user_id = None

                                s_summary = db_session.query(CBOMSummary).filter(CBOMSummary.scan_id == scan.id, CBOMSummary.is_deleted == True).first()
                                if s_summary:
                                    s_summary.is_deleted = False
                                    s_summary.deleted_at = None
                                    s_summary.deleted_by_user_id = None
                    db_session.commit()
                    _audit("recycle_bin", "restore_assets", "success", details={"count": len(assets_to_restore)})
                    if wants_json:
                        return _json(
                            f"Successfully restored {len(assets_to_restore)} asset(s).",
                            200,
                            restored_count=len(assets_to_restore),
                            restored_asset_ids=[int(getattr(a, "id", 0) or 0) for a in assets_to_restore],
                        )
                    flash(f"Successfully restored {len(assets_to_restore)} asset(s).", "success")
                    
            elif action == "restore_scans":
                scan_ids = _payload_ids(payload, "scan_ids")
                if scan_ids:
                    scans_to_restore = db_session.query(Scan).filter(Scan.id.in_(scan_ids), Scan.is_deleted == True).all()
                    for scan in scans_to_restore:
                        scan.is_deleted = False
                        scan.deleted_at = None
                        scan.deleted_by_user_id = None

                        for s_model in (Certificate, PQCClassification, CBOMEntry):
                            try:
                                s_rows = db_session.query(s_model).filter(s_model.scan_id == scan.id, s_model.is_deleted == True).all()
                            except Exception:
                                s_rows = []
                            for s_row in s_rows:
                                s_row.is_deleted = False
                                s_row.deleted_at = None
                                s_row.deleted_by_user_id = None

                        for s_model in (DiscoveryDomain, DiscoverySSL, DiscoveryIP, DiscoverySoftware, ComplianceScore, CyberRating, Subdomain):
                            s_rows = db_session.query(s_model).filter(s_model.scan_id == scan.id, s_model.is_deleted == True).all()
                            for s_row in s_rows:
                                s_row.is_deleted = False
                                s_row.deleted_at = None
                                s_row.deleted_by_user_id = None

                        s_summary = db_session.query(CBOMSummary).filter(CBOMSummary.scan_id == scan.id, CBOMSummary.is_deleted == True).first()
                        if s_summary:
                            s_summary.is_deleted = False
                            s_summary.deleted_at = None
                            s_summary.deleted_by_user_id = None
                    db_session.commit()
                    _audit("recycle_bin", "restore_scans", "success", details={"count": len(scans_to_restore)})
                    if wants_json:
                        return _json(
                            f"Successfully restored {len(scans_to_restore)} scan(s).",
                            200,
                            restored_count=len(scans_to_restore),
                            restored_scan_ids=[int(getattr(s, "id", 0) or 0) for s in scans_to_restore],
                        )
                    flash(f"Successfully restored {len(scans_to_restore)} scan(s).", "success")
            
            elif action == "delete_assets":
                # Admin-only: permanently purge soft-deleted assets
                asset_ids = _payload_ids(payload, "asset_ids")
                if asset_ids:
                    assets_to_delete = db_session.query(Asset).filter(
                        Asset.id.in_(asset_ids), 
                        Asset.is_deleted == True
                    ).all()
                    
                    deleted_count = 0
                    for asset in assets_to_delete:
                        try:
                            # Explicitly purge scan-linked rows that are not FK-constrained by asset_id.
                            asset_target = str(getattr(asset, "name", "") or "").strip().lower()
                            if asset_target:
                                related_scans = db_session.query(Scan).filter(Scan.target.ilike(asset_target), Scan.is_deleted == True).all()
                                for scan in related_scans:
                                    db_session.query(DiscoveryDomain).filter(DiscoveryDomain.scan_id == scan.id).delete(synchronize_session=False)
                                    db_session.query(DiscoverySSL).filter(DiscoverySSL.scan_id == scan.id).delete(synchronize_session=False)
                                    db_session.query(DiscoveryIP).filter(DiscoveryIP.scan_id == scan.id).delete(synchronize_session=False)
                                    db_session.query(DiscoverySoftware).filter(DiscoverySoftware.scan_id == scan.id).delete(synchronize_session=False)
                                    db_session.query(Certificate).filter(Certificate.scan_id == scan.id).delete(synchronize_session=False)
                                    db_session.query(PQCClassification).filter(PQCClassification.scan_id == scan.id).delete(synchronize_session=False)
                                    db_session.query(CBOMEntry).filter(CBOMEntry.scan_id == scan.id).delete(synchronize_session=False)
                                    db_session.query(ComplianceScore).filter(ComplianceScore.scan_id == scan.id).delete(synchronize_session=False)
                                    db_session.query(CyberRating).filter(CyberRating.scan_id == scan.id).delete(synchronize_session=False)
                                    db_session.query(CBOMSummary).filter(CBOMSummary.scan_id == scan.id).delete(synchronize_session=False)
                                    db_session.delete(scan)

                            # Hard delete the asset (ORM cascade will handle related entities via ON DELETE CASCADE)
                            db_session.delete(asset)
                            deleted_count += 1
                        except Exception as e:
                            logger.warning(f"Failed to hard-delete asset {asset.id}: {e}")
                    
                    db_session.commit()
                    _audit("recycle_bin", "delete_assets", "success", details={"count": deleted_count})
                    if wants_json:
                        return _json(
                            f"Permanently deleted {deleted_count} asset(s) and related records.",
                            200,
                            deleted_count=deleted_count,
                            deleted_asset_ids=[int(getattr(a, "id", 0) or 0) for a in assets_to_delete],
                        )
                    flash(f"Permanently deleted {deleted_count} asset(s) and related records.", "warning")
            
            elif action == "delete_scans":
                # Admin-only: permanently purge soft-deleted scans
                scan_ids = _payload_ids(payload, "scan_ids")
                if scan_ids:
                    scans_to_delete = db_session.query(Scan).filter(
                        Scan.id.in_(scan_ids), 
                        Scan.is_deleted == True
                    ).all()
                    
                    deleted_count = 0
                    for scan in scans_to_delete:
                        try:
                            # Hard delete the scan (ORM cascade will handle related entities)
                            db_session.delete(scan)
                            deleted_count += 1
                        except Exception as e:
                            logger.warning(f"Failed to hard-delete scan {scan.id}: {e}")
                    
                    db_session.commit()
                    _audit("recycle_bin", "delete_scans", "success", details={"count": deleted_count})
                    if wants_json:
                        return _json(
                            f"Permanently deleted {deleted_count} scan(s) and related records.",
                            200,
                            deleted_count=deleted_count,
                            deleted_scan_ids=[int(getattr(s, "id", 0) or 0) for s in scans_to_delete],
                        )
                    flash(f"Permanently deleted {deleted_count} scan(s) and related records.", "warning")
                    
        except Exception as e:
            db_session.rollback()
            _audit("recycle_bin", action or "unknown", "failed", details={"error": str(e)})
            if wants_json:
                return _json(f"Error processing request: {str(e)}", 500)
            flash(f"Error processing request: {str(e)}", "danger")
            
        if wants_json:
            return _json("No matching items selected.", 200)
        return redirect(url_for("recycle_bin"))

    # GET Request: display soft-deleted items
    try:
        deleted_assets = db_session.query(Asset).filter(Asset.is_deleted == True).all()
        deleted_scans = db_session.query(Scan).filter(Scan.is_deleted == True).all()
        vm = {
            "empty": not deleted_assets and not deleted_scans,
            "assets": deleted_assets,
            "scans": deleted_scans,
            "is_admin": is_admin,  # Pass to template for conditional UI
            "is_manager": is_manager,
        }
    except Exception as e:
        logger.error(f"Error loading recycle bin: {e}")
        vm = {
            "empty": True,
            "assets": [],
            "scans": [],
            "is_admin": is_admin,
            "is_manager": is_manager,
        }
    
    return render_template("recycle_bin.html", vm=vm)




def _check_concurrency():
    import subprocess
    import atexit
    import time
    
    pid_file = os.path.join(os.path.dirname(__file__), "app_instance.pid")
    if os.path.exists(pid_file):
        try:
            with open(pid_file, "r") as f:
                old_pid = int(f.read().strip())
        except Exception:
            old_pid = None
        
        if old_pid and old_pid != os.getpid():
            # Check if alive on Windows
            cmd = f'tasklist /FI "PID eq {old_pid}" /NH'
            try:
                out = subprocess.check_output(cmd, shell=True).decode(errors='replace')
                if str(old_pid) in out:
                    print(f"\n[!] ALERT: Another instance of {app.import_name} is already running (PID: {old_pid}).")

                    import os as _os
                    auto_kill = _os.environ.get("AUTO_KILL_PREVIOUS", "false").lower() == "true"
                    
                    if auto_kill or sys.stdin.isatty():
                        ans = 'y' if auto_kill else input("Should I end the previous session to start this app? [y/N]: ").strip().lower()
                        if ans == 'y':

                            print(f"Terminating PID {old_pid}...")
                            subprocess.call(f'taskkill /F /PID {old_pid}', shell=True)
                            time.sleep(1)
                            if os.path.exists(pid_file): os.remove(pid_file)
                        else:
                            print("Redirecting to previous instance. Exiting Startup Guard.")
                            sys.exit(0)
                    else:
                        print("Non-interactive mode: Another instance is running. Exiting.")
                        sys.exit(0)
            except Exception:
                pass

    # Save current PID
    with open(pid_file, "w") as f:
        f.write(str(os.getpid()))

    def _cleanup_pid():
        if os.path.exists(pid_file):
            try:
                with open(pid_file, "r") as f:
                    if int(f.read().strip()) == os.getpid():
                        os.remove(pid_file)
            except Exception:
                pass
    atexit.register(_cleanup_pid)


def _auto_update_on_start():
    """Optional auto-update on startup: check branch heads or release tags.

    Controlled by environment variables:
      - QSS_AUTO_UPDATE_ON_START (true|false) — enable check at startup
      - QSS_ALLOW_AUTO_PULL (true|false) — allow performing a hard reset or tag checkout
      - QSS_GIT_BRANCH — branch name to compare (default: main)
      - QSS_AUTO_UPDATE_SOURCE — 'branch' (default) or 'release' to follow Git tags
      - QSS_RELEASE_TAG_PREFIX — optional tag prefix when tracking releases (default: v)

    Safety: requires a clean working tree. If an update is performed the process
    re-execs itself to pick up new code. No secrets are stored here.
    """
    try:
        if os.environ.get("QSS_AUTO_UPDATE_ON_START", "false").lower() != "true":
            return
        if os.environ.get("QSS_AUTO_UPDATE_PERFORMED") == "1":
            logger.info("Auto-update already performed; skipping.")
            return

        update_source = os.environ.get("QSS_AUTO_UPDATE_SOURCE", "branch").strip().lower()
        if update_source not in {"branch", "release", "releases", "tag", "tags"}:
            update_source = "branch"

        import shutil
        import subprocess

        git = shutil.which("git")
        if not git:
            logger.warning("Auto-update requested but 'git' is not available on PATH.")
            return

        p = subprocess.run([git, "rev-parse", "--is-inside-work-tree"], cwd=BASE_DIR, capture_output=True, text=True)
        if p.returncode != 0 or "true" not in p.stdout:
            logger.warning("Not a git work tree (or git rev-parse failed). Skipping auto-update.")
            return

        if update_source in {"release", "releases", "tag", "tags"}:
            tag_prefix = os.environ.get("QSS_RELEASE_TAG_PREFIX", "v").strip()
            fetch = subprocess.run([git, "fetch", "--tags", "--prune", "origin"], cwd=BASE_DIR, capture_output=True, text=True)
            if fetch.returncode != 0:
                logger.warning("git fetch --tags failed: %s", fetch.stderr.strip())
                return

            tag_pattern = f"{tag_prefix}*" if tag_prefix else "*"
            latest = subprocess.run(
                [git, "tag", "--list", tag_pattern, "--sort=-version:refname"],
                cwd=BASE_DIR,
                capture_output=True,
                text=True,
            )
            if latest.returncode != 0:
                logger.warning("Failed to list release tags: %s", latest.stderr.strip())
                return

            latest_tag = next((line.strip() for line in latest.stdout.splitlines() if line.strip()), "")
            if not latest_tag:
                logger.info("No release tags found; skipping release update check.")
                return

            current = subprocess.run(
                [git, "describe", "--tags", "--exact-match"],
                cwd=BASE_DIR,
                capture_output=True,
                text=True,
            )
            current_tag = current.stdout.strip() if current.returncode == 0 else ""

            if current_tag == latest_tag:
                logger.info("Local repository is already on latest release tag %s", latest_tag)
                return

            logger.info("Latest release tag differs from local tag (%s -> %s)", current_tag or "<none>", latest_tag)

            if os.environ.get("QSS_ALLOW_AUTO_PULL", "false").lower() != "true":
                logger.warning("Auto-pull disabled (set QSS_ALLOW_AUTO_PULL=true to enable). Skipping update.")
                return

            status = subprocess.run([git, "status", "--porcelain"], cwd=BASE_DIR, capture_output=True, text=True)
            if status.stdout.strip():
                logger.warning("Uncommitted changes present in working tree; refusing tag checkout. Clean the tree or disable auto-update.")
                return

            checkout = subprocess.run([git, "checkout", "-f", latest_tag], cwd=BASE_DIR, capture_output=True, text=True)
            if checkout.returncode != 0:
                logger.warning("git checkout failed: %s", checkout.stderr.strip())
                return

            logger.info("Pulled latest release tag %s — restarting process to pick up changes.", latest_tag)
        else:
            branch = os.environ.get("QSS_GIT_BRANCH", "main")

            fetch = subprocess.run([git, "fetch", "origin", branch], cwd=BASE_DIR, capture_output=True, text=True)
            if fetch.returncode != 0:
                logger.warning("git fetch failed: %s", fetch.stderr.strip())
                return

            local = subprocess.run([git, "rev-parse", "HEAD"], cwd=BASE_DIR, capture_output=True, text=True)
            remote = subprocess.run([git, "rev-parse", f"origin/{branch}"], cwd=BASE_DIR, capture_output=True, text=True)
            if local.returncode != 0 or remote.returncode != 0:
                logger.warning("Failed to read commit hashes; skipping auto-update.")
                return

            local_sha = local.stdout.strip()
            remote_sha = remote.stdout.strip()
            if not local_sha or not remote_sha:
                logger.info("Could not determine commit SHAs; skipping auto-update.")
                return

            if local_sha == remote_sha:
                logger.info("Local repository is up-to-date with origin/%s", branch)
                return

            logger.info("Remote origin/%s differs from local HEAD (%s -> %s)", branch, local_sha[:8], remote_sha[:8])

            if os.environ.get("QSS_ALLOW_AUTO_PULL", "false").lower() != "true":
                logger.warning("Auto-pull disabled (set QSS_ALLOW_AUTO_PULL=true to enable). Skipping update.")
                return

            status = subprocess.run([git, "status", "--porcelain"], cwd=BASE_DIR, capture_output=True, text=True)
            if status.stdout.strip():
                logger.warning("Uncommitted changes present in working tree; refusing hard reset. Clean the tree or disable auto-update.")
                return

            reset = subprocess.run([git, "reset", "--hard", f"origin/{branch}"], cwd=BASE_DIR, capture_output=True, text=True)
            if reset.returncode != 0:
                logger.warning("git reset failed: %s", reset.stderr.strip())
                return

            logger.info("Pulled latest code from origin/%s — restarting process to pick up changes.", branch)

        os.environ["QSS_AUTO_UPDATE_PERFORMED"] = "1"
        python = sys.executable
        os.execv(python, [python] + sys.argv)

    except Exception as exc:
        logger.warning("Auto-update check failed: %s", exc)


if __name__ == "__main__":
    # Optionally auto-update code from the remote before boot.
    # Controlled by QSS_AUTO_UPDATE_ON_START and QSS_ALLOW_AUTO_PULL environment variables.
    try:
        _auto_update_on_start()
    except Exception:
        pass

    _start_scheduler_if_enabled()
    _bootstrap_runtime_state()

    print(f"\n{'='*60}")
    print(f"  [QuantumShield] {app.import_name} - Quantum-Safe TLS Scanner")
    print(f"  Running on https://{FLASK_HOST}:{FLASK_PORT}")
    print(f"{'='*60}\n")

    # ── HTTP → HTTPS redirect server (background daemon) ─────────────
    _http_redirect_port = int(os.environ.get("QSS_HTTP_REDIRECT_PORT", "5080"))
    _start_http_redirect_server(
        http_port=_http_redirect_port,
        https_port=FLASK_PORT,
        https_host=FLASK_HOST,
    )

    # Prefer mkcert-generated trusted certs (no browser warning)
    _cert_file = os.path.join(BASE_DIR, "certs", "cert.pem")
    _key_file  = os.path.join(BASE_DIR, "certs", "key.pem")
    _has_certs = os.path.exists(_cert_file) and os.path.exists(_key_file)

    if DEBUG:
        # Dev mode: use Flask built-in server with hot-reload
        if _has_certs:
            _ssl_ctx = (_cert_file, _key_file)
            print("  [OK] Using mkcert trusted SSL certificate (no browser warnings)")
        else:
            _ssl_ctx = "adhoc"
            print("  [WARN] No certs/ dir found - using adhoc self-signed cert (browser will warn)")
            print("     To fix, run:  mkcert -install && mkcert -key-file certs/key.pem -cert-file certs/cert.pem localhost 127.0.0.1")

        app.run(host=FLASK_HOST, port=FLASK_PORT, debug=True, ssl_context=_ssl_ctx)
    else:
        # Production mode: use Waitress (Windows-compatible WSGI server)
        try:
            from waitress import serve as waitress_serve  # type: ignore
            print("  [OK] Production mode - Waitress WSGI server")
            if _has_certs:
                print("  [OK] TLS certs loaded from certs/")
            else:
                print("  [WARN] No certs/ dir - running plain HTTP on Waitress")
                print("     Tip: put a reverse proxy (nginx/caddy) in front for HTTPS in production")
            # Waitress does not natively handle SSL — use a reverse proxy for HTTPS.
            # For dev convenience with certs, fall back to Flask's ssl_context.
            if _has_certs:
                # Use Flask's dev server with certs for now (Waitress + SSL needs a proxy)
                app.run(host=FLASK_HOST, port=FLASK_PORT, debug=False, ssl_context=(_cert_file, _key_file))
            else:
                waitress_serve(app, host=FLASK_HOST, port=int(FLASK_PORT), threads=8)
        except ImportError:
            print("  [WARN] Waitress not installed - falling back to Flask dev server")
            print("     Install with: pip install waitress")
            app.run(host=FLASK_HOST, port=FLASK_PORT, debug=False, ssl_context="adhoc")
